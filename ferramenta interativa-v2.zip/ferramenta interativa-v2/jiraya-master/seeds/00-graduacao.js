/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */

exports.seed = async function (knex) {
  // Deletes ALL existing entries
  // await knex("ufpa_graduacao").del();

  await knex.raw("ALTER TABLE ufpa_graduacao AUTO_INCREMENT = 1"); // reseta o incremento da coluna id

  await knex("ufpa_graduacao").insert([
    {
      nome: "Engenharia da Computação",
      codigo: "00108",
    },
    {
      nome: "Engenharia de Telecomunicações",
      codigo: "00109",
    },
    {
      nome: "Engenharia Elétrica",
      codigo: "00102",
    },
    {
      nome: "Contabilidade",
      codigo: "00705",
    },
  ]);
};
