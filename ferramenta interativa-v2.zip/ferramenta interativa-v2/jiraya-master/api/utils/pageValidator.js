exports.validatePageNumber = (page) => {
  if (!Number(page)) {
    return 1
  }

  if (Math.floor(+page) <= 0) {
    return 1
  }

  return Math.floor(+page)
}
