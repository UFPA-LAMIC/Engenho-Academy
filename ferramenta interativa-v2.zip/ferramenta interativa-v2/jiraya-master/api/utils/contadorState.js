exports.getCount = async (app, tableName) => {
  try {
    const [ok, error, aberto, total] = await Promise.all([
      app.db(tableName).count('id as count').where({ state: 'OK' }).first(),
      app.db(tableName).count('id as count').where({ state: 'ERROR' }).first(),
      app.db(tableName).count('id as count').where({ state: '' }).first(),
      app.db(tableName).count('id as count').where({}).first(),
    ])

    return {
      ok: ok.count,
      error: error.count,
      aberto: aberto.count,
      total: total.count,
    }
  } catch (error) {
    // eslint-disable-next-line no-console
    console.error(error)
    return {
      ok: 0,
      error: 0,
      aberto: 0,
      total: 0,
    }
  }
}
