const express = require("express");
const router = express.Router();
const RespostaController = require("../controllers/resposta.controller.js");

// Require the authenticate middleware
const { authenticate } = require("../middlewares/auth");

const roles = [99, 1, 7];
const master = [99, 7];

//Routes for resposta crud operations
router.post(
  "/:idPergunta",
  authenticate(roles),
  RespostaController.createResposta
);
// router.get('/', authenticate(roles), RespostaController.findAllRespostas)
// router.get('/:id', authenticate(roles), RespostaController.getRespostaById)

module.exports = router;
