const express = require("express");
const router = express.Router();
const VideoController = require("../controllers/video.controller.js");

// Require the authenticate middleware
const { authenticate } = require("../middlewares/auth");
const {
  authenticateUser,
  authenticateCourseAccess,
} = require("../middlewares/authRules.js");

const roles = [99, 1, 7];
const master = [99, 7];

router.post("/", authenticate(master), VideoController.createVideo);
router.get("/", authenticate(roles), VideoController.getAllVideos);
router.get("/:id", authenticate(roles), VideoController.getVideoById);
router.get(
  "/curso/:id_curso",
  authenticateUser(roles),
  authenticateCourseAccess,
  VideoController.getAllVideosFromThatCourse
);
router.put("/:id", authenticate(master), VideoController.editVideo);

module.exports = router;
