const Resposta = require("../models/resposta.model.js");
const RespostaResposta = require("../models/pergunta-resposta.model.js");
const { numberToMonthMapper } = require("../utils/numberToMonthMapper.js");

const RespostaController = {
  async createResposta(req, res) {
    const resposta = {
      ...req.body,
      id_pergunta: Number(req.params.idPergunta),
    };
    
    try {
      await Resposta.createResposta(resposta);
      // O que eu tentei fazer aqui foi pegar o id da pergunta por parâmetro e jogar na tabela pergunta_resposta. Agora foi mudado a tabela resposta e add nela o id da pergunta
      // await RespostaResposta.createPerguntaResposta(perguntaResposta);
      res
        .status(200)
        .json({ msg: "new resposta created and added to pergunta_resposta" });
    } catch (error) {
      res.status(500).json({
        error: `Erro no controller createResposta - ${error.message}`,
      });
    }
  },
};

module.exports = RespostaController;
