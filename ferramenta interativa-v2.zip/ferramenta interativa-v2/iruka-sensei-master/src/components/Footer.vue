<template>
  <footer>
    <div class="my-footer">
      <div>
        <img class="logo" src="@/assets/logo.png" alt="logo footer" />
        <p class="lamic">
          Laboratório de Monitoramento Inteligente e Soluções em
          Telecomunicações
        </p>
      </div>
      <img
        class="brasao"
        src="@/assets/ufpa-brasao.png"
        alt="ufpa brasao footer"
      />
      <aside class="texto">
        <p class="contato">Contato</p>
        <p class="email"><strong>E-mail: </strong>agcastro@ufpa.br</p>
      </aside>
    </div>
    <div class="copy">
      <p>&copy; 2023, LPB & AGCastro</p>
    </div>
  </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style lang="scss" scoped>
footer {
  //   position: absolute;
  //   width: 100%;
  //   bottom: 0;
  //   margin: 50px;
  background: $primary_color;
  //   background: red;
}
.my-footer {
  height: 160px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 50px;
}
.logo {
  width: 130px;
  position: relative;
  right: 6px;
  top: 8px;
  // background: purple;
}
.brasao {
  width: 80px;
  // background: red;
}

.lamic {
  // background: purple;
  text-align: start;
  font-family: $primary_font;
  width: 260px;
  font-size: 10px;
  font-weight: 500;
  margin: 0;
  line-height: 15px;
  color: $fontes_background;
}

.texto {
  text-align: end;
  font-family: $primary_font;
  width: 260px;
}
.texto p {
  margin: 0;
  color: $fontes_background;
}

.contato {
  font-size: 18px;
  font-weight: 700;
}

.email {
  font-size: 14px;
}

.copy {
  height: 40px;
  background: $footer_second_color;
  // background: rgb(198, 135, 0);
  display: flex;
  justify-content: center;
  align-items: center;
}

.copy p {
  // color: #fff;
  margin: 0;
  font-family: $primary_font;
  color: $fontes_background;
}

@media screen and (max-width: 650px) {
  .my-footer {
    display: grid;
    grid-template-columns: 80% 20%;
    justify-content: space-between;
    align-items: center;
  }

  .logo {
    width: 100px;
    right: 4px;
    top: 6px;
  }

  .lamic {
    width: 220px;
  }

  .brasao {
    width: 50px;
  }

  .texto {
    text-align: start;
  }

  .copy p {
    font-size: 14px;
  }
}
</style>