<template>
  <base-page-layout>
    <aside v-if="isLogged">
      <meus-cursos-docente v-if="isDocente" />
      <meus-cursos-discente v-else />
      <!-- <div class="paginacao">
          <v-pagination
            v-model="currentPage"
            :total-items="totalItems"
            :items-per-page="itemsPerPage"
            @input="updatePage"
          />
        </div> -->
    </aside>
    <aside v-else>
      <div class="sem-cursos">
        <img
          src="../../../../public/assets/sem-cursos.png"
          alt="Sem cursos img"
        />
        <p @click="redirectTo('login')">
          Faça o login para visualizar seus cursos! <span>Ir para login.</span>
        </p>
      </div>
    </aside>
  </base-page-layout>
</template>
  
  <script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import { mapState } from "vuex";
import MeusCursosDocente from "../components/MeusCursosDocente.vue";
import MeusCursosDiscente from "../components/MeusCursosDiscente.vue";
export default {
  components: { BasePageLayout, MeusCursosDocente, MeusCursosDiscente },
  data: () => ({
    cursos: [],
    cursosDocente: [],
    src: "",
    isLogged: false,
    isDocente: false,
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
  },
  beforeMount() {
    this.whichPageMustShow();
    window.scrollTo(0, 0);
  },
  methods: {
    whichPageMustShow() {
      if (!this.$isLogged()) {
        return;
      }
      this.isLogged = true;

      this.user.tipo === "DOCENTE"
        ? (this.isDocente = true)
        : (this.isDocente = false);
    },
    redirectTo(where) {
      this.$router.push({ name: `${where}` }).catch(() => {});
    },
  },
};
</script>
<style lang="scss" scoped>
.sem-cursos {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 80vh;
}
.sem-cursos img {
  width: 800;
  height: 400px;
}

.sem-cursos p,
span {
  font-family: $primary_font;
}

.sem-cursos span {
  color: $primary_btn;
}
.sem-cursos span:hover {
  cursor: pointer;
}
</style>