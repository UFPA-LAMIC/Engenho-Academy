<template>
  <v-card class="mt-5">
    <v-toolbar color="#002040" dark>
      <v-toolbar-title
        >Curso de Manutenção e Redes de Computadores</v-toolbar-title
      >
      <v-spacer />
      <div>
        <cadastro-model
          v-if="getUser.tipo === 'DOCENTE'"
          :id="cursoId"
          @updatePage="loadVideos()"
        />
      </div>
    </v-toolbar>

    <v-list subheader two-line>
      <v-subheader inset>Aulas</v-subheader>

      <v-list-item v-for="video in videos" :key="video.titulo">
        <v-list-item-avatar>
          <v-icon class="green" dark> mdi-movie-play </v-icon>
        </v-list-item-avatar>

        <v-list-item-content>
          <v-list-item-title v-text="video.titulo"></v-list-item-title>

          <v-list-item-subtitle
            v-text="video.dth_sistema"
          ></v-list-item-subtitle>
        </v-list-item-content>

        <v-list-item-action>
          <v-btn
            icon
            :to="{ name: 'videos', params: { id: video.id, curso: cursoId } }"
            style="text-decoration: none; color: #000"
          >
            <v-icon color="grey lighten-1">mdi-play-circle</v-icon>
          </v-btn>
        </v-list-item-action>
      </v-list-item>
      <!-- <v-divider></v-divider> -->
    </v-list>
  </v-card>
</template>

<script>
import axios from "axios";
import { baseApiUrl } from "../global";
import CadastroModel from "../features/CadastroModel.vue";
import { mapGetters } from "vuex";
export default {
  name: "VideoList",
  components: { CadastroModel },
  props: {
    cursoId: {
      type: Number,
      // default: 1,
    },
  },
  data: function () {
    return {
      videos: [],
      video: {},
      mode: "",
    };
  },
  computed: mapGetters(["getUser"]),
  methods: {
    // async loadVideos() {
    //   try {
    //     const response = await axios.get(
    //       `${baseApiUrl}/videos/?id_curso=${this.cursoId}`
    //     );
    //     this.videos = response.data.data;
    //     console.log(this.videos);
    //   } catch (error) {
    //     console.error(error);
    //   }
    // },
    loadVideos() {
      axios
        .get(`${baseApiUrl}/videos/?id_curso=${this.cursoId}`)
        .then((res) => {
          this.videos = res.data.data;
        })
        .catch((error) => {
          alert(error.res.data.msg);
        });
    },
  },
  mounted() {
    this.loadVideos();
  },
};
</script>
<style>
</style>