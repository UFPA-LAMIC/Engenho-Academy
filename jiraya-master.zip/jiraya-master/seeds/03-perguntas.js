/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */

exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex("perguntas").del();

  await knex.raw("ALTER TABLE perguntas AUTO_INCREMENT = 1"); // reseta o incremento da coluna id

  await knex("perguntas").insert([
    {
      pergunta:"O que é polimorfismo em java?",
      autor: 1,
    },
    {
      pergunta:"O que é o herança em java?",
      autor: 3,
    },
    {
      pergunta:"O que é O protocolo TCP/IP ?",
      autor: 1,
    },
    {
      pergunta:"Por que a cortina é azul ?",
      autor: 3,
    },
  ]);
};
