exports.up = function (knex, Promise) {
  return knex.schema.createTable("users", (table) => {
    table.increments("id").primary();
    table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
    table.string('tipo').defaultTo("DISCENTE");
    table.string("nome", 100);
    table.string("email",60);
    table.string("password");
    table.date("dt_nascimento")
    table.boolean("pcd").defaultTo(false);
    table.enu("pne", ["VISUAL", "MOTORA"]);
    table.integer("graduacao").unsigned();
    table.foreign("graduacao").references("id").inTable("ufpa_graduacao");
  });
};

exports.down = function (knex, Promise) {
  return knex.schema.dropTable("users");
};
