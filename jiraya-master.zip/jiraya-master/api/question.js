module.exports = (app) => {
    const limit = 25;
    
    const getQuestion = async (req, res) => {
      try {
        let {  quest  } = req.query;
        
        if (quest) quest = quest.trim(); //tira o espaço em branco, final e começo
        else quest = "";
            
        const page = req.query.page || 1;
        const result = await app
          .db("pergunta")
          .count("id as count")
          .where({ aula: req.params.aula })
          .where("pergunta", "like", `%${quest}%`)
          .first();
        const count = parseInt(result.count);
        const perguntas = await app
          .db("pergunta")
          .where({ aula: req.params.aula })
          .where("pergunta", "like", `%${quest}%`)
          .leftJoin("users", "pergunta.autor", "=", "users.id")
          .leftJoin("resposta", "pergunta.id", "=", "resposta.id_pergunta")
          .leftJoin("users AS usuario", "resposta.autor", "=", "usuario.id")
          .select("pergunta.*", "resposta.resposta", "resposta.id as id_resposta", "resposta.rank as rank_resposta", "users.email as autor_pergunta", "usuario.email as autor_resposta",
          app.db('resposta')
          .count('*')
          .whereRaw('?? = ??', ['resposta.id_pergunta', 'pergunta.id'])
          .as('total_respostas')
          )
          .orderBy('resposta.id')
          .limit(limit)
          .offset(page * limit - limit);

          const mapper = {}
          const resultado = []

          perguntas.forEach((pergunta) => {
            if (mapper[pergunta.id]) {
              mapper[pergunta.id].respostas.push({
                id: pergunta.id_resposta,
                resposta: pergunta.resposta,
                autor_resposta: pergunta.autor_resposta,
                rank: pergunta.rank_resposta
              })
            } else {
              const obj = {
                ...pergunta,
                respostas: [
                  { id: pergunta.id_resposta, resposta: pergunta.resposta, autor_resposta: pergunta.autor_resposta, rank: pergunta.rank_resposta }
                ]
              }

              console.log(obj)
              delete obj.resposta
              delete obj.autor_resposta

              mapper[pergunta.id] = obj
            }
          })
          for (const key in mapper) {
            resultado.push(mapper[key])
          }

          const perguntasFormated = resultado.map(form => {
            const [date, time] = form.dth_sistema.split(" ");
            const dataFormatada = date.split("-").reverse().join("/");
    
            const formatedDtsistema = dataFormatada + " " + time;
         
                  return { ...form, dth_sistema: formatedDtsistema,  };
                });
  
          res.json({ data: perguntasFormated, count, limit });
      } catch (error) {
        res.status(500).send(error);
        console.log(error)
      }
    };
  
    const getQuestionById = async (req, res) => {
    
     const responsavel = await app.db("pergunta").
      join("users", "pergunta.autor", "=", "users.id")
      .select("users.email");

      app
      .db("pergunta")
        .select()
        .table("pergunta")
        .where({ id: req.params.id })
        .first()
        .then((perguntas) => {
          const [date, time] = perguntas.dth_sistema.split(' ');
          const dateFormated = date.split("-").reverse().join("/");
          
          const formatedDtsistema = dateFormated + " " + time;
          
          res.json({ ...perguntas, dth_sistema: formatedDtsistema, autor: responsavel });
        })
        .catch((err) => res.status(500).send(err));
    };
    
  
      const saveQuestion = async (req, res) => {
        try {
          const pergunta = { ...req.body }
            const inserir = await app
              .db("pergunta")
              .insert({...pergunta})
            res.json(inserir)
        } catch (error) {
          res.status(500).send(error);
        }
      };
  
      const updateQuestion = async (req, res) => {
        try {
          const state = { ...req.body };
          console.log(state)
          const status = await app
            .db("pergunta")
            .where({ id: state.id })
            .update({ 
              pergunta: state.pergunta,
              rank: state.rank,
              autor: state.autor
            });
            console.log(status)
          res.json(status);
        } catch (error) {
          res.status(500).send(error);
        }
      };
    
      const updateState = async (req, res) => {
        try {
          const auto = {
            id: req.body.id,
            state: req.body.state,
            state_description: req.body.state_description,
            id_administrativo: req.body.id_administrativo,
          };
    
          const status = await app
            .db("relatorio_disparo")
            .where({ id: auto.id })
            .update({ state: auto.state })
            .update({ state_description: auto.state_description })
            .update({ id_administrativo: auto.id_administrativo });
    
          res.json({
            data: status,
            // msg: `Documento: Auto de Entrega número ${auto.id} modificado com sucesso`,
          });
        } catch (error) {
          res.status(500).send(error);
        }
      };
  
  
  
  return { getQuestion, getQuestionById, saveQuestion, updateQuestion };
  
}

// .join("comentario", "resposta.id", "=", "comentario.id_resposta")
// .join("resposta", "pergunta.id", "=", "resposta.id_pergunta")
//           .select("pergunta.*","resposta.id as resposta_id", "resposta.resposta", "comentario.comentario", "comentario.id_resposta", "users.email as autor_pergunta")


// [
//   {
// 	pergunta:"Pergunta 1",
// 	autor:"luan",
// 	resposta:"resposta 1",
// 	autor_resposta:"Cardeal",
// 	resposta2:"resposta 2",
// 	autor_resposta:"Fernando"
//   },
//   {
// 	pergunta:"Pergunta 2",
// 	autor:"Cardeal",
// 	resposta:"resposta 1",
// 	autor_resposta:"Luan",
// 	resposta2:"resposta 2",
// 	autor_resposta:"Fernando",
// 	resposta3:"resposta 3",
// 	autor_resposta:"Luan",
// 	resposta4:"resposta 4",
// 	autor_resposta:"Fernando"
//   }

// ]