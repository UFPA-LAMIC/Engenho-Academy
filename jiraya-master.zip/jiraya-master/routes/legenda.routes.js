const express = require('express')
const router = express.Router()
const legendaController = require('../controllers/legenda.controller.js')

// Require the authenticate middleware

router.post('/', legendaController.findLegenda)
module.exports = router