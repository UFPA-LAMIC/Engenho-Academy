const express = require('express')
const router = express.Router()
const { verifyToken } = require('../controllers/verifyToken.controller.js')

router.post('/', verifyToken)

module.exports = router
