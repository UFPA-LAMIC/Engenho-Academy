const express = require('express')
const router = express.Router()
const GraduacaoController = require('../controllers/graduacao.controller.js')

// Require the authenticate middleware
const { authenticate } = require('../middlewares/auth');

// here I can put the roles that my graduacaos will acces
const roles = ['DOCENTE', 'DISCENTE']

//Routes for graduacao crud operations
router.post('/', GraduacaoController.createGraduacao)
router.get('/', GraduacaoController.getAllGraduacao)
router.get('/:id', authenticate(roles), GraduacaoController.getGraduacaoById)

module.exports = router