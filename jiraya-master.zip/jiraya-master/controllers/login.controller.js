const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const Login = require("../models/login.model");
const { jwtSecret } = require("../env");

const loginController = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find user by username
    const user = await Login.getLoggedUser(email);

    // Check if user exists
    if (!user) {
      return res.status(400).json({ message: "Usuário não encontrado!" });
    }

    // Check if password is correct
    if (!(await bcrypt.compare(password, user.password))) {
      return res.status(400).json({ message: "Senha incorreta!" });
    }

    // Generate token
    const token = jwt.sign({...user}, jwtSecret, { expiresIn: "3d" });

    // Return token
    res.json({ token, user });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error in login request");
  }
};

module.exports = { loginController };
