const jwt = require("jsonwebtoken");
const { jwtSecret } = require("../env");
const db = require("../config/db"); // Instância do banco

// Middleware para autenticação geral (usuário logado)
const authenticateUser = (roles) => (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Unauthorized, please login!" });
  }

  try {
    const payload = jwt.verify(token, jwtSecret);

    const foundRole = roles.includes(payload.id_tipo);
    if (!foundRole) {
      return res
        .status(403)
        .json({ msg: "Usuário não possui acesso à página!" });
    }

    req.userId = payload.id; // Armazena o ID do usuário na requisição para uso posterior
    next();
  } catch (error) {
    return res
      .status(401)
      .json({ message: "Expired token! Please login again", expired: true });
  }
};

// Middleware para verificar se o usuário está matriculado no curso
// Seu uso é para que o aluno tenha acesso somente aos vídeos do curso que está matriculado.
const authenticateCourseAccess = async (req, res, next) => {
  try {
    const { id_curso } = req.params;

    if (!id_curso) {
      return res.status(400).json({ msg: "ID do curso não fornecido!" });
    }

    const isEnrolled = await db("matricula")
      .where({ curso: id_curso, aluno: req.userId })
      .first();

    // console.log("Matrícula encontrada:", isEnrolled);

    if (!isEnrolled || isEnrolled.status !== 1) {
      return res
        .status(403)
        .json({ msg: "Acesso negado! Você não está matriculado neste curso." });
    }

    next();
  } catch (error) {
    console.error("Erro ao verificar matrícula:", error);
    return res
      .status(500)
      .json({ msg: "Erro interno ao verificar matrícula." });
  }
};

// Middleware para verificar se o aluno é o próprio usuário logado e assim ter acesso às matriculas que ele fez
const authenticateMatriculaByAluno = async (req, res, next) => {
  try {
    const { idAluno } = req.params;

    if (idAluno != req.userId) {
      return res
        .status(400)
        .json({ msg: "ID do aluno é diferente do usuário logado!" });
    }

    next();
  } catch (error) {
    console.error("Erro ao verificar matrícula:", error);
    return res
      .status(500)
      .json({ msg: "Erro interno ao verificar matrícula." });
  }
};

module.exports = {
  authenticateUser,
  authenticateCourseAccess,
  authenticateMatriculaByAluno,
};

// const jwt = require("jsonwebtoken");
// const { jwtSecret } = require("../env");
// const db = require("../config/db"); // Importe a instância do banco de dados

// // Middleware para autenticação geral (usuário logado)
// const authenticateCourseAccess = (roles) => async (req, res, next) => {
//   const token = req.headers.authorization?.split(" ")[1];

//   if (!token) {
//     return res.status(401).json({ message: "Unauthorized, please login!" });
//   }

//   try {
//     const payload = jwt.verify(token, jwtSecret);

//     const foundRole = roles.find((role) => role === payload.tipo);
//     if (!foundRole) {
//       return res
//         .status(403)
//         .json({ msg: "Usuário não possui acesso à página!" });
//     }

//     const { id_curso } = req.params;

//     if (!id_curso) {
//       return res.status(400).json({ msg: "ID do curso não fornecido!" });
//     }

//     const isEnrolled = await db("matricula")
//       .where({ curso: id_curso, aluno: payload.id })
//       .first();

//     console.log(isEnrolled);
//     if (!isEnrolled) {
//       return res
//         .status(403)
//         .json({ msg: "Acesso negado! Você não está matriculado neste curso." });
//     }
//     next();
//   } catch (error) {
//     res
//       .status(401)
//       .json({ message: "Expired token! Please login again", expired: true });
//   }
// };

// module.exports = { authenticateCourseAccess };
