const db = require("../config/db");
const { formatDate, formatDatetime } = require("../utils");

const Curso = {
  async createCurso(curso) {
    try {
      await db("cursos").insert(curso);
    } catch (error) {
      throw new Error(`Erro no endpoint createCurso - ${error.message}`);
    }
  },

  //query para buscar todos os cursos
  async findAllCursos(param) {
    try {
      const [count, getCurso] = [
        await db("cursos")
          .join("users", "cursos.docente", "=", "users.id")
          .count("cursos.id as count")
          .where("cursos.nome", "like", `%${param.nome}%`)
          .first(),

        await db("cursos")
          .select("cursos.*", "users.nome as responsavel")
          .join("users", "cursos.docente", "=", "users.id")
          .where("cursos.nome", "like", `%${param.nome}%`)
          .orderBy("cursos.id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const getCursoFormated = getCurso.map((curso) => {
        return {
          ...curso,
          data_inicio: formatDate(curso.data_inicio),
          data_fim: formatDate(curso.data_fim),
        };
      });
      const curso = {
        data: getCursoFormated,
        ...count,
      };
      return curso;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllCurso - ${error.message}`);
    }
  },

  //query para buscar todos os cursos que o aluno se matriculou
  async findAllCursosMatriculados(param) {
    try {
      const [count, getCurso] = [
        await db("cursos")
          .count("cursos.id as count")
          .join("matricula", "cursos.id", "=", "matricula.curso")
          .join("users", "cursos.docente", "=", "users.id")
          .where("matricula.aluno", "=", param.aluno)
          .first(),

        await db("cursos")
          .select("cursos.*", "users.nome as responsavel")
          .join("users", "cursos.docente", "=", "users.id")
          .join("matricula", "cursos.id", "=", "matricula.curso")
          .where("matricula.aluno", "=", param.aluno)
          .orderBy("cursos.id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const getCursoFormated = getCurso.map((curso) => {
        return {
          ...curso,
          data_inicio: formatDate(curso.data_inicio),
          data_fim: formatDate(curso.data_fim),
        };
      });
      const curso = {
        data: getCursoFormated,
        ...count,
      };
      return curso;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllCurso - ${error.message}`);
    }
  },

  //query para buscar todos os cursos que o docente cadastrou
  async findAllCursosOfDocente(param) {
    try {
      const [count, getCurso] = [
        await db("cursos")
          .count("cursos.id as count")
          .join("users", "cursos.docente", "=", "users.id")
          .where("cursos.docente", "=", param.docente)
          .first(),

        await db("cursos")
          .select("cursos.*", "users.nome as responsavel")
          .join("users", "cursos.docente", "=", "users.id")
          .where("cursos.docente", "=", param.docente)
          .orderBy("cursos.id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const getCursoFormated = getCurso.map((curso) => {
        return {
          ...curso,
          data_inicio: formatDate(curso.data_inicio),
          data_fim: formatDate(curso.data_fim),
        };
      });
      const curso = {
        data: getCursoFormated,
        ...count,
      };
      return curso;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllCurso - ${error.message}`);
    }
  },

  async findCursoByDocente(idCurso, idUser) {
    try {
      const curso = await db("cursos")
        .join("users", "cursos.docente", "users.id")
        .where("cursos.id", idCurso)
        .andWhere("users.id", idUser)
        .andWhere("users.tipo", "DOCENTE")
        .select("cursos.*", "users.nome as docente_nome")
        .first();

      let cursoFormated = {};

      if (curso) {
        console.log("O usuário é docente deste curso:", curso);
        cursoFormated = {
          ...curso,
          is_docente: true,
          dth_sistema: formatDatetime(curso.dth_sistema),
          data_inicio: formatDate(curso.data_inicio),
          data_fim: formatDate(curso.data_fim),
        };
      } else {
        console.log("O usuário não é docente deste curso.");
        cursoFormated = {
          is_docente: false,
        };
      }
      return cursoFormated;
    } catch (error) {
      throw new Error(`Erro no endpoint findCursoByDocente - ${error.message}`);
    }
  },

  async findCursoById(id) {
    try {
      let criador = {};

      const curso = await db("cursos").where("id", id).select().first();

      // if (curso.docente) {
      // criador = await db("cursos")
      //   .join("users", "cursos.docente", "=", "users.id")
      //   .select("users.nome")
      //   .where("cursos.id", "=", id)
      //   .first();
      // }

      const docente = await db("users")
        .where("id", curso.docente)
        .select()
        .first();

      const numberOfVideos = await db("videos")
        .where("curso", curso.id)
        .select();

      const cursoFormated = {
        ...curso,
        dth_sistema: formatDatetime(curso.dth_sistema),
        data_inicio: formatDate(curso.data_inicio),
        data_fim: formatDate(curso.data_fim),
        criador: curso.docente ? docente.nome : null,
        numberOfVideos: numberOfVideos.length,
      };
      return cursoFormated;
    } catch (error) {
      throw new Error(`Erro no endpoint findCursoById - ${error.message}`);
    }
  },
  async editCurso(curso, id) {
    try {
      await db("cursos").update(curso).where("id", id);
    } catch (error) {
      throw new Error(`Erro no endpoint findCursoById - ${error.message}`);
    }
  },
};

module.exports = Curso;
