const db = require("../config/db");
const { formatDate, formatDatetime } = require('../utils')

const Resposta = {
  async createResposta(resposta) {
    try {
      const respostaId = await db("respostas").insert(resposta);
      return respostaId[0];
    } catch (error) {
      throw new Error(`Erro no endpoint createResposta - ${error.message}`);
    }
  },
};

module.exports = Resposta;