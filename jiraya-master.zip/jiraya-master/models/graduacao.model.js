const db = require("../config/db");

const Graduacao = {
  async createGraduacao(graduacao) {
    try {
      await db("ufpa_graduacao").insert(graduacao);
    } catch (error) {
      throw new Error(`Erro no endpoint createGraduacao - ${error.message}`);
    }
  },
  async findAllGraduacao(param) {
    try {
      const [count, getGraduacao] = [
        await db("ufpa_graduacao")
          .count("id as count")
          .where("nome", "like", `%${param.nome}%`)
          .first(),

        await db("ufpa_graduacao")
          .select()
          .where("nome", "like", `%${param.nome}%`)
          .orderBy("id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const graduacao = {
        data: getGraduacao,
        ...count,
      };
      return graduacao;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllGraduacao - ${error.message}`);
    }
  },
  async findGraduacaoById(id) {
    try {
      const graduacao = await db("graduacao").where("id", id).select().first();
      return graduacao;
    } catch (error) {
      throw new Error(`Erro no endpoint findGraduacaoById - ${error.message}`);
    }
  },
};

module.exports = Graduacao;
