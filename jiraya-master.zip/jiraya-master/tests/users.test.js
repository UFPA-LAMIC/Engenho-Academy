const request = require("supertest");
const ApiUrl = "http://localhost:3006";

describe("POST /users", () => {
    afterAll(() => {
        return request(ApiUrl).del('/user').query({ email:"cardeal2@ufpa.br" })
    })
  it("should create a user", () => {
    const user = {
        nome:"Iglan Cardeal",
        email:"cardeal2@ufpa.br",
        password:"123456",
        "confirmPassword":"123456",
        tipo:"DISCENTE",
        dt_nascimento:"1992-08-02"
    }
    return request(ApiUrl)
      .post("/users")
      .send(user)
      .expect(200)
      .then(() => {
        return request(ApiUrl)
        .get("/users")
        .query({ email:"cardeal2@ufpa.br" })
        .expect(200)
      });
    });

  it("should create a user that already exists", () => {
    const user = {
        nome:"Iglan Cardeal",
        email:"renan@ufpa.br",
        password:"123456",
        "confirmPassword":"123456",
        tipo:"DISCENTE",
        dt_nascimento:"1992-08-02"
    }
    return request(ApiUrl)
      .post("/users")
      .send(user)
      .expect(400)
      .then(response => {
        expect(response.text).toEqual('Usuário já cadastrado!');
      });
    });
}),

describe("GET /users/{id}", () => {

  it("should return 200 and check user email is 'rapha@ufpa.br'", () => {
    return request(ApiUrl)
      .get("/users/1")
      .expect(200)
      .then(response => {
        expect(response.body.data.email).toEqual("rapha@ufpa.br");
      });
  });

  it("should return 404 with 'The user was not found'", () => {
    return request(ApiUrl)
      .get("/users/121212")
      .expect(200)
      .then(response => {
        expect(response.body).toEqual({});
      });
  });
});
