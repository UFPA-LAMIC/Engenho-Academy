-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: plataforma
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `avaliacoes`
--

DROP TABLE IF EXISTS `avaliacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avaliacoes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `tipo` enum('geral','estrelas','like') DEFAULT NULL,
  `nota` int DEFAULT NULL,
  `opiniao` text,
  `curso` int unsigned DEFAULT NULL,
  `autor` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `avaliacoes_curso_foreign` (`curso`),
  KEY `avaliacoes_autor_foreign` (`autor`),
  CONSTRAINT `avaliacoes_autor_foreign` FOREIGN KEY (`autor`) REFERENCES `users` (`id`),
  CONSTRAINT `avaliacoes_curso_foreign` FOREIGN KEY (`curso`) REFERENCES `cursos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avaliacoes`
--

LOCK TABLES `avaliacoes` WRITE;
/*!40000 ALTER TABLE `avaliacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `avaliacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cursos`
--

DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `nome` varchar(255) DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `aprendizado` text,
  `descricao` text,
  `color` varchar(20) DEFAULT '#CCC',
  `docente` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cursos_docente_foreign` (`docente`),
  CONSTRAINT `cursos_docente_foreign` FOREIGN KEY (`docente`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursos`
--

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
INSERT INTO `cursos` VALUES (1,'2025-02-25 22:38:35','Direito Administrativo','2023-10-08','2023-10-12',NULL,'Conheça o conteúdo do curso Direito Administrativo voltado a Gestão Pública - Princípios do Direito Administrativo: legalidade, supremacia do interesse público e publicidade - Princípios do Direito Administrativo: continuidade do serviços público, moralidade administrativa, eficiência e segurança jurídica - Administração Indireta - Conceito e elementos do serviço público - Classificação e formas de gestão do serviço público - Cargo, emprego e função pública - Regime jurídico dos servidores públicos - Conceitos e classificação dos atos administrativos - Atributos dos atos administrativos - Extinção dos atos administrativos - Poderes da Administração Pública - Fundamentos da intervenção na propriedade privada - Modalidades de intervenção na propriedade - Desapropriação - Intervenção do Estado no domínio econômico - Características e prerrogativas de Direito Público Administrativo','#CCC',4),(2,'2025-02-25 22:38:35','Java - Entendendo o conceito básico da linguagem','2023-04-02','2023-08-12','<p>No curso de Java para iniciantes, o aluno aprenderá os conceitos fundamentais da linguagem, incluindo sintaxe básica, variáveis, operadores, estruturas de controle, laços de repetição e manipulação de dados. Além disso, serão abordados os princípios da programação orientada a objetos, como classes, objetos, herança, polimorfismo e encapsulamento. O curso também inclui a criação de pequenos projetos práticos para reforçar o aprendizado, além de introduzir boas práticas de programação e o uso de ferramentas essenciais, como o ambiente de desenvolvimento integrado (IDE) e o Java Development Kit (JDK).</p>','<p>Este é o único curso em que você vai contar não só com vídeo aulas, mas também com material de apoio específico para TODOS capítulos, inúmeros exercícios resolvidos e também exercícios propostos com correção, cobertura de aspectos de design com diagramas UML, e a melhor didática baseada na associação aula / conteúdo do material de apoio / versões do Github. O curso é constantemente atualizado com novos conteúdos, e nós garantimos que ele estará sempre atualizado para a última versão LTS (Long Term Support) do Java, que atualmente é a versão 11 (lembre-se que, embora as versões 12 e 13 já estejam disponíveis, estas são versões de curta duração, que serão retiradas de circulação em poucos meses, assim como foi com as versões 9 e 10).</p>','#CCC',4),(3,'2025-02-25 22:38:35','Aprenda Arduino usando o simulador Tinkercad','2023-05-22','2023-07-06','<p>No curso de Arduino para iniciantes, os alunos aprenderão os conceitos básicos de eletrônica e programação voltados para o desenvolvimento de projetos interativos com a plataforma Arduino. Serão abordados temas como configuração do ambiente de desenvolvimento (IDE Arduino), estrutura e sintaxe da linguagem de programação, uso de sensores e atuadores, e comunicação com dispositivos externos. Além disso, os alunos desenvolverão projetos práticos para entender na prática como funcionam circuitos, entradas e saídas digitais, PWM, e comunicação serial.</p>','<p>O Arduino é uma plataforma muito popular atualmente. Criada inicialmente para facilitar a programação de microcontroladores, hoje é usada em diversas áreas tanto para prototipagem quanto para pesquisas. Apesar de ter uma grande quantidade de bibliotecas, que facilitam em muito o desenvolvimento de projetos, os primeiros passos podem ser um poucos frustrantes se você não tiver habituado na programação em linguagem C/C++ ou programação de microcontroladores. Esse curso foi criado para ajudar os iniciantes na plataforma Arduino a quebrarem as barreiras iniciais na plataforma. O uso de uma plataforma de simulação gratuita lhe ajudará a entender os fundamentos essenciais da plataforma Arduino. Assim, quando você for usar a placa física e criar seus próprios projetos, já terá uma base sólida de conhecimento.</p>','#CCC',4),(5,'2025-02-26 01:41:23','Circuitos elétricos I',NULL,NULL,'<p>No curso de Circuitos Elétricos 1, os alunos aprenderão os fundamentos da eletricidade, incluindo conceitos como corrente, tensão e resistência, além das leis de Ohm e Kirchhoff. Serão abordadas técnicas de análise de circuitos em corrente contínua (CC) e corrente alternada (CA), o funcionamento de componentes como resistores, capacitores e indutores, e a aplicação de teoremas fundamentais, como Thevenin e Norton. O curso também inclui simulações e experimentos práticos para reforçar o aprendizado teórico.</p>','<p>Este curso é essencial para quem deseja compreender o funcionamento básico dos circuitos elétricos e suas aplicações em engenharia e tecnologia. Com uma abordagem didática e progressiva, ele prepara os alunos para interpretar esquemas elétricos, resolver problemas de circuitos e aplicar os conhecimentos adquiridos em projetos práticos. Ideal para estudantes de engenharia elétrica, eletrônica e áreas afins, o curso estabelece uma base sólida para disciplinas mais avançadas na área.</p>','#CCC',2),(6,'2025-02-26 01:59:09','Curso de redes de computadores',NULL,NULL,'<p>Neste curso de Redes de Computadores, os alunos aprenderão os conceitos fundamentais sobre comunicação de dados, topologias de redes, protocolos e modelos de arquitetura como o TCP/IP e o OSI. Além disso, serão abordadas configurações de dispositivos de rede, como roteadores e switches, segurança em redes, administração de servidores e serviços essenciais, como DHCP, DNS e VPNs. O curso também incluirá práticas de troubleshooting e monitoramento para garantir um funcionamento eficiente das redes.</p>','<p>O curso de Redes de Computadores oferece uma abordagem teórica e prática para capacitar os alunos no planejamento, implantação e manutenção de redes de diferentes portes. Com uma metodologia dinâmica, ele prepara os participantes para atuar no mercado de TI, fornecendo habilidades essenciais para trabalhar com infraestrutura de redes corporativas, segurança da informação e conectividade. Ideal para quem deseja ingressar ou se especializar na área de tecnologia, o curso cobre desde os fundamentos até temas avançados, alinhados às demandas do setor.</p>','#CCC',2),(7,'2025-02-26 02:03:46','Curso de excel',NULL,NULL,'<p>No curso de Excel, os alunos aprenderão desde os conceitos básicos até funcionalidades avançadas da ferramenta, incluindo a criação e formatação de planilhas, uso de fórmulas e funções, organização e análise de dados, além da geração de gráficos dinâmicos. Também serão explorados recursos como tabelas dinâmicas, filtros, validação de dados e automação de tarefas com macros, proporcionando uma experiência completa para melhorar a produtividade e a eficiência no uso do Excel.</p>','<p>O curso de Excel é ideal para quem deseja desenvolver habilidades essenciais em manipulação de dados, seja para uso acadêmico, profissional ou pessoal. Com uma abordagem prática e objetiva, os alunos serão capacitados a utilizar o Excel para organizar informações, realizar cálculos avançados e interpretar dados de forma clara e eficiente. Voltado para iniciantes e usuários que desejam aprimorar seus conhecimentos, o curso oferece um aprendizado progressivo, garantindo que cada aluno possa dominar a ferramenta com confiança.</p>','#CCC',2);
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matricula`
--

DROP TABLE IF EXISTS `matricula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matricula` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `curso` int unsigned DEFAULT NULL,
  `aluno` int unsigned DEFAULT NULL,
  `status` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matricula_curso_foreign` (`curso`),
  KEY `matricula_aluno_foreign` (`aluno`),
  CONSTRAINT `matricula_aluno_foreign` FOREIGN KEY (`aluno`) REFERENCES `users` (`id`),
  CONSTRAINT `matricula_curso_foreign` FOREIGN KEY (`curso`) REFERENCES `cursos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matricula`
--

LOCK TABLES `matricula` WRITE;
/*!40000 ALTER TABLE `matricula` DISABLE KEYS */;
INSERT INTO `matricula` VALUES (1,'2025-02-26 00:22:53',3,6,1),(2,'2025-02-26 01:12:26',3,4,1),(3,'2025-02-26 01:44:00',5,2,1),(4,'2025-02-26 01:59:13',6,2,1),(5,'2025-02-26 02:03:57',7,2,1),(6,'2025-02-26 02:08:52',2,4,1),(7,'2025-02-26 02:18:01',5,6,1),(8,'2025-02-26 02:18:05',6,6,1),(9,'2025-02-26 02:18:10',7,6,1),(10,'2025-02-26 02:18:19',2,6,1);
/*!40000 ALTER TABLE `matricula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `batch` int DEFAULT NULL,
  `migration_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (12,'00_ufpa_graduacao.js',1,'2025-02-25 19:33:36'),(13,'20220226232141_table_users.js',1,'2025-02-25 19:33:37'),(14,'20220226232200_table_cursos.js',1,'2025-02-25 19:33:37'),(15,'20220227000047_table_matricula.js',1,'2025-02-25 19:33:38'),(16,'20220313153243_table_videos.js',1,'2025-02-25 19:33:39'),(17,'20220327132543_table_perguntas.js',1,'2025-02-25 19:33:39'),(18,'20220327132549_table_respostas.js',1,'2025-02-25 19:33:40'),(19,'20220910025419_table_quiz.js',1,'2025-02-25 19:33:40'),(20,'20220910182214_table_quiz_answer.js',1,'2025-02-25 19:33:41'),(21,'20221007033111_table_avaliacao.js',1,'2025-02-25 19:33:41'),(22,'20231014000845_pergunta_resposta.js',1,'2025-02-25 19:33:42');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations_lock`
--

DROP TABLE IF EXISTS `migrations_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations_lock` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `is_locked` int DEFAULT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations_lock`
--

LOCK TABLES `migrations_lock` WRITE;
/*!40000 ALTER TABLE `migrations_lock` DISABLE KEYS */;
INSERT INTO `migrations_lock` VALUES (1,0);
/*!40000 ALTER TABLE `migrations_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pergunta_resposta`
--

DROP TABLE IF EXISTS `pergunta_resposta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pergunta_resposta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `id_pergunta` int unsigned DEFAULT NULL,
  `id_resposta` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pergunta_resposta_id_pergunta_foreign` (`id_pergunta`),
  KEY `pergunta_resposta_id_resposta_foreign` (`id_resposta`),
  CONSTRAINT `pergunta_resposta_id_pergunta_foreign` FOREIGN KEY (`id_pergunta`) REFERENCES `perguntas` (`id`),
  CONSTRAINT `pergunta_resposta_id_resposta_foreign` FOREIGN KEY (`id_resposta`) REFERENCES `respostas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pergunta_resposta`
--

LOCK TABLES `pergunta_resposta` WRITE;
/*!40000 ALTER TABLE `pergunta_resposta` DISABLE KEYS */;
/*!40000 ALTER TABLE `pergunta_resposta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perguntas`
--

DROP TABLE IF EXISTS `perguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `perguntas` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `pergunta` text,
  `autor` int unsigned DEFAULT NULL,
  `video` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `perguntas_autor_foreign` (`autor`),
  KEY `perguntas_video_foreign` (`video`),
  CONSTRAINT `perguntas_autor_foreign` FOREIGN KEY (`autor`) REFERENCES `users` (`id`),
  CONSTRAINT `perguntas_video_foreign` FOREIGN KEY (`video`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perguntas`
--

LOCK TABLES `perguntas` WRITE;
/*!40000 ALTER TABLE `perguntas` DISABLE KEYS */;
INSERT INTO `perguntas` VALUES (1,'2025-02-25 22:38:45','O que é polimorfismo em java?',1,NULL),(2,'2025-02-25 22:38:45','O que é o herança em java?',3,NULL),(3,'2025-02-25 22:38:45','O que é O protocolo TCP/IP ?',1,NULL),(4,'2025-02-25 22:38:45','Por que a cortina é azul ?',3,NULL);
/*!40000 ALTER TABLE `perguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `question` text,
  `optionA` text,
  `optionB` text,
  `optionC` text,
  `optionD` text,
  `answer` int DEFAULT NULL,
  `id_video` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_id_video_foreign` (`id_video`),
  CONSTRAINT `quiz_id_video_foreign` FOREIGN KEY (`id_video`) REFERENCES `videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_answer`
--

DROP TABLE IF EXISTS `quiz_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_answer` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `selected` int DEFAULT NULL,
  `score` varchar(255) DEFAULT NULL,
  `aluno` int unsigned DEFAULT NULL,
  `id_quiz_question` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_answer_aluno_foreign` (`aluno`),
  KEY `quiz_answer_id_quiz_question_foreign` (`id_quiz_question`),
  CONSTRAINT `quiz_answer_aluno_foreign` FOREIGN KEY (`aluno`) REFERENCES `users` (`id`),
  CONSTRAINT `quiz_answer_id_quiz_question_foreign` FOREIGN KEY (`id_quiz_question`) REFERENCES `quiz` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_answer`
--

LOCK TABLES `quiz_answer` WRITE;
/*!40000 ALTER TABLE `quiz_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respostas`
--

DROP TABLE IF EXISTS `respostas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `respostas` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `resposta` text,
  `autor` int unsigned DEFAULT NULL,
  `id_pergunta` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `respostas_autor_foreign` (`autor`),
  KEY `respostas_id_pergunta_foreign` (`id_pergunta`),
  CONSTRAINT `respostas_autor_foreign` FOREIGN KEY (`autor`) REFERENCES `users` (`id`),
  CONSTRAINT `respostas_id_pergunta_foreign` FOREIGN KEY (`id_pergunta`) REFERENCES `perguntas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respostas`
--

LOCK TABLES `respostas` WRITE;
/*!40000 ALTER TABLE `respostas` DISABLE KEYS */;
INSERT INTO `respostas` VALUES (1,'2025-02-25 22:38:50','O polimorfismo é um dos conceitos fundamentais da programação orientada a objetos (POO) e é amplamente utilizado em Java. O termo polimorfismo se refere à capacidade de um objeto assumir diferentes formas, ou seja, uma mesma operação pode ser realizada por diferentes objetos de classes diferentes',2,1),(2,'2025-02-25 22:38:50','Em Java, a herança é um conceito fundamental da programação orientada a objetos (POO). Ela permite que uma classe (a classe filha ou subclasse) herde os atributos e métodos de outra classe (a classe pai ou superclasse). A herança é uma maneira de reutilizar código e estabelecer uma hierarquia de classes.',4,2),(3,'2025-02-25 22:38:50','É um conjunto de protocolos de comunicação utilizados para conectar dispositivos em redes, incluindo a Internet. Ele fornece um conjunto de regras e convenções para que computadores possam se comunicar uns com os outros em redes de forma confiável e eficiente. O TCP/IP é composto por dois protocolos principais: o Protocolo de Controle de Transmissão (TCP) e o Protocolo de Internet (IP). Outros protocolos complementares também fazem parte do conjunto TCP/IP.',4,3),(4,'2025-02-25 22:38:50','A herança em Java ajuda a promover a reutilização de código, a organização de classes em uma hierarquia lógica e a criação de classes mais especializadas a partir de classes mais gerais. No entanto, é importante usá-la com cuidado, pois uma hierarquia de classes muito profunda pode tornar o código mais complexo e difícil de manter.',1,2),(5,'2025-02-25 22:38:50','O TCP é responsável por estabelecer uma conexão confiável entre dois dispositivos na rede. Ele divide os dados em pacotes, os envia e garante que eles sejam entregues na ordem correta e sem erros. Se um pacote é perdido ou corrompido durante a transmissão, o TCP reenvia o pacote para garantir a entrega confiável dos dados.',2,3),(6,'2025-02-25 22:38:50','O IP é responsável pelo roteamento dos pacotes de dados através da rede. Ele atribui endereços IP exclusivos a cada dispositivo na rede para que os dados possam ser encaminhados de forma eficiente de origem para destino. O IP divide os dados em pacotes e adiciona informações de cabeçalho, incluindo o endereço de origem e o endereço de destino, para permitir que os roteadores direcionem os pacotes para seus destinos corretos.',1,3),(7,'2025-02-25 22:38:50','Além do TCP e do IP, o conjunto de protocolos TCP/IP inclui muitos outros protocolos e serviços, como o Protocolo de Controle de Mensagens (ICMP) para gerenciar mensagens de erro e notificação, o Protocolo de Resolução de Endereços (ARP) para mapear endereços IP para endereços de hardware e muitos outros.',2,3),(8,'2025-02-25 22:38:50','A frase \"por que a cortina é azul?\" é uma referência a uma cena do filme \"Pulp Fiction\" (1994), dirigido por Quentin Tarantino. Nessa cena, o personagem Jules, interpretado por Samuel L. Jackson, pergunta a outro personagem por que a cortina de uma casa é azul de maneira um tanto agressiva e filosófica.',3,4),(9,'2025-02-25 22:38:50','Há também o Polimorfismo de tempo de compilação (ou estático): Este tipo de polimorfismo ocorre durante a compilação. Ele está relacionado à sobrecarga de métodos, onde várias versões do mesmo método podem ser chamadas com base nos argumentos passados. O compilador decide qual versão do método chamar com base na assinatura do método. Isso é resolvido em tempo de compilação e é conhecido como ligação estática.',4,1);
/*!40000 ALTER TABLE `respostas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ufpa_graduacao`
--

DROP TABLE IF EXISTS `ufpa_graduacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ufpa_graduacao` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `codigo` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ufpa_graduacao`
--

LOCK TABLES `ufpa_graduacao` WRITE;
/*!40000 ALTER TABLE `ufpa_graduacao` DISABLE KEYS */;
INSERT INTO `ufpa_graduacao` VALUES (1,'Engenharia da Computação','00108'),(2,'Engenharia de Telecomunicações','00109'),(3,'Engenharia Elétrica','00102'),(4,'Contabilidade','00705'),(5,'Engenharia da Computação','00108'),(6,'Engenharia de Telecomunicações','00109'),(7,'Engenharia Elétrica','00102'),(8,'Contabilidade','00705'),(9,'Engenharia da Computação','00108'),(10,'Engenharia de Telecomunicações','00109'),(11,'Engenharia Elétrica','00102'),(12,'Contabilidade','00705');
/*!40000 ALTER TABLE `ufpa_graduacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_tipo` int DEFAULT '1',
  `tipo` varchar(255) DEFAULT 'DISCENTE',
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `dt_nascimento` date DEFAULT NULL,
  `pcd` tinyint(1) DEFAULT '0',
  `pne` enum('VISUAL','MOTORA') DEFAULT NULL,
  `graduacao` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_graduacao_foreign` (`graduacao`),
  CONSTRAINT `users_graduacao_foreign` FOREIGN KEY (`graduacao`) REFERENCES `ufpa_graduacao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2025-02-25 22:38:14',1,'DISCENTE','Luan Paiva','luan@ufpa.br','$2b$10$jIh/BEZcdF1flppZQxKWV.b.zMrgMwzy0spcZehjUj19k/bVh2t6e',NULL,0,NULL,1),(2,'2025-02-25 22:38:14',99,'DOCENTE','Agostinho Castro','agostinho@ufpa.br','$2b$10$jIh/BEZcdF1flppZQxKWV.b.zMrgMwzy0spcZehjUj19k/bVh2t6e',NULL,0,NULL,4),(3,'2025-02-25 22:38:14',1,'DISCENTE','Thomas','thomas@ufpa.br','$2b$10$jIh/BEZcdF1flppZQxKWV.b.zMrgMwzy0spcZehjUj19k/bVh2t6e',NULL,0,NULL,1),(4,'2025-02-25 22:38:14',99,'DOCENTE','Raphaela Gallo','gallo@ufpa.br','$2b$10$jIh/BEZcdF1flppZQxKWV.b.zMrgMwzy0spcZehjUj19k/bVh2t6e',NULL,0,NULL,4),(6,'2025-02-26 00:22:27',1,'DISCENTE','Gabriel','gabrielsilva12ps3@gmail.com','$2b$10$vMKcqaH9PaRuA7ITey8BnOn/WNyWrvXQrDVYn0EgoYS/.JSdQfAQq','2001-11-10',0,NULL,10);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dth_sistema` datetime DEFAULT CURRENT_TIMESTAMP,
  `titulo` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `ordem` int DEFAULT NULL,
  `curso` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `videos_curso_foreign` (`curso`),
  CONSTRAINT `videos_curso_foreign` FOREIGN KEY (`curso`) REFERENCES `cursos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` VALUES (1,'2025-02-25 22:38:59','Aula 1 Curso de Java 2023','https://www.youtube.com/embed/R4Xte53PKwA?si=zmptAkXJeFwmIf4I',1,3),(2,'2025-02-25 22:38:59','Aula 2 Java 2023 (Variável int, operações matemáticas e concatenação)','https://www.youtube.com/embed/8EuBDQbc5WU?si=UeKHpuyFHxL7pkAB',2,3),(3,'2025-02-25 22:38:59','Aula 3 JAVA 2023 ( tipo flutuante , double)','https://www.youtube.com/embed/K6Ynbw4cBnA?si=LAqQ6KQIYXW-_Egw',3,3),(4,'2025-02-25 22:38:59','Aula 4 JAVA 2023 (Cast e tipos de variáveis numéricas)','https://www.youtube.com/embed/r5wNDhaPdfI?si=fnSAjmxj04YwRSO-',4,3),(5,'2025-02-26 01:45:33','Variáveis e elementos de circuitos(Capítulo 1 parte 1).','https://www.youtube.com/embed/zk5idX0qq2I?si=v8Q6rfcZFCdXUWGR',1,5),(6,'2025-02-26 01:48:08','Variáveis e elementos de circuitos(Capítulo 1 parte 2).','https://www.youtube.com/embed/j8OJ1nZ13SU?si=eBXGd0LqwoZnLE-H',2,5),(7,'2025-02-26 01:48:47','Variáveis e elementos de circuitos(Capítulo 1 parte 3).','https://www.youtube.com/embed/eMXZXdw_jpg?si=TgQKVWnxzbun5qGv',3,5),(8,'2025-02-26 01:49:16','Variáveis e elementos de circuitos(Capítulo 1 parte 4).','https://www.youtube.com/embed/h-J7IMHw5DM?si=QY4N9dLSgeO5wbFW',4,5),(9,'2025-02-26 01:49:54','Variáveis e elementos de circuitos(Capítulo 1 parte 5).','https://www.youtube.com/embed/1wmYBFcrwR8?si=DtxQ4KQBEX7I50Mm',5,5),(10,'2025-02-26 01:50:25','Variáveis e elementos de circuitos(Capítulo 1 parte 6).','https://www.youtube.com/embed/7sNFYET8Mro?si=0P-uaEIAbeO_B8Vj',6,5),(11,'2025-02-26 01:51:02','Capitulo 1 parte final','https://www.youtube.com/embed/QXIa59eFHB8?si=3OnbnmcKb7ir8QjH',7,5),(12,'2025-02-26 01:51:38','Circuitos resistivos(capítulo 2 parte 1)','https://www.youtube.com/embed/pl4MQZ_G540?si=kugHl3RYIBeqswmO',8,5),(13,'2025-02-26 01:53:00','Teoremas de circuitos(capítulo 3 parte 1)','https://www.youtube.com/embed/egPYT98ohvQ?si=uYLb5dOWOostOYTT\" ',9,5),(14,'2025-02-26 01:54:04','Teoremas de circuitos(capítulo 3 parte 2).','https://www.youtube.com/embed/5HqvCUCR5IA?si=JgEDvAEAtlbB59pr',10,5),(15,'2025-02-26 01:55:17','Teoremas de circuitos(capítulo 3 parte 3).','https://www.youtube.com/embed/2PmsgEPqpyc?si=_uDobJdTyyfTQRBq',11,5),(16,'2025-02-26 01:56:03','Teoremas de circuitos(capítulo 3 exercícios).','https://www.youtube.com/embed/9ieFVZ1Thr8?si=0PSEuTToOa1FAArG',12,5),(17,'2025-02-26 01:56:31','Teoremas de circuitos(capítulo 3 parte 4)','https://www.youtube.com/embed/3i6jHs_fRyk?si=VeIw8PtqDdDKl_m2',13,5),(18,'2025-02-26 01:57:06','1º Momento Assíncrono.','https://www.youtube.com/embed/pzrG1MyfOvM?si=TH3iecJHKeyc97N1',14,5),(19,'2025-02-26 01:58:12','2º Momento Assíncrono','https://www.youtube.com/embed/ZBqirN_ZznQ?si=6x8ullYtFPUL7Xp3',15,5),(20,'2025-02-26 01:59:58','Curso de Redes de Computadores - Aula 1','https://www.youtube.com/embed/pGtlDQ-c9-0?si=HVF6lQj2uwl6DAEi',1,6),(21,'2025-02-26 02:00:19','Curso de Redes de Computadores - Aula 2','https://www.youtube.com/embed/xeQvNWlt6So?si=_cP9FMdEKOyl6uov',2,6),(22,'2025-02-26 02:01:01','Curso de Redes de Computadores - Aula 3','https://www.youtube.com/embed/caKhuBXpJsI?si=gKtf-9OtwnXZc5mr ',3,6),(23,'2025-02-26 02:01:41','Curso de Redes de Computadores - Aula 4','https://www.youtube.com/embed/3DwHf1PJg14?si=JGNZjZL1YVgFCaR8',4,6),(24,'2025-02-26 02:02:28','Curso de Redes de Computadores - Aula 5','https://www.youtube.com/embed/09OHm9A5s_w?si=eYYzHdUnuZJxcloq',5,6),(25,'2025-02-26 02:04:39','Curso Excel | AULA 01 | Introdução ao Excel','https://www.youtube.com/embed/qQLT_uoMN0U?si=1P-dQfKDuwUHqiDr',1,7),(26,'2025-02-26 02:05:02','Curso Excel | AULA 02 | Operando na Planilha','https://www.youtube.com/embed/7h5ZesJZ9o8?si=XY4M3xTm1AuyxVvR',2,7),(27,'2025-02-26 02:05:44','Curso Excel | AULA 03 | Formatando sua Planilha','https://www.youtube.com/embed/Qj5ar291SHM?si=_7F5yVeJE6NsXg55',3,7),(28,'2025-02-26 02:06:10','Curso Excel | AULA 04 | Formatando Planilha como Tabela','https://www.youtube.com/embed/ksT1bSwzreo?si=yJcTWaWPSC13l58m',4,7),(29,'2025-02-26 02:06:35','Curso Excel | AULA 05 | Fórmulas no Excel','https://www.youtube.com/embed/tetFYM7Eu_o?si=8-UAQVF3dvo1nj4X',5,7),(30,'2025-02-26 02:10:33','CURSO DE JAVA PARA INICIANTES - BEM-VINDO #01','https://www.youtube.com/embed/mRryrODqQcw?si=hxlar9IpGmiQ_yqR',1,2),(31,'2025-02-26 02:10:56','CURSO DE JAVA PARA INICIANTES - FUNDAMENTOS DE PROGRAMAÇÃO #02','https://www.youtube.com/embed/o5H2LYuHM1I?si=ucTYbwbHjctiKqRc',2,2),(32,'2025-02-26 02:11:52','COMO INSTALAR O JAVA JDK E INTELLIJ NO WINDOWS - CURSO DE JAVA PARA INICIANTES #03.1','https://www.youtube.com/embed/ebEhe5NBUw4?si=i4sld96vqGOwMmyA',3,2),(33,'2025-02-26 02:12:49','CURSO DE JAVA PARA INICIANTES - INSTALANDO JAVA JDK E IDE NO MACOS #03.2','https://www.youtube.com/embed/-uwh4GWJBqc?si=ygo_JA-7HFfVikkI',4,2),(34,'2025-02-26 02:15:45','CURSO DE JAVA PARA INICIANTES - PRIMEIRO PROGRAMA JAVA #04','https://www.youtube.com/embed/QO5ItC3KqJg?si=5JfdpGOIvHBu_jef',5,2),(35,'2025-02-26 02:16:55','CURSO DE JAVA PARA INICIANTES - PROGRAMAÇÃO DINÂMICA COM VARIÁVEIS #05','https://www.youtube.com/embed/BLMu7ebMC1A?si=9A30lVkGcJbhLSJ2',6,2);
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'plataforma'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-25 23:32:18
