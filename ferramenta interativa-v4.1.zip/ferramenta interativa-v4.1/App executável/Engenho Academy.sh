#!/bin/bash
xdg-open http://192.168.3.13:8080/

#rodar o seguinte comando no terminal:chmod +x abrir_link.sh para tornar executavel
#para add icon 1️⃣ No Linux, crie um arquivo abrir_link.desktop no VS Code ou outro editor de texto, com este conteúdo:


[Desktop Entry]
Version=1.0
Type=Application
Name=Abrir Link
Exec=/caminho/para/abrir_link.sh
Icon=firefox
Terminal=false
2️⃣ Salve esse arquivo em ~/.local/share/applications/ ou na Área de Trabalho.

3️⃣ Torne o atalho executável:


chmod +x ~/.local/share/applications/abrir_link.desktop
Se estiver na Área de Trabalho, pode precisar rodar:


chmod +x ~/Área\ de\ Trabalho/abrir_link.desktop
Agora, basta dar dois cliques no atalho e ele abrirá o link no navegador, como se fosse um aplicativo!
