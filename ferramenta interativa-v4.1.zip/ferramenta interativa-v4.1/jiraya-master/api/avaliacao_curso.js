module.exports = (app) => {
  const getCourseRates = async (req, res, next) => {
    try {
      let { curso } = req.query

      const page = req.query.page
      const limit = req.query.limit
      const orderBy = req.query.orderBy

      const model = app
        .db('avaliacao_curso')
        .select()
        .where('curso', '=', `${curso}`)

      const ratePromise = model
        .clone()
        .orderBy('id', orderBy)
        .limit(limit)
        .offset(page * limit - limit)
      const counterPromise = model.clone().count('id as count')

      const [rates, counter] = await Promise.all([
        ratePromise,
        counterPromise,
      ])

      const totalCount = counter[0]['count']

      const media = rates.map(e => e.nota).reduce((previous, current) => previous + current, 0)/rates.length

      res.json({
        data: rates, 
        count: totalCount,
        media,
        limit,
      })
    } catch (error) {
      next(error)
    }
  }

  const getMetrics = async (req, res, next) => {
    try {
      const { curso } = req.query

      const model = await app
        .db('avaliacao_curso')
        .where('curso', '=', `${curso}`)
        .join('cursos', 'avaliacao_curso.curso', '=', 'cursos.id')
        .select('avaliacao_curso.*', 'cursos.nome')
      if(model.length > 0) {
        const countOne = model.filter(item => item.nota === 1).length;
        const countTwo = model.filter(item => item.nota === 2).length;
        const countThree = model.filter(item => item.nota === 3).length;
        const countFour = model.filter(item => item.nota === 4).length;
        const countFive = model.filter(item => item.nota === 5).length
        const courseName = model[0].nome
        let arr = [
          {nota:'1', total: countOne}, 
          {nota:'2', total:countTwo},
          {nota:'3', total:countThree},
          {nota:'4', total:countFour},
          {nota:'5', total:countFive},
        ]
        res.json({data: arr, nome: courseName})
        return
      }
      res.json({data: model})
    } catch (error) {
      next(error)
    }
  }

  const getByAluno = async (req, res, next) => {
    let { curso, aluno } = req.query
      try {  
        let model = await app
          .db('avaliacao_curso')
          .where('curso', '=', `${curso}`)
          .where('aluno', '=', `${aluno}`)
          .select()
          .first()

          // if(Object.keys(model).length > 0) {
          //   model.nota = 0
          //  }
          if(!model) {
            model = { nota: 0 }
          res.json(model)
          return
        }
        res.json(model)
      } catch (error) {
        next(error)
      }
  }

  const getById = async (req, res, next) => {
    app
      .db('avaliacao_curso')
      .select()
      .table('avaliacao_curso')
      .where({ id: req.params.id })
      .first()
      .then((q) => {
        const [date, time] = q.dth_sistema.split(' ')
        const dateFormated = date.split('-').reverse().join('/')

        const formatedDtsistema = dateFormated + ' ' + time

        res.json({
          ...q,
          dth_sistema: formatedDtsistema,
        })
      })
      .catch((err) => next(err))
  }

  const ratingCourse = async (req, res, next) => {
    try {
      const answer = { ...req.body }

      const status = await app
        .db('avaliacao_curso')
        .insert(answer)
      res.json(status)
    } catch (error) {
      next(error)
    }
  }

  const UpdateRatingCourse = async (req, res, next) => {
    try {
      let { curso, aluno } = req.query
      const answer = { ...req.body }

      const status = await app
        .db('avaliacao_curso')
        .where('curso', '=', `${curso}`)
        .where('aluno', '=', `${aluno}`)
        .update(answer)
      res.json({
        data: status,
      })
    } catch (error) {
      next(error)
    }
  }

  return { getCourseRates, getById, ratingCourse, UpdateRatingCourse, getByAluno, getMetrics }
}