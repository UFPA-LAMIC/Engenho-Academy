const validStates = ['OK', 'ERROR', '']

exports.validateState = (state = '') => {
  state = state.toString().trim().toUpperCase()
  if (!validStates.includes(state)) return null
  return state
}
