exports.validateOrderBy = (order = '') => {
  const validOrders = ['desc', 'asc']
  if (!validOrders.includes(order.trim())) return 'desc'
  return order.trim()
}
