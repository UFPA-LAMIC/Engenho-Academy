module.exports = (app) => {
    const limit = 25;
    
    const getComment = async (req, res) => {
      try {
        const page = req.query.page || 1;
        const result = await app
          .db("comentario")
          .count("id as count")
          .first();
        const count = parseInt(result.count);

        const comentarios = await app
          .db("comentario")
          .join("users", "comentario.autor", "=", "users.id")
          .select("comentario.*","users.email",)
          .limit(limit)
          .offset(page * limit - limit);
  
          const comentariosFormated = comentarios.map(form => {
            const [date, time] = form.dth_sistema.split(" ");
            const dataFormatada = date.split("-").reverse().join("/");
    
            const formatedDtsistema = dataFormatada + " " + time;
          
                  return { ...form, dth_sistema: formatedDtsistema };
                });
  
          res.json({ data: comentariosFormated, count, limit });
      } catch (error) {
        res.status(500).send(error);
        console.log(error)
      }
    };
  
    const getCommentById = async (req, res) => {
    
     const responsavel = await app
        .db("comentario")
        .join("users", "comentario.autor", "=", "users.id")
        .select("users.email");

      app
      .db("comentario")
        .select()
        .table("comentario")
        .where({ id: req.params.id })
        .first()
        .then((comentario) => {
          const [date, time] = comentario.dth_sistema.split(' ');
          const dateFormated = date.split("-").reverse().join("/");
          
          const formatedDtsistema = dateFormated + " " + time;
          
          res.json({ ...comentario, dth_sistema: formatedDtsistema, autor: responsavel });
        })
        .catch((err) => res.status(500).send(err));
      };
  
      const saveComment = async (req, res) => {
        try {
          const resposta = { ...req.body}
          const inserir = await app
            .db("comentario")
            .insert({...resposta})
          res.json(inserir)
        } catch (error) {
          res.status(500).send(error);
        }
      };
  
      const updateComment = async (req, res) => {
        try {
          const state = { ...req.body };
          console.log(state)
          const status = await app
            .db("comentario")
            .where({ id: state.id })
            .update({ 
              comentario: state.comentario,
              rank: state.rank,
              autor: state.autor
            });
            console.log(status)
          res.json(status);
        } catch (error) {
          res.status(500).send(error);
        }
      };
  
  
  return { getComment, getCommentById, saveComment, updateComment };
  
  }