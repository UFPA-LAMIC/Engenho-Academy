const knex_config = require("../knexfile.js");
const knex = require("knex");

const db = knex(knex_config);

module.exports = db