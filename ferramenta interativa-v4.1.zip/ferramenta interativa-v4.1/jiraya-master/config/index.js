const dotenv = require("dotenv")

dotenv.config()

module.exports = Object.freeze({
  env: process.env.NODE_ENV
})
