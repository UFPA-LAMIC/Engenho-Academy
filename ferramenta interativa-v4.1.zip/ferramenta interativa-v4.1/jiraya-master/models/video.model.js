const db = require("../config/db");

const Video = {
  async createVideo(video) {
    try {
      await db("videos").insert(video);
    } catch (error) {
      throw new Error(`Erro no endpoint createVideo - ${error.message}`);
    }
  },
  async findAllVideos(param) {
    try {
      const [count, getVideos] = [
        await db("videos")
          .count("id as count")
          .where("titulo", "like", `%${param.titulo}%`)
          .first(),

        await db("videos")
          .select()
          .where("titulo", "like", `%${param.titulo}%`)
          .orderBy("id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const videos = {
        data: getVideos,
        ...count,
      };
      return videos;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllVideo - ${error.message}`);
    }
  },
  async findAllVideosFromThatCourse(param, id) {
    try {
      const [count, getVideos] = [
        await db("videos")
          .count("id as count")
          .where("curso", id)
          .where("titulo", "like", `%${param.titulo}%`)
          .first(),

        await db("videos")
          .select()
          .where("curso", id)
          .where("titulo", "like", `%${param.titulo}%`)
          .orderBy("ordem", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const videos = {
        data: getVideos,
        ...count,
      };
      return videos;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllVideo - ${error.message}`);
    }
  },
  async findVideoById(id) {
    try {
      const video = await db("videos").where("id", id).select().first();
      return video;
    } catch (error) {
      throw new Error(`Erro no endpoint findVideoById - ${error.message}`);
    }
  },
  async editVideo(video, id) {
    try {
      await db("videos").update(video).where("id", id);
    } catch (error) {
      throw new Error(`Erro no endpoint findVideoById - ${error.message}`);
    }
  },
};

module.exports = Video;
