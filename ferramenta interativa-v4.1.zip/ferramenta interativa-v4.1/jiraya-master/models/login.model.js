const db = require("../config/db");

const Login = {
  async getLoggedUser(email) {
    try {
      const user = await db("users")
        .where("email", email)
        .select()
        .first();
      return user;
    } catch (error) {
      throw new Error(`Erro no endpoint findUserById - ${error.message}`);
    }
  },
};

module.exports = Login;
