exports.up = function (knex, Promise) {
    return knex.schema.createTable("quiz", (table) => {
      table.increments("id").primary();
      table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
      table.text("question");
      table.text("optionA");
      table.text("optionB");
      table.text("optionC");
      table.text("optionD");
      table.integer("answer");
      table.integer("id_video").unsigned();
      table.foreign("id_video").references("id").inTable("videos");
    });
  };
  
  exports.down = function (knex, Promise) {
    return knex.schema.dropTable("quiz");
  };
  