exports.up = function (knex, Promise) {
  return knex.schema.createTable("cursos", (table) => {
    table.increments("id").primary();
    table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
    table.string("nome");
    table.date("data_inicio");
    table.date("data_fim");
    table.text("aprendizado");
    table.text("descricao");
    table.string("color",20).defaultTo('#CCC')
    table.integer("docente").unsigned();
    table.foreign("docente").references("id").inTable("users");
  });
};

exports.down = function (knex, Promise) {
  return knex.schema.dropTable("cursos");
};
