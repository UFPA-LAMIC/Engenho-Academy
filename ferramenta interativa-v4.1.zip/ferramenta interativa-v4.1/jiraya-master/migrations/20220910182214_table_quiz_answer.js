exports.up = function (knex, Promise) {
    return knex.schema.createTable("quiz_answer", (table) => {
      table.increments("id").primary();
      table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
      table.integer("selected");
      table.string("score");
      table.integer("aluno").unsigned();
      table.foreign("aluno").references("id").inTable("users");
      table.integer("id_quiz_question").unsigned();
      table.foreign("id_quiz_question").references("id").inTable("quiz");
    });
  };
  
  exports.down = function (knex, Promise) {
    return knex.schema.dropTable("quiz_answer");
  };
  