exports.up = function (knex, Promise) {
  return knex.schema.createTable("avaliacoes", (table) => {
    table.increments("id").primary();
    table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
    table.enu("tipo", ["geral", "estrelas", "like"]);
    table.integer("nota");
    table.text("opiniao");
    table.integer("curso").unsigned();
    table.integer("autor").unsigned();
    table.foreign("curso").references("id").inTable("cursos");
    table.foreign("autor").references("id").inTable("users");
  });
};

exports.down = function (knex, Promise) {
  return knex.schema.dropTable("avaliacoes");
};
