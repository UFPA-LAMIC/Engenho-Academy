const express = require("express");
const router = express.Router();
const MatriculaController = require("../controllers/matricula.controller.js");

// Require the authenticate middleware
const { authenticate } = require("../middlewares/auth");
const {
  authenticateUser,
  authenticateMatriculaByAluno,
} = require("../middlewares/authRules.js");

const roles = [99, 1, 7];
const master = [99, 7];

//Routes for matricula crud operations
router.post("/", authenticate(roles), MatriculaController.createMatricula);
router.get("/", authenticate(master), MatriculaController.findAllMatriculas);
router.get(
  "/curso/:idCurso/aluno/:idAluno",
  authenticate(roles),
  MatriculaController.findMatriculaByAlunoForThatCourse
);
router.get(
  "/curso/:idCurso",
  authenticate(master),
  MatriculaController.findAllMatriculasByCurso
);
router.put(
  "/curso/:idCurso",
  authenticate(master),
  MatriculaController.editMatricula
);
router.get(
  "/aluno/:idAluno",
  authenticateUser(roles),
  authenticateMatriculaByAluno,
  MatriculaController.findAllMatriculasByAluno
);
router.get("/:id", authenticate(master), MatriculaController.getMatriculaById);
router.put("/:id", authenticate(roles), MatriculaController.editMatricula);

module.exports = router;
