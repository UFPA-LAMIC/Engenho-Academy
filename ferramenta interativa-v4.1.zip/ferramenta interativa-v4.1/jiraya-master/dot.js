data: [
  {
    id: 1,
    resposta:
      "resposta 1 do id 1",
    id_pergunta: 1,
    id_resposta: 1,
  },
  {
    id: 1,
    resposta:
      "resposta 2 do id 1",
    id_pergunta: 1,
    id_resposta: 6,
  },
  {
    id: 1,
    resposta:
      "resposta 3 do id 1",
    id_pergunta: 1,
    id_resposta: 21,
  },
  {
    id: 2,
    resposta:
      "resposta 1 do id 2",
    id_pergunta: 2,
    id_resposta: 6,
  },
  {
    id: 2,
    resposta:
      "resposta 2 do id 2",
    id_pergunta: 2,
    id_resposta: 21,
  },
];
data: [
  {
    id: 1,
    respostas: [
      {
        resposta:
          "resposta 1",
        id_pergunta: 1,
      },
      {
        resposta:
          "resposta 2",
        id_pergunta: 1,
      },
      {
        resposta:
          "resposta 3",
        id_pergunta: 1,
      }
    ],
  },
  {
    id: 2,
    respostas: [
      {
        resposta:
          "resposta 1 do id 2",
        id_pergunta: 2,
      },
      {
        resposta:
          "resposta 2 do id 2",
        id_pergunta: 2,
      },
    ],
  },
];
