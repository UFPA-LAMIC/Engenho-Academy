const Graduacao = require("../models/graduacao.model.js");
const bcrypt = require("bcrypt");

const GraduacaoController = {
  async createGraduacao(req, res) {
    try {
      const graduacao = req.body;

      await Graduacao.createGraduacao(graduacao);
      res.status(200).json({ msg: "new graduacao created" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller createGraduacao - ${error.message}` });
    }
  },
  async getAllGraduacao(req, res) {
    try {
      let params = req.query;
      const limit = params.limit;

      params.nome = params.nome?.trim() || "";

      const graduacao = await Graduacao.findAllGraduacao(params);

      res.status(200).json({
        ...graduacao,
        limitStats: limit,
      });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getAllGraduacao - ${error.message}` });
    }
  },

  async getGraduacaoById(req, res) {
    const id = req.params.id;
    try {
      const graduacao = await Graduacao.findGraduacaoById(id);
      res.status(200).json(graduacao);
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getGraduacaoById - ${error.message}` });
    }
  },
};

module.exports = GraduacaoController