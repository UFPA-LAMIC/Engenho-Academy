const exec = require('child_process').exec;

const LegendaController = {
  async findLegenda(req, res) {
    const videoUrl = req.body.videoUrl;
    console.log(videoUrl)

    const command = `youtube-dl --skip-download --get-subtitles --write-subtitles ${videoUrl}`;

    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Erro ao obter legendas: ${error.message}`);
        return res.status(500).json({ error: "Erro ao obter legendas." });
      }

      const captions = stdout.split("\n");
      res.json({ captions });
    });
  },
};

module.exports = LegendaController;
