const Matricula = require("../models/matricula.model.js");

const MatriculaController = {
  async createMatricula(req, res) {
    const matricula = req.body;
    try {
      await Matricula.createMatricula(matricula);
      res.status(200).json({ msg: "new matricula created" });
    } catch (error) {
      res.status(500).json({
        error: `Erro no controller createMatricula - ${error.message}`,
      });
    }
  },

  async findAllMatriculas(req, res, next) {
    try {
      const params = req.query;

      const limit = params.limit;

      const matricula = await Matricula.findAllMatriculas(params);

      res.status(200).json({
        ...matricula,
        limitStats: limit,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        error: `Erro no controller findAllMatriculas - ${error.message}`,
      });
    }
  },

  async findMatriculaByAlunoForThatCourse(req, res, next) {
    try {
      const id = req.params.idAluno;
      const curso = req.params.idCurso;

      const params = {
        aluno: id,
        curso: curso,
      };

      let matricula = await Matricula.findMatriculaByAlunoForThatCourse(params);
      // se o aluno não estiver matriculado, manda na resposta um status de que ele ainda não pediu matricula (status 9999)
      if (!matricula) {
        matricula = { status: 9999 };
      }
      res.status(200).json(matricula);
    } catch (error) {
      console.log(error);
      res.status(500).json({
        error: `Erro no controller findMatriculaByAlunoForThatCourse - ${error.message}`,
      });
    }
  },

  async findAllMatriculasByCurso(req, res, next) {
    try {
      const params = req.query;
      const id = req.params.idCurso;

      params.curso = id;

      const limit = params.limit;

      const matricula = await Matricula.findAllMatriculasByCurso({
        ...params,
      });

      res.status(200).json({
        ...matricula,
        limitStats: limit,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        error: `Erro no controller findAllMatriculasByCurso - ${error.message}`,
      });
    }
  },

  async findAllMatriculasByAluno(req, res, next) {
    try {
      const params = req.query;
      const id = req.params.idAluno;

      params.aluno = id;

      const limit = params.limit;

      const matricula = await Matricula.findAllMatriculasByAluno({
        ...params,
      });

      res.status(200).json({
        ...matricula,
        limitStats: limit,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        error: `Erro no controller findAllMatriculasByAluno - ${error.message}`,
      });
    }
  },

  async getMatriculaById(req, res) {
    try {
      const id = req.params.id;
      const matricula = await Matricula.findMatriculaById(id);
      res.status(200).json(matricula);
    } catch (error) {
      res.status(500).json({
        error: `Erro no controller getMatriculaById - ${error.message}`,
      });
    }
  },
  async editMatricula(req, res) {
    const matricula = req.body;
    try {
      await Matricula.editMatricula(matricula);
      res.status(200).json({ msg: "matricula edited!" });
    } catch (error) {
      res.status(500).json({
        error: `Erro no controller getMatriculaById - ${error.message}`,
      });
    }
  },
};

module.exports = MatriculaController;
