// const PerguntaResposta = require("../models/pergunta-resposta.model.js");
const Pergunta = require("../models/pergunta.model.js");
const { numberToMonthMapper } = require("../utils/numberToMonthMapper.js");

const PerguntaController = {
  async createPergunta(req, res) {
    const pergunta = req.body;
    try {
      // Ao criar uma pergunta, irá ser retornado o id da pergunta criada e esse id irá ser inserido da tabela pergunta_resposta
      await Pergunta.createPergunta(pergunta);
      // await PerguntaResposta.createPerguntaResposta({id_pergunta: perguntaId});
      res.status(200).json({ msg: "new pergunta created" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller createPergunta - ${error.message}` });
    }
  },
  async findAllPerguntas (req, res) {
    try {
      const params = req.query
      const limit = params.limit

      const perguntas = await Pergunta.findAllPerguntas(params)

      res.status(200).json({
        ...perguntas,
        limitStats: limit
      })
    } catch (error) {
      console.log(error)
      res.status(500).json({
        error: `Erro no controller findAllPerguntas - ${error.message}`
      })
    }
  },
};

module.exports = PerguntaController;
