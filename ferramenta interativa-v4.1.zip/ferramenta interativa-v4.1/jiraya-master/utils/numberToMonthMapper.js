const months = {
  '01': 'Janeiro',
  '02': 'Fevereiro',
  '03': 'Março',
  '04': 'Abril',
  '05': 'Maio',
  '06': 'Junho',
  '07': 'Julho',
  '08': 'Agosto',
  '09': 'Setembro',
  10: 'Outubro',
  11: 'Novembro',
  12: 'Dezembro'
}

const monthsNumbers = [
  '01',
  '02',
  '03',
  '04',
  '05',
  '06',
  '07',
  '08',
  '09',
  '10',
  '11',
  '12'
]

const sortResultByMonth = (resultArray) =>
  resultArray.sort((a, b) => +a.mes - +b.mes)

exports.getMonthName = (number = '01') =>
  months[number.toString()] || months['01']

exports.numberToMonthMapper = (
  resultArray = [],
  year = new Date().getFullYear()
) => {
  const resultMonths = []
  resultArray.forEach((row) => {
    resultMonths.push(row.mes)
  })
  monthsNumbers.forEach((month) => {
    if (!resultMonths.includes(month)) {
      resultArray.push({
        total: 0,
        mes: month,
        ano: `${year}`
      })
    }
  })
  sortResultByMonth(resultArray)
  resultArray.forEach((row) => {
    row.mes = this.getMonthName(row.mes)
  })
}
