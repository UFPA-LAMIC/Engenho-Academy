exports.formatDate = (data) => {
  if(!data) return
  return data.split('-').reverse().join('/')
}

exports.formatDatetime = (datetime) => {
  const [data, time] = datetime.split(' ')
  const formatedDatetime = `${data.split('-').reverse().join('/')} ${time}`
  return formatedDatetime
}

exports.formatDateText = (date) => {
  const data = date.split('-')
  const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']
  const mesFormated = meses[Number(data[1]) - 1]
  const dataFormated = `${data[2]} de ${mesFormated} de ${data[0]}`
  return dataFormated
}
