/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
const bcrypt = require("bcrypt");

exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex("users").del();

  await knex.raw("ALTER TABLE users AUTO_INCREMENT = 1"); // reseta o incremento da coluna id

  const hashedPassword = await bcrypt.hash("123456", 10);
  await knex("users").insert([
    {
      nome: "Luan Paiva",
      email: "luan@ufpa.br",
      graduacao: 1,
      password: hashedPassword,
      tipo: "DISCENTE",
      id_tipo:1
    },
    {
      nome: "Agostinho Castro",
      email: "agostinho@ufpa.br",
      graduacao: 4,
      password: hashedPassword,
      tipo: "DOCENTE",
      id_tipo:99
    },
    {
      nome: "Thomas",
      email: "thomas@ufpa.br",
      graduacao: 1,
      password: hashedPassword,
      tipo: "DISCENTE",
      id_tipo:1
    },
    {
      nome: "Raphaela Gallo",
      email: "gallo@ufpa.br",
      graduacao: 5,
      password: hashedPassword,
      tipo: "DOCENTE",
      id_tipo:99
    },
  ]);
};
