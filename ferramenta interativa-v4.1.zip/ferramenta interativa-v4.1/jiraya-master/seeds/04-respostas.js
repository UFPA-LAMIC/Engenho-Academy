/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */

exports.seed = async function (knex) {
  // Deletes ALL existing entries
  await knex("respostas").del();

  await knex.raw("ALTER TABLE respostas AUTO_INCREMENT = 1"); // reseta o incremento da coluna id

  await knex("respostas").insert([
    {
      id_pergunta: 1,
      autor: 2,
      resposta:
        "O polimorfismo é um dos conceitos fundamentais da programação orientada a objetos (POO) e é amplamente utilizado em Java. O termo polimorfismo se refere à capacidade de um objeto assumir diferentes formas, ou seja, uma mesma operação pode ser realizada por diferentes objetos de classes diferentes",
    },
    {
      id_pergunta: 2,
      autor: 4,
      resposta:
      "Em Java, a herança é um conceito fundamental da programação orientada a objetos (POO). Ela permite que uma classe (a classe filha ou subclasse) herde os atributos e métodos de outra classe (a classe pai ou superclasse). A herança é uma maneira de reutilizar código e estabelecer uma hierarquia de classes.",
    },
    {
      id_pergunta: 3,
      autor: 4,
      resposta:
      "É um conjunto de protocolos de comunicação utilizados para conectar dispositivos em redes, incluindo a Internet. Ele fornece um conjunto de regras e convenções para que computadores possam se comunicar uns com os outros em redes de forma confiável e eficiente. O TCP/IP é composto por dois protocolos principais: o Protocolo de Controle de Transmissão (TCP) e o Protocolo de Internet (IP). Outros protocolos complementares também fazem parte do conjunto TCP/IP.",
    },
    {
      id_pergunta: 2,
      autor: 1,
      resposta:
        "A herança em Java ajuda a promover a reutilização de código, a organização de classes em uma hierarquia lógica e a criação de classes mais especializadas a partir de classes mais gerais. No entanto, é importante usá-la com cuidado, pois uma hierarquia de classes muito profunda pode tornar o código mais complexo e difícil de manter.",
    },
    {
      id_pergunta: 3,
      autor: 2,
      resposta:
        "O TCP é responsável por estabelecer uma conexão confiável entre dois dispositivos na rede. Ele divide os dados em pacotes, os envia e garante que eles sejam entregues na ordem correta e sem erros. Se um pacote é perdido ou corrompido durante a transmissão, o TCP reenvia o pacote para garantir a entrega confiável dos dados.",
    },
    {
      id_pergunta: 3,
      autor: 1,
      resposta:
        "O IP é responsável pelo roteamento dos pacotes de dados através da rede. Ele atribui endereços IP exclusivos a cada dispositivo na rede para que os dados possam ser encaminhados de forma eficiente de origem para destino. O IP divide os dados em pacotes e adiciona informações de cabeçalho, incluindo o endereço de origem e o endereço de destino, para permitir que os roteadores direcionem os pacotes para seus destinos corretos.",
    },
    {
      id_pergunta: 3,
      autor: 2,
      resposta:
        "Além do TCP e do IP, o conjunto de protocolos TCP/IP inclui muitos outros protocolos e serviços, como o Protocolo de Controle de Mensagens (ICMP) para gerenciar mensagens de erro e notificação, o Protocolo de Resolução de Endereços (ARP) para mapear endereços IP para endereços de hardware e muitos outros.",
    },
    {
      id_pergunta: 4,
      autor: 3,
      resposta:
        'A frase "por que a cortina é azul?" é uma referência a uma cena do filme "Pulp Fiction" (1994), dirigido por Quentin Tarantino. Nessa cena, o personagem Jules, interpretado por Samuel L. Jackson, pergunta a outro personagem por que a cortina de uma casa é azul de maneira um tanto agressiva e filosófica.',
    },
    {
      id_pergunta: 1,
      autor: 4,
      resposta:
        'Há também o Polimorfismo de tempo de compilação (ou estático): Este tipo de polimorfismo ocorre durante a compilação. Ele está relacionado à sobrecarga de métodos, onde várias versões do mesmo método podem ser chamadas com base nos argumentos passados. O compilador decide qual versão do método chamar com base na assinatura do método. Isso é resolvido em tempo de compilação e é conhecido como ligação estática.',
    },
  ]);
};
