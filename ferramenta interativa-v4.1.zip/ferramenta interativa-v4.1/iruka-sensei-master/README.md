# iruka-sensei
front end project for my tcc

## TODO
- [] implement dompurify
- [] implement vuelidate
