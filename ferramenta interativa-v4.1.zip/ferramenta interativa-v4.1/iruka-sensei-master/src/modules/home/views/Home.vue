<template>
  <base-page-layout has-filter>
    <div class="home">
      <div class="home-texts">
        <h1>Cursos online que impulsionam o seu potêncial</h1>
        <p>
          Um ambiente de aprendizado virtual que oferece uma ampla gama de
          cursos e recursos educacionais para estudantes, professores e
          interessados.
        </p>
      </div>
      <div class="home-img">
        <img src="../../../assets/home-img.png" alt="Imagem da homepage" />
      </div>
    </div>
    <div
      class="cards-container"
      :class="{ 'more-than-four': hasMoreThanFourCourses }"
    >
      <aside v-for="curso in cursos" :key="curso.id">
        <card
          redirect-to="Descrição do Curso"
          :id-curso="curso.id"
          :titulo="curso.nome"
          :docente="curso.responsavel"
          :numberOfVideos="curso.numberOfVideos"
          :status="curso.status_matricula"
        />
      </aside>
    </div>
    <div class="paginacao mt-5">
      <v-pagination
        v-model="currentPage"
        :total-items="totalItems"
        :items-per-page="10"
        :length="pageLength"
        @input="getCursos"
      />
    </div>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import Card from "@/components/Card.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
import { mapState } from "vuex";
export default {
  components: { BasePageLayout, Card },
  data: () => ({
    cursos: [],
    matriculas: [],
    currentPage: 1,
    totalItems: 0,
    pageLength: 1,
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
    hasMoreThanFourCourses() {
      return this.cursos.length > 4; // Verifica se há mais de 4 cursos
    },
  },
  mounted() {
    this.getCursos();
  },
  methods: {
    async getCursos() {
      try {
        const response = await axios.get(
          `${baseApiUrl}/cursos?page=${this.currentPage}`
        );
        this.cursos = response.data.data;
        this.totalItems = response.data.count;
        this.pageLength = this.totalPageCalc(
          response.data.count,
          response.data.limitStats
        );

        this.getMatriculasByAluno();
        window.scrollTo(0, 0);
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao conectar com o servidor 0001",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    totalPageCalc(a, b) {
      if (b === 0) throw new Error("Divisão por zero não é permitida.");
      return Math.ceil(a / b);
    },
    async getMatriculasByAluno() {
      if (!this.$isLogged()) {
        return;
      }

      try {
        const response = await axios.get(
          `${baseApiUrl}/matriculas/aluno/${this.user.id}`
        );
        this.matriculas = response.data.data;

        const cursosComStatus = this.cursos.map((curso) => {
          // Encontra a matrícula correspondente ao curso
          const matriculaCorrespondente = this.matriculas.find(
            (mat) => mat.curso === curso.id
          );

          return {
            ...curso,
            status_matricula: matriculaCorrespondente
              ? matriculaCorrespondente.status
              : null,
          };
        });

        this.cursos = cursosComStatus;
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao conectar com o servidor 0002",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.cards-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, 326px);
  // grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
  width: 100%;
  max-width: 1500px;
  margin: 0 auto;
  padding: 0;
  box-sizing: border-box;
  // background: red;
}

.cards-container.more-than-four {
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
}

.card {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
}
.cards-container > .card {
  margin: 0;
}
.home {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 20px 40px;
  background: #dad7cd;
  margin-bottom: 30px;
}

.home-texts {
  background-color: #fff;
  margin-top: 40px;
  max-width: 600px;
  padding: 30px;
  box-shadow: 1px 1px rgb(227, 227, 227), 0 0 0.08em rgb(184, 184, 184);
}

.home-texts h1 {
  max-width: 430px;
  margin-bottom: 8px;
  line-height: 1.2;
  font-family: $primary_font;
}

.home-texts p {
  font-weight: 500;
  font-family: $primary_font;
}

.home-img img {
  // flex: 0 0 50%;
  max-width: 400px;
  max-height: 350px;
}

.card-container {
  display: grid;
  grid-template-columns: repeat(
    auto-fit,
    minmax(330px, 1fr)
  ); /* Ajusta o tamanho mínimo e máximo dos cards */
  gap: 20px; /* Espaçamento entre os cards */
  justify-content: center; /* Centraliza o grid no container */
  align-items: start;
  padding: 20px; /* Espaçamento interno */
}
// .card-container {
//   display: grid;
//   grid-template-columns: repeat(auto-fit, minmax(285px, auto));
//   gap: 20px;
//   justify-content: start;
//   align-items: center;
//   // background: rgb(228, 163, 163);
// }

@media screen and (max-width: 830px) {
  .titulo {
    // background: red;
    // word-break: normal;
  }
  .titulo h1 {
    font-size: 24px;
    line-height: 25px;
  }
  .titulo p {
    font-size: 14px;
    line-height: 17px;
  }
}
@media screen and (max-width: 440px) {
}
</style>