export default [
    {
      path: "/perfil",
      name: "Perfil",
      component: () => import("@/modules/perfil/views/PerfilUsuario.vue"),
    },
  ];
  