<template>
  <base-page-layout has-no-style>
    <div class="header-description">
      <h3>{{ curso.nome }}</h3>
      <p>
        <span>Criado por</span> <strong>{{ curso.criador }}</strong>
      </p>
    </div>
    <aside class="content">
      <aside class="first-column">
        <h4>O que você irá aprender</h4>
        <div v-html="curso.aprendizado"></div>
        <h4>Descrição do curso</h4>
        <div v-html="curso.descricao"></div>
      </aside>
      <div class="second-column">
        <img
          class="course-img"
          src="@/assets/no_image_course.png"
          alt="no card image"
        />
        <aside class="adicionais">
          <h5>Este curso inclui:</h5>
          <div class="teste">
            <aside class="teste2">
              <v-icon color="#0b090a">mdi-cast-variant</v-icon>
              <p>
                <span style="font-size: 20px">{{ curso.numberOfVideos }}</span>
                Aulas
              </p>
            </aside>
          </div>
        </aside>
        <v-btn depressed dark color="#4966FE" @click="isLoggedIn"
          >Solicitar matricula</v-btn
        >
        <v-btn
          v-if="isDocente"
          depressed
          dark
          color="#4966FE"
          @click="editCourse(curso.id)"
          >Editar curso</v-btn
        >
        <v-btn
          v-if="isDocente"
          depressed
          dark
          color="#4966FE"
          @click="matriculaCourse(curso.id)"
          >Acompanhar Matrículas</v-btn
        >
        <v-btn
          v-if="hasMatriculaOk"
          depressed
          dark
          color="#4966FE"
          @click="watchCourse(curso.id)"
          >Assistir Aulas</v-btn
        >
      </div>
    </aside>
    <aside>
      <!-- <h4>Avaliação do curso</h4> -->
    </aside>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import Swal from "sweetalert2";
import axios from "axios";
import { baseApiUrl } from "@/global";
import { mapState } from "vuex";
export default {
  components: { BasePageLayout },
  data: () => ({
    redirect: null,
    curso: {},
    matricula: {},
    hasMatricula: false,
    hasMatriculaOk: false,
    cursoOfDocente: {},
    isDocente: false,
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
  },
  mounted() {
    this.getCursoInfos();
    this.getMatriculaByCurso();
    this.isUserDocente();
    window.scrollTo(0, 0);
  },
  methods: {
    isLoggedIn() {
      this.$isLogged() && this.$showPage()
        ? this.newAlert()
        : this.$router.push({ name: "login" }).catch(() => {});
    },
    async getMatriculaByCurso() {
      //Condição para que faça a requisição ao servidor. se o usuário não estiver logado, já mata a função
      if (!this.$isLogged()) {
        return;
      }

      try {
        const response = await axios.get(
          `${baseApiUrl}/matriculas/curso/${this.$route.params.id}/aluno/${this.user.id}`
        );
        this.matricula = response.data;
        // se o status der 9999 o aluno não solicitou matricula, senão já
        this.matricula.status === 9999
          ? (this.hasMatricula = false)
          : (this.hasMatricula = true);

        this.userCases();
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao conectar com o servidor 0012",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    async newAlert() {
      if (!this.hasMatricula) {
        const infoMatricula = {
          aluno: this.user.id,
          curso: this.$route.params.id,
        };
        try {
          await axios.post(`${baseApiUrl}/matriculas`, infoMatricula);
          Swal.fire({
            // position: "top-end",
            icon: "success",
            title: "Sua matrícula foi solicitada!",
            showConfirmButton: true,
            timer: 2500,
          });
        } catch (error) {
          console.log(error);
          this.$snackbar({
            message: "Erro ao cadastrar usuário",
            color: "#e02222",
            timeout: 3000,
          });
        }
      } else {
        Swal.fire({
          // position: "top-end",
          icon: "info",
          title: "Você já possui uma matrícula pendente!",
          showConfirmButton: true,
          timer: 2500,
        });
      }
    },
    watchCourse(id) {
      this.$router.push({ name: "video", params: { id: id } }).catch(() => {});
    },
    editCourse(id) {
      this.$router
        .push({ name: "Editar curso", params: { id: id } })
        .catch(() => {});
    },
    matriculaCourse(id) {
      this.$router
        .push({ name: "Matriculas curso", params: { id: id } })
        .catch(() => {});
    },
    async getCursoInfos() {
      try {
        const response = await axios.get(
          `${baseApiUrl}/cursos/${this.$route.params.id}`
        );
        this.curso = response.data;
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao conectar com o servidor 0013",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    async isUserDocente() {
      // console.log(this.user.tipo);
      if (this.user.tipo === "DISCENTE") {
        return;
      }

      try {
        const response = await axios.get(
          `${baseApiUrl}/cursos/${this.$route.params.id}/docente/${this.user.id}`
        );
        this.cursoOfDocente = response.data;
        // se is_docente for true então o docente é o professor deste curso
        this.cursoOfDocente.is_docente == true
          ? (this.isDocente = true)
          : (this.isDocente = false);
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao conectar com o servidor 0014",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    userCases() {
      // if (!this.$isLogged()) {
      //   return;
      // }

      if (this.matricula.status === 1) {
        this.hasMatriculaOk = true;
      } else if (this.matricula.status === 2) {
        this.hasMatriculaOk = false;
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.header-description {
  display: flex;
  flex-direction: column;
  // align-items: center;
  justify-content: center;
  background: $dark_banner;
  height: 100px;
  padding: 30px;

  & h3 {
    font-size: 32px;
    color: $light;
    font-weight: 400;
    // line-height: 1.5rem;
  }
  & p {
    margin: 0;
    font-family: $primary_font;
    color: $light;
    font-weight: 400;

    & span {
      font-weight: 200;
      color: $lighter;
    }
  }
}

.content {
  padding: 20px 20px 20px 30px;
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 30px;

  & h4 {
    font-family: $primary_font;
    font-size: 24px;
    color: $dark;
    font-weight: 400;
    margin-bottom: 10px;
  }

  & .text {
    line-height: 25px;
    font-family: $primary_font;
    color: $black;
  }

  & .second-column {
    // background: red;
    display: flex;
    flex-direction: column;
    align-items: center;

    & .course-img {
      width: 320px;
    }

    & .adicionais {
      // background: red;
      width: 320px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: flex-start;

      & h5 {
        font-size: 20px;
        font-family: $primary_font;
        margin: 15px 0;
      }

      & .teste {
        // background: green;
        width: inherit;
        display: flex;
        justify-content: space-between;
        align-items: center;
        & .teste2 {
          display: flex;
          justify-content: flex-start;
          // background: orange;
          width: inherit;
          margin-bottom: 10px;
        }
        & .teste2 p {
          margin: 0 0 0 10px;
          font-size: 16px;
          font-family: $primary_font;
        }
      }
    }

    & button {
      margin-top: 20px;
      width: 320px;
      text-transform: capitalize;
      font-family: $primary_font;
      font-size: 16px;
      // color: $primary_btn;
    }
  }
}

@media screen and (max-width: 765px) {
  .header-description {
    padding: 20px;
    h3 {
      font-size: 26px;
    }
    p {
      font-size: 14px;
    }
  }
  .content {
    gap: 20px;
    padding: 20px;

    & h4 {
      font-size: 20px;
    }

    & .text {
      font-size: 14px;
    }

    & .second-column {
      & .course-img {
        width: 260px;
      }

      & .adicionais {
        // background: red;
        width: 260px;

        & h5 {
          font-size: 18px;
        }

        & .teste {
          & .teste2 p {
            font-size: 13px;
          }
        }
      }

      & button {
        width: 260px;
        font-size: 14px;
      }
    }
  }
}

@media screen and (max-width: 630px) {
  .header-description {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 10px 20px 10px 20px;
    height: 100px;
    // text-align: center;
    // height: 140px;
    h3 {
      font-size: 22px;
    }
    p {
      font-size: 14px;
    }
  }
  .content {
    display: flex;
    flex-direction: column-reverse;
  }
}
</style>