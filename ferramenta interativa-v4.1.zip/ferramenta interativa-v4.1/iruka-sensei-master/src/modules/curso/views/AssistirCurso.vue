<template>
  <base-page-layout>
    <div v-if="hasVideo" class="video">
      <iframe
        v-if="hasMatricula"
        class="video-iframe"
        :src="src"
        title="YouTube video player"
        frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen
      ></iframe>

      <v-card class="video-list" tile v-if="hasMatricula">
        <v-list>
          <v-subheader class="subtitle">Aulas do curso</v-subheader>
          <v-list-item-group v-model="selectedItem" color="primary">
            <v-list-item v-for="(item, i) in items" :key="i">
              <p class="mr-3" style="margin: 0">{{ item.ordem }} -</p>
              <v-list-item-content @click="chooseVideo(item)">
                <v-list-item-title class="texto">{{
                  item.titulo
                }}</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
      </v-card>
    </div>
    <aside v-else>
      <div class="sem-videos">
        <img src="../../../assets/no-video-bkg.png" alt="Sem videos" />
        <p>
          {{ textMsg }}
          <span @click="redirectToCurso()">Voltar.</span>
        </p>
      </div>
    </aside>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
export default {
  components: { BasePageLayout },
  data: () => ({
    selectedItem: 1,
    items: [],
    src: "",
    hasVideo: true,
    hasMatricula: false,
    textMsg: "",
  }),
  mounted() {
    this.getVideos();
    window.scrollTo(0, 0);
  },
  methods: {
    async getVideos() {
      // O usuário pode querer acessar a rota de aulas sem estar logado.
      // Senão tiver logado, manda pra tela de login
      if (!this.$isLogged()) {
        this.$router.push({ name: "login" }).catch(() => {});
        return;
      }
      try {
        const response = await axios.get(
          `${baseApiUrl}/videos/curso/${this.$route.params.id}?orderBy=asc`
        );
        this.items = response.data.data;

        if (this.items.length == 0 || !this.items) {
          this.textMsg = "Este curso ainda não possui vídeos cadastrados!";
          this.hasVideo = false;
          return;
        }

        this.src = this.items[0].url;
        this.selectedItem = this.items[0].ordem - 1;
        this.hasMatricula = true;
      } catch (error) {
        this.textMsg = error.response?.data?.msg;
        this.hasVideo = false;

        this.$snackbar({
          message: "Erro ao conectar com o servidor 0020",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    chooseVideo(item) {
      this.src = item.url;
      this.selectedItem = this.items.ordem - 1;
    },
    redirectToCurso() {
      this.$router
        .push({ name: "Descrição do Curso", params: this.$route.params.id })
        .catch(() => {});
    },
  },
};
</script>

<style lang="scss" scoped>
.video {
  display: flex;
  width: 100%;
  height: 100vh;
  // background-color: red;
}

.video-iframe {
  width: 100%;
  height: 500px;
  margin-right: 20px;
}

.video-list {
  min-width: 450px;
  max-width: 450px;
  height: 500px;
}
.texto {
  text-wrap: wrap;
  font-family: $primary_font;
}
.sem-videos {
  display: flex;
  justify-content: center;
  align-items: center;
  // height: 100vh;
  flex-direction: column;
  // background-color: #f1f1f1;
}
.sem-videos span {
  color: blue;
}
.sem-videos span:hover {
  cursor: pointer;
}

@media screen and (max-width: 1265px) {
  .video-list {
    min-width: 300px;
    max-width: 300px;
    height: 500px;
  }
}

@media screen and (max-width: 1050px) {
  .video {
    display: flex;
    flex-direction: column;
    width: 100%;
  }
  .video-iframe {
    min-height: 500px;
  }
  .video-list {
    margin-top: 20px;
    max-width: 100%;
    max-height: 100%;
  }
}

@media screen and (max-width: 690px) {
  .video {
    display: flex;
    flex-direction: column;
    width: 100%;
  }
  .video-iframe {
    min-height: 400px;
  }
  .video-list {
    margin-top: 20px;
    max-width: 100%;
    max-height: 100%;
  }
}
</style>