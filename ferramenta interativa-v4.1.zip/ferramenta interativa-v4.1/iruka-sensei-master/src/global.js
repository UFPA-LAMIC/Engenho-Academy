import Vue from 'vue'

export const userKey = '__ufpa_user'
//colocar o mesmo ip da maquina 
export const baseApiUrl = 'http://192.168.3.13:3006' //colocar o ip da maquina-base
//export const baseApiUrl = 'http://localhost:3006'

export function showError(e) {
  if (e && e.response && e.response.data) {
    Vue.toasted.global.defaultError({ msg: e.response.data })
  } else if (typeof e === 'string') {
    Vue.toasted.global.defaultError({ msg: e })
  } else {
    Vue.toasted.global.defaultError()
  }
}

export default { baseApiUrl, showError, userKey }
