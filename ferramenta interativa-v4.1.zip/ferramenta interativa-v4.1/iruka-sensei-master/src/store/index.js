import Vue from 'vue'
import Vuex from 'vuex'

import actions from '@/store/actions.js'
import mutations from '@/store/mutations.js'
import state from '@/store/state.js'

// load Vuex
Vue.use(Vuex)

// Create Store
export default new Vuex.Store({
  actions,
  mutations,
  state
})
