<template>
  <v-menu offset-y class="logged-user z-index">
    <template v-slot:activator="{ on }">
      <v-list color="#3C6E71" class="lista pa-0">
        <v-list-item>
          <v-avatar class="user" color="#FFF" v-on="on" size="40">
            <span class="green--text text-h7">{{
              formatAvatar(user.nome)
            }}</span>
          </v-avatar>
          <!-- <span class="mx-2 user-name">{{ user.nome }}</span> -->
          <!-- <v-icon color="#D9D9D9" v-on="on">mdi-chevron-down</v-icon> -->
        </v-list-item>
      </v-list>
    </template>
    <v-list>
      <!-- <v-list-item class="logged-user__item" @click="profile">
        <v-list-item-title>Perfil</v-list-item-title>
      </v-list-item> -->
      <v-list-item class="logged-user__item" @click="logout">
        <v-list-item-title>Sair</v-list-item-title>
      </v-list-item>
    </v-list>
  </v-menu>
</template>

<script>
// import { mapState } from "vuex";
export default {
  props: {
    user: {
      type: Object,
      default: () => {},
    },
  },
  computed: {
    // ...mapState({ user: (state) => state.user }),
  },
  methods: {
    logout() {
      this.$logout();
      this.$store.commit("LOGOUT");
      this.$router.push({ name: "home" }).catch(() => {});
    },
    profile() {
      this.$router.push({ path: "/perfil" });
    },
    formatAvatar(name) {
      const nameSplitted = name.split(" ");
      return (
        nameSplitted[0].charAt(0) +
        nameSplitted[nameSplitted.length - 1].charAt(0)
      );
    },
  },
};
</script>
<style lang="scss" scoped>
.lista {
  background: transparent !important;
}
.user:hover {
  cursor: pointer;
}
.logged-user {
  &__item {
    width: 120px;
    margin: 0 10px;
  }
}
.user-name {
  color: #d9d9d9;
}
</style>
