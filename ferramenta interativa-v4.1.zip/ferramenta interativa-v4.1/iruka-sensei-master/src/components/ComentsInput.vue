<template>
  <v-row>
    <v-col cols="12" sm="6" md="12">
      <v-textarea
        color="orange orange-darken-4"
        placeholder="Escreva um comentário sobre a resposta...(1)"
        auto-grow
        outlined
        rows="4"
        row-height="25"
        dense
        :v-model="coment"
      ></v-textarea>
    </v-col>
  </v-row>
</template>

<script>
export default {
  name: "ComentsInput",
  props: ["coment"],
};
</script>

<style>
</style>