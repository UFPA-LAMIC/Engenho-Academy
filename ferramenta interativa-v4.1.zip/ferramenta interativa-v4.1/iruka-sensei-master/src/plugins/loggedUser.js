export default {
  install(Vue) {
    // Logged User
    const isLogged = () => {
      return window.localStorage.getItem("loggedUser") !== null;
    };
    const getLoggedUser = () => {
      const user = JSON.parse(window.localStorage.getItem("loggedUser"));
      if (!user) return null;
      return user;
    };
    const setLoggedUser = (loggedUser) => {
      if (!loggedUser) return;
      window.localStorage.setItem("loggedUser", JSON.stringify(loggedUser));
    };
    const removeLoggedUser = () => {
      window.localStorage.removeItem("loggedUser");
    };

    // Session
    const getToken = () => {
      return window.localStorage.getItem("token");
    };
    const setToken = (token) => {
      if (!token) return;
      window.localStorage.setItem("token", token);
    };
    const removeToken = () => {
      window.localStorage.removeItem("token");
    };

    // Logout
    const logout = () => {
      window.localStorage.removeItem("loggedUser");
      window.localStorage.removeItem("token");
    };

    // show page
    const showPage = () => {
      return getToken() ? true : false;
    };

    // Logged User
    Vue.prototype.$isLogged = Vue.isLogged = isLogged;
    Vue.prototype.$getLoggedUser = Vue.getLoggedUser = getLoggedUser;
    Vue.prototype.$setLoggedUser = Vue.setLoggedUser = setLoggedUser;
    Vue.prototype.$removeLoggedUser = Vue.removeLoggedUser = removeLoggedUser;

    // Session ID
    Vue.prototype.$getToken = Vue.getToken = getToken;
    Vue.prototype.$setToken = Vue.setToken = setToken;
    Vue.prototype.$removeToken = Vue.removeToken = removeToken;

    // Logout
    Vue.prototype.$logout = Vue.logout = logout;

    // Show page
    Vue.prototype.$showPage = Vue.showPage = showPage;

    Object.defineProperty(Vue.prototype, "$loggedUser", {
      get: () => {
        return getLoggedUser();
      },
    });

    Object.defineProperty(Vue, "loggedUser", {
      get: () => {
        return getLoggedUser();
      },
    });
  },
};
