<template>
  <div>
    <v-row>
      <v-col cols="12">
        <v-card tile height="100%">
          <v-card-title class="text-h5"
            ><v-icon class="mr-2">{{ mainCard.icon }}</v-icon
            >{{ mainCard.title }}</v-card-title
          >
          <v-card-subtitle>{{ mainCard.text }}</v-card-subtitle>
        </v-card>
      </v-col>
    </v-row>
    <v-row>
      <v-col v-for="item in cards" :key="item.index" :cols="item.cols">
        <v-card tile height="100%" class="card-outter">
          <v-card-title class="text-h5"
            ><v-icon class="mr-2">mdi-label-outline</v-icon>{{ item.title }}
          </v-card-title>
          <v-card-subtitle>{{ item.text }}</v-card-subtitle>
          <v-card-actions class="card-actions">
            <v-btn class="mb-1" outlined text @click="redirect(item.href)">
              {{ item.textButton }}
            </v-btn>
            <v-btn
              v-if="item.extraLinks.length"
              class="mb-1"
              outlined
              text
              @click="redirect(item.extraLinks[0])"
              >{{ item.extraLinks[1] || "" }}</v-btn
            >
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script>
export default {
  data: () => ({
    mainCard: {
      title: "Plataforma de ensino",
      icon: "mdi-map-marker-outline",
      text: "Cursos de diferentes áreas para todas as pessoas que querem aprender algo novo, ou aprimorar aquilo que já tenha conhecimento.",
    },
    cards: [
      {
        title: "Sugestões",
        text: "Sugestões de melhoria da plataforma, novas funcionalidades e/ou relatar bugs.",
        cols: 6,
        href: "https://docs.google.com/forms/d/e/1FAIpQLScQ2NUvg7hsZZyqUB14B1eOrp-U9QD7YDd088hihZLmf9kjGw/viewform?usp=sf_link",
        textButton: "Formulário",
        extraLinks: [],
      },
    ],
  }),
  methods: {
    redirect(link) {
      return window.open(link, "_blank");
    },
  },
};
</script>
<style lang="scss" scoped>
.card-outter {
  position: relative;
  padding-bottom: 48px;
}
.card-actions {
  position: absolute;
  bottom: 0;
}
</style>
