<template>
  <div class="home ma-5">
    <h1 style="font: 1.5rem">Turmas</h1>
    <h4>Meus Cursos</h4>
    <div class="cards-curso">
      <div v-for="c in cursos" :key="c.nome">
        <card-list
          :nome="c.nome"
          :data_inicio="c.data_inicio"
          :data_fim="c.data_fim"
          :color="c.color"
          :id_matricula="c.id"
          :method="dialogExpand"
          tipo="expand"
        ></card-list>
      </div>
    </div>
    <v-transition>
      <div v-show="expand">
        <v-row>
          <v-col md="12">
            <v-card class="mt-5">
              <v-card-title>Alunos Matriculados</v-card-title>
              <v-data-table
                :headers="headers"
                :items="matriculados"
                item-key="name"
                class="elevation-1"
              >
                <template v-slot:item="{ item }">
                  <tr>
                    <td>
                      {{ item.id_aluno }}
                    </td>
                    <td>
                      {{ item.nome }}
                    </td>
                    <td>
                      {{ item.email }}
                    </td>
                    <td>
                      <v-chip :color="statusColor(item.status)" dark>
                        {{ item.status }}
                      </v-chip>
                    </td>
                    <td>
                      <v-btn icon>
                        <v-icon color="green" @click="acceptSubscribe(item)"
                          >mdi-check</v-icon
                        >
                      </v-btn>
                      <v-btn icon>
                        <v-icon
                          color="rgba(233, 23, 23, 0.842)"
                          @click="declineSubscribe(item)"
                          >mdi-close</v-icon
                        >
                      </v-btn>
                    </td>
                  </tr>
                </template>
              </v-data-table>
            </v-card>
          </v-col>
        </v-row>
      </div>
    </v-transition>
    <!-- </div> -->
    <v-snackbar
      v-model="snackbar"
      :timeout="3000"
      down
      left
      :color="snackColor"
    >
      {{ snackText }}
    </v-snackbar>
  </div>
</template>

<script>
import CardList from "../components/CardList.vue";
import axios from "axios";
import { baseApiUrl, userKey } from "../global.js";
export default {
  name: "Turma",
  components: { CardList },
  data: () => ({
    expand: false,
    snackbar: false,
    snackText: "",
    snackColor: "",
    cursos: [],
    users: [],
    user: {},
    matriculados: [],
    usuario: {},
    headers: [
      { value: "id_aluno", text: "Código Aluno" },
      { value: "nome", text: "Discente" },
      { value: "email", text: "E-Mail" },
      { value: "status", text: "Status" },
      { value: "actions", text: "Deferir/Indeferir" },
    ],
  }),
  methods: {
    async loadCursos(id) {
      try {
        const response = await axios.get(`${baseApiUrl}/cursos-docente/${id}`);
        this.cursos = response.data.data;
        console.log(this.cursos);
      } catch (error) {
        console.error(error);
      }
    },
    // Mostrar tabela de alunos matriculados(deferidos) daquele respectivo curso
    async loadMatriculas(id_curso) {
      try {
        const response = await axios.get(
          `${baseApiUrl}/matriculas/${id_curso}`
        );
        this.matriculados = response.data.data;
        console.log("Matriculados", this.matriculados);
      } catch (e) {
        console.log(e);
      }
    },
    async updateStatusMatricula(item) {
      try {
        await axios.put(
          `${baseApiUrl}/matriculas/${item.curso}/${item.id_aluno}`,
          this.usuario
        );
        this.loadMatriculas(item.curso);
      } catch (e) {
        console.log(e);
      }
    },
    acceptSubscribe(item) {
      this.usuario.status = "DEFERIDO";
      this.updateStatusMatricula(item);
      this.snackText = "Aluno(a) deferido!";
      this.snackColor = "rgb(52, 185, 52)";
      this.snackbar = true;
    },
    declineSubscribe(item) {
      this.usuario.status = "INDEFERIDO";
      this.updateStatusMatricula(item);
      this.snackText = "Aluno(a) indeferido!";
      this.snackColor = "rgb(219, 42, 42)";
      this.snackbar = true;
    },
    dialogExpand(value, id_matricula) {
      this.expand = value;
      this.loadMatriculas(id_matricula);
    },
    statusColor(status) {
      if (status === "DEFERIDO") {
        return "rgb(52, 185, 52)";
      } else if (status === "INDEFERIDO") {
        return "rgb(219, 42, 42)";
      } else {
        return "orange";
      }
    },
  },
  mounted() {
    if (localStorage.getItem(userKey)) {
      try {
        this.user = JSON.parse(localStorage.getItem(userKey));
        this.loadCursos(this.user.id);
      } catch (e) {
        localStorage.removeItem(userKey);
      }
    }
  },
};
</script>

<style>
.btn-add {
  display: flex;
  justify-content: center;
  align-content: center;
  align-items: center;
}
</style>