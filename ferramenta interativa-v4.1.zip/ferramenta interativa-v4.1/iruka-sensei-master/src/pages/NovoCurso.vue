<template>
  <v-row>
    <v-col cols="auto">
      <v-dialog transition="dialog-bottom-transition" width="1000">
        <template v-slot:activator="{ on, attrs }">
          <v-btn text class="mb-3" color="primary" v-bind="attrs" v-on="on"
            >Novo Curso</v-btn
          >
        </template>
        <template v-slot:default="dialog">
          <v-card class="px-5" color="white">
            <v-card-title class="px-0">Casdastro de Curso</v-card-title>
            <v-divider></v-divider>
            <v-card-text fluid class="pa-0">
              <v-row>
                <v-col cols="12" sm="6" md="12">
                  <label for="nome" class="labels pb-3">Título</label>
                  <v-text-field
                    id="nome"
                    v-model="curso.nome"
                    outlined
                    dense
                  ></v-text-field>
                </v-col>
                <v-row>
                  <v-col cols="12" sm="6" md="3">
                    <label for="dtInicio" class="labels pb-3">Início</label>
                    <v-text-field
                      v-model="curso.data_inicio"
                      id="dtInicio"
                      dense
                      outlined
                      type="date"
                    ></v-text-field>
                  </v-col>
                  <v-col cols="12" sm="6" md="3">
                    <label for="dtInicio" class="labels pb-3">Fim</label>
                    <v-text-field
                      v-model="curso.data_fim"
                      id="dtInicio"
                      outlined
                      dense
                      type="date"
                    ></v-text-field>
                  </v-col>
                </v-row>
                <v-col cols="12" sm="6" md="12">
                  <label for="descricao" class="labels pb-3">Informações</label>
                  <!-- <div id="descricao" v-html="curso.descricao"></div> -->
                  <vue-editor
                    id="descricao"
                    v-model="curso.descricao"
                    :editorToolbar="customToolbar"
                  ></vue-editor>
                </v-col>
              </v-row>
              <v-row>
                <v-col md="2">
                  <v-btn text @click="colorDialog = true">
                    <v-icon :color="curso.color"
                      >mdi-checkbox-blank-circle</v-icon
                    >cor do card</v-btn
                  >
                </v-col>
                <v-dialog
                  transition="dialog-bottom-transition"
                  width="300"
                  v-model="colorDialog"
                >
                  <div>
                    <v-color-picker
                      dot-size="30"
                      hide-inputs
                      v-model="curso.color"
                    ></v-color-picker>
                  </div>
                  <v-btn color="primary" @click="colorDialog = false"
                    >SALVAR</v-btn
                  >
                </v-dialog>
              </v-row>
            </v-card-text>
            <v-card-actions class="justify-end">
              <v-btn text color="secondary" @click="dialog.value = false"
                >cancelar</v-btn
              >
              <v-btn
                dark
                color="#002040"
                @click="submit(), (dialog.value = false)"
                >SALVAR</v-btn
              >
            </v-card-actions>
          </v-card>
        </template>
      </v-dialog>
      <v-snackbar
        v-model="snackbar"
        :timeout="3000"
        absolute
        bottom
        left
        :color="snackColor"
      >
        {{ snackText }}
      </v-snackbar>
    </v-col>
  </v-row>
</template>
<script>
import axios from "axios";
import { baseApiUrl } from "../global.js";
export default {
  name: "NovoCurso",
  data: () => ({
    curso: {
      color: "#CCC",
    },
    snackbar: false,
    snackText: "",
    snackColor: "",
    colorDialog: false,
    chosenColor: "#000",
    customToolbar: [
      [{ font: [] }],
      [{ header: [false, 1, 2, 3, 4, 5, 6] }],
      [{ size: ["small", false, "large", "huge"] }],
      ["bold", "italic", "underline", "strike"],
      [
        { align: "" },
        { align: "center" },
        { align: "right" },
        { align: "justify" },
      ],
      [{ header: 1 }, { header: 2 }],
      ["blockquote", "code-block"],
      [{ list: "ordered" }, { list: "bullet" }, { list: "check" }],
      [{ script: "sub" }, { script: "super" }],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ color: [] }, { background: [] }],
      [{ direction: "rtl" }],
      ["clean"],
    ],
  }),
  methods: {
    async createCurso() {
      try {
        await axios.post(`${baseApiUrl}/curso/`, this.curso);
        document.location.reload(true);
        console.log(this.curso);
      } catch (e) {
        console.log(e);
      }
    },
    submit() {
      this.createCurso();
      this.curso = { color: "#CCC" };
      this.snackText = "Parabéns pelo cadastro do curso";
      this.snackColor = "rgb(51, 222, 71)";
      this.snackbar = true;
    },
  },
};
</script>
<style>
.labels {
  font-weight: bold;
}
</style>