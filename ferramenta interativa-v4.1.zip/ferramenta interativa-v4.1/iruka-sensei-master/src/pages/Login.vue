<template>
  <v-layout
    class="login-layout my-5"
    align-center
    justify-center
    row
    fill-height
  >
    <v-card class="login pa-5" color="#F3F3F3" max-width="600">
      <v-toolbar dark color="primary">
        <span class="pa-3 title"> A Plataforma </span>
      </v-toolbar>

      <v-form class="pa-3" v-model="valid" lazy-validation>
        <v-text-field
          v-model="ususario.email"
          :rules="nameRules"
          label="Nome"
          required
        ></v-text-field>

        <v-text-field
          v-model="ususario.password"
          :rules="passwordRules"
          label="Senha"
          type="password"
          required
        ></v-text-field>
        <div class="login-buttons">
          <v-btn
            depressed
            :loading="loading"
            color="primary"
            @click="newSignin()"
            >LOGIN</v-btn
          >
          <cadastro-user />
        </div>
      </v-form>
    </v-card>
  </v-layout>
</template>

<script>
import CadastroUser from "../features/CadastroUser.vue";
import { baseApiUrl, showError, userKey } from "@/global";
import axios from "axios";
import { mapActions } from "vuex";
export default {
  name: "Login",
  components: { CadastroUser },
  data: () => {
    return {
      valid: true,
      nameRules: [(v) => !!v || "Digite o Nome!"],
      passwordRules: [
        (v) => !!v || "Digite a Senha!",
        (v) => (v && v.length >= 6) || "Senha com menos de 6 caracteres!",
      ],
      loading: false,
      ususario: {},
    };
  },
  methods: {
    ...mapActions(["signinUser"]),
    newSignin() {
      axios
        .post(`${baseApiUrl}/login`, this.ususario)
        .then((res) => {
          this.signinUser(res.data);
          // this.$store.commit("setUser", res.data);
          localStorage.setItem(userKey, JSON.stringify(res.data));
          this.$router.push({ path: "/" });
        })
        .catch(showError);
    },
    async validate() {
      try {
        await this.$refs.form.validate();
      } catch {
        this.$snackbar({ message: "ERROR!", snackbarColor: "#FF5252" });
      } finally {
        this.loading = true;
        this.$router.push({ path: "/" });
      }
    },
  },
};
</script>

<style>
.login-layout {
  /* width: 100%; */
  height: auto;
  /* min-height: 110vh; */
  background-color: F3F3F3;
  /* display: flex;
  justify-content: center; */
}
.login {
  width: 600px;
}
.login-buttons {
  display: flex;
  align-items: center;
  /* background-color: aqua; */
}
</style>