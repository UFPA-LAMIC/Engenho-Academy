import loginRoute from '@/modules/login/routes'
import cursoRoute from '@/modules/curso/routes'
import perfilRoute from '@/modules/perfil/routes'
import homeRoute from '@/modules/home/routes'

export default [
    ...homeRoute,
    ...loginRoute,
    ...perfilRoute,
    ...cursoRoute,
]