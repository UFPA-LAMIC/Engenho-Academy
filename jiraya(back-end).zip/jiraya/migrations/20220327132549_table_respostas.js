exports.up = function (knex) {
    return knex.schema.createTable("respostas", (table) => {
      table.increments("id").primary();
      table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
      table.text("resposta");
      table.integer("autor").unsigned();
      table.integer("id_pergunta").unsigned().notNullable();
      table.foreign("autor").references("id").inTable("users");
      table.foreign("id_pergunta").references("id").inTable("perguntas");
    });
  };
  
  exports.down = function (knex) {
    return knex.schema.dropTable("respostas");
  };
  