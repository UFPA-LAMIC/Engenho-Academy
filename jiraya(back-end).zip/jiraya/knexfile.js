require("dotenv").config();

const dev_connection = {
    database: "plataforma",
    user: "admin",
    host: "127.0.0.1",
    password: "admin",
    timezone: "-03:00",
    dateStrings: true
};

const prod_connection = {}; // conexão para quando o sistema for para produção

module.exports = {

    client: "mysql",
    connection: dev_connection,
    pool: {
        min: 2,
        max: 10,
    },
    migrations: {
        tableName: "migrations",
    },
    seeds: {
        directory: "./seeds",
    },

};