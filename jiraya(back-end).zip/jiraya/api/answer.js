module.exports = (app) => {
    const limit = 25;
    
    const getAnswer = async (req, res) => {
      try {
        const page = req.query.page || 1;
        const result = await app
          .db("resposta")
          .count("id as count")
          .first();
        const count = parseInt(result.count);

        const respostas = await app
          .db("resposta")
          .select("resposta.*","users.email")
          .join("users", "resposta.autor", "=", "users.id")
          .limit(limit)
          .offset(page * limit - limit);
  
          const respostasFormated = respostas.map(form => {
            const [date, time] = form.dth_sistema.split(" ");
            const dataFormatada = date.split("-").reverse().join("/");
    
            const formatedDtsistema = dataFormatada + " " + time;
          
                  return { ...form, dth_sistema: formatedDtsistema };
                });
  
          res.json({ data: respostasFormated, count, limit });
      } catch (error) {
        res.status(500).send(error);
        console.log(error)
      }
    };
  
    const getAnswerById = async (req, res) => {
    
     const responsavel = await app
        .db("resposta")
        .join("users", "resposta.autor", "=", "users.id")
        .select("users.email");

      app
      .db("resposta")
        .select()
        .table("resposta")
        .where({ id: req.params.id })
        .first()
        .then((resposta) => {
          const [date, time] = resposta.dth_sistema.split(' ');
          const dateFormated = date.split("-").reverse().join("/");
          
          const formatedDtsistema = dateFormated + " " + time;
          
          res.json({ ...resposta, dth_sistema: formatedDtsistema, autor: responsavel });
        })
        .catch((err) => res.status(500).send(err));
      };
  
      const saveAnswer = async (req, res) => {
        try {
          const resposta = { ...req.body}
          console.log(req.body)
            const inserir = await app
              .db("resposta")
              .insert({...resposta})
            console.log(inserir)
            res.json(inserir)
        } catch (error) {
          res.status(500).send(error);
        }
      };
  
      const updateAnswer = async (req, res) => {
        try {
          const state = { ...req.body };
          
          const status = await app
            .db("resposta")
            .where({ id: req.params.id })
            .update({ 
              resposta: state.resposta,
              rank: state.rank,
              autor: state.autor
            });
            
          res.json(status);
        } catch (error) {
          res.status(500).send(error);
        }
      };

      const removeAnswer = async (req, res) => {
        try {
          const deletado = await app.db("resposta").where({ id: req.params.id }).del();
    
          res.json({ data: deletado });
        } catch (error) {
          console.log(error)
          res.status(500).send(error);
        }
      };
  
  
  return { getAnswer, getAnswerById, saveAnswer, updateAnswer, removeAnswer };
  
  }