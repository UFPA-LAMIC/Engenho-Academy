module.exports = (app) => {
    const limit = 20;
    
    const getAllMatriculas = async (req, res) => {
        try {

            const page = req.query.page || 1;
            
            const result = await app
            .db('matricula')
            .count("id as count")
            .first();
            
            const count = parseInt(result.count);
            
            const matricula = await app
            .db("matricula")
            .select()
            .limit(limit)
            .offset(page * limit - limit);

            console.log(matricula)

            res.json({ data: matricula, count, limit });
        } catch (error) {
            res.status(500).send(error)
        }
    }

    const getByAlunoAndCourseId = async (req, res) => {
        try {
            let { aluno, curso } = req.query

            const page = req.query.page || 1;
            
            const result = await app
            .db('matricula')
            .where("curso", "=", `${curso}`)
            .where("aluno", "=", `${aluno}`)
            .count("id as count")
            .first();
            
            const count = parseInt(result.count);
            
            const matricula = await app
            .db("matricula")
            .where("curso", "=", `${curso}`)
            .where("aluno", "=", `${aluno}`)
            .select()
            .limit(limit)
            .offset(page * limit - limit);

            console.log(matricula)

            res.json({ data: matricula, count, limit });
        } catch (error) {
            res.status(500).send(error)
        }
    };
    
    // selecionar todas as matrículas deferidas de um curso específico
    const getMatriculasDeferidas = async (req, res) => {
        try {
            const page = req.query.page || 1;
            
            const result = await app
            .db('matricula')
            .where({ curso: req.params.curso })
            .where("status","=","DEFERIDO")
            .leftJoin("users", "matricula.aluno", "=", "users.id")
            .count("matricula.id as count")
            .first();
            
            const count = parseInt(result.count);
            
            const matricula = await app
            .db("matricula")
            .where({ curso: req.params.curso })
            .where("status","=","DEFERIDO")
            .leftJoin("users", "matricula.aluno", "=", "users.id")
            .select("matricula.*","users.id as id_aluno","users.email", "users.nome")
            .limit(limit)
            .offset(page * limit - limit);

            console.log(matricula)

            res.json({ data: matricula, count, limit });
        } catch (error) {
            res.status(500).send(error)
        }
    }

    // selecionar todas as matrículas em análise de um curso específico
    const getMatriculasAnalise = async (req, res) => {
        try {
            const page = req.query.page || 1;
            
            const result = await app
            .db('matricula')
            .where({ curso: req.params.curso })
            .where("status","=","ANALISE")
            .leftJoin("users", "matricula.aluno", "=", "users.id")
            .count("matricula.id as count")
            .first();
            
            const count = parseInt(result.count);
            
            const matricula = await app
            .db("matricula")
            .where({ curso: req.params.curso })
            .where("status","=","ANALISE")
            .leftJoin("users", "matricula.aluno", "=", "users.id")
            .select("matricula.*","users.id as id_aluno","users.email", "users.nome")
            .limit(limit)
            .offset(page * limit - limit);

            console.log(matricula)

            res.json({ data: matricula, count, limit });
        } catch (error) {
            res.status(500).send(error)
        }
    }
    // selecionar todas as matrículas em análise de um curso específico
    const getMatriculasCurso = async (req, res) => {
        try {
            const page = req.query.page || 1;
            
            const result = await app
            .db('matricula')
            .where({ curso: req.params.curso })
            .leftJoin("users", "matricula.aluno", "=", "users.id")
            .count("matricula.id as count")
            .first();
            
            const count = parseInt(result.count);
            
            const matricula = await app
            .db("matricula")
            .where({ curso: req.params.curso })
            .leftJoin("users", "matricula.aluno", "=", "users.id")
            .select("matricula.*","users.id as id_aluno","users.email", "users.nome")
            .limit(limit)
            .offset(page * limit - limit);


            res.json({ data: matricula, count, limit });
        } catch (error) {
            res.status(500).send(error)
        }
    }

    const getCursosMatriculados = async (req, res) => {

        try {
          let {  id_user  } = req.query;
          
          if (id_user) id_user = id_user.trim();
          else id_user = "";

          const page = req.query.page || 1;
            
          const result = await app
          .db('matricula')
          .where('matricula.aluno', '=', `${id_user}`)
          .where('matricula.status', '=', 'DEFERIDO')
          .leftJoin("cursos", "matricula.curso", "=", "cursos.id")
          .count("matricula.id as count")
          .first();
        
          const count = parseInt(result.count);
        
          const curso = await app
          .db("matricula")
          .where('matricula.aluno', '=', `${id_user}`)
          .where('matricula.status', '=', 'DEFERIDO')
          .leftJoin("cursos", "matricula.curso", "=", "cursos.id")
          .select("cursos.id", "cursos.nome",  "cursos.data_inicio", "cursos.data_fim", "cursos.color", "cursos.docente",  "matricula.status")
          .limit(limit)
          .offset(page * limit - limit);
          
           res.json({ data: curso, count, limit });
            
        } catch (error) {
            res.status(500).send(error)
        }
    }

    const saveMatricula = async (req, res) => {
        try {
                const data = { ...req.body }
                const inserir = await app
                .db("matricula")
                .insert({ ...data });
                
                console.log('inserir',inserir)
                res.json(inserir)
        } catch(error){
            res.status(500).send(error)
        }
    }

    const updateMatricula = async (req,res) => {
        // let data = new Date();
        try {
            const state = { ...req.body }
            const updateStatus = await app
            .db("matricula")
            .where({ curso: req.params.curso })
            .where({ aluno: req.params.aluno })
            .update({
                status: state.status,
                // dt_analise: data
            });
            
            res.json(updateStatus);
        } catch(error) {
            res.status(500).send(error)
        }
    }
    return { getAllMatriculas, saveMatricula, updateMatricula, getMatriculasDeferidas, getMatriculasAnalise, getMatriculasCurso, getCursosMatriculados, getByAlunoAndCourseId }
}