const jwt = require("jwt-simple");
module.exports = (app) => {
    const limit = 25;
    
    const getCurso = async (req, res) => {
      try {
        let {  id_user  } = req.query;
          
        if (id_user) id_user = id_user.trim();
        else id_user = "";
 
        const page = req.query.page || 1;
        const result = await app
          .db("cursos")
          .count("id as count")
          .first();
        const count = parseInt(result.count);
        const curso = await app
          .db("cursos")
          .where("id", "=", `${id_user}`)
          .select("cursos.*",
          // app.db('videos')
          // .count('*')
          // .whereRaw('?? = ??', ['videos.curso', 'cursos.id'])
          // .as('videos'),
          // app.db('users')
          // .count('*')
          // .whereRaw('?? = ??', ['users.curso', 'cursos.id'])
          // .where('users.tipo', '=', 'DISCENTE') //Conta somente os discentes
          // .as('matriculados')
          )
          .limit(limit)
          .offset(page * limit - limit);

          const cursoFormated = curso.map(data => {
            const dataFormatadaInicio = data.data_inicio.split("-").reverse().join("/");
            const dataFormatadaFim = data.data_fim.split("-").reverse().join("/");
         
                return { ...data, data_inicio: dataFormatadaInicio, data_fim: dataFormatadaFim  };
            });
  
          res.json({ data: cursoFormated, count, limit });
      } catch (error) {
        res.status(500).send(error);
        console.log(error)
      }
    };

    // rota feita para o aluno ver todos os cursos da plataforma
    const getAllCursos = async (req, res) => {
      try {

        const docente = await app
          .db('cursos')
          .join('users', 'cursos.docente', '=', 'users.id')
          .select('users.nome')
          .first()

        const page = req.query.page || 1;
        const result = await app
          .db("cursos")
          .count("id as count")
          .first();
        const count = parseInt(result.count);
        const curso = await app
          .db("cursos")
          .select()
          .limit(limit)
          .offset(page * limit - limit);

          const cursoFormated = curso.map(data => {
            const dataFormatadaInicio = data.data_inicio.split("-").reverse().join("/");
            const dataFormatadaFim = data.data_fim.split("-").reverse().join("/");
         
                return { ...data, data_inicio: dataFormatadaInicio, data_fim: dataFormatadaFim, professor: docente  };
            });
  
          res.json({ data: cursoFormated, count, limit });
      } catch (error) {
        res.status(500).send(error);
        console.log(error)
      }
    };
  
    // Selecionar curso pelo id
    const getCursoById = async (req, res) => {
        try {
          const docente = await app
          .db('cursos')
          .join('users', 'cursos.docente', '=', 'users.id')
          .select('users.nome as docente')
          .first()
          
          const curso = await app
          .db("cursos")
          .where({ id: req.params.id })
          .select()
          .first()

          const dataInicio = curso.data_inicio.split('-').reverse().join('/')
          const dataFinal = curso.data_fim.split('-').reverse().join('/')

          res.json({...curso, data_inicio: dataInicio, data_fim: dataFinal, nomeDocente: docente});
        } catch (error) {
          console.log(error)
          res.status(500).send(error);
        }
    };

      // seleciona os cursos apenas daquele professor 
    const getCursosEspec = async (req, res) => {
        try {
          const page = req.query.page || 1;

          const result = await app
          .db("cursos")
          .leftJoin("users", "cursos.docente", "=", "users.id")
          .where({ docente: req.params.docente })
          .count("cursos.id as count")
          .first();

          const count = parseInt(result.count);

          const curso = await app
          .db("cursos")
          .leftJoin("users", "cursos.docente", "=", "users.id")
          .where({ docente: req.params.docente })
          .select("cursos.*", "users.nome as docente")
          .limit(limit)
          .offset(page * limit - limit);
          
          res.json({ data: curso, count, limit });
        } catch (error) {
          res.status(500).send(error);
        }
    };
    
  
      const saveCurso = async (req, res) => {
        try {
          const data = { ...req.body }

          await app
            .db("cursos")
            .insert(data)
            .returning('id')
            .then(([id]) => res.json({id: id}));  //id here
              
          
        } catch (error) {
          res.status(500).send(error);
        }
      };
  
      const updateCurso = async (req, res) => {
        try {
          const state = { ...req.body };
          
          const status = await app
            .db("cursos")
            .where({ id: req.params.id })
            .update(state);

            console.log(status)
          res.json(status);
        } catch (error) {
          res.status(500).send(error);
        }
      };

      // Selecionar todos os cursos ao qual o aluno foi deferido
      const getMatriculasCurso = async (req, res) => {

        try {
          let {  id_user  } = req.query;
          
          if (id_user) id_user = id_user.trim();
          else id_user = "";

          const page = req.query.page || 1;
            
          const result = await app
          .db('cursos')
          .where('matricula.aluno', '=', `${id_user}`)
          .leftJoin("cursos.id", "=", "matricula.curso")
          .leftJoin("matricula.aluno", "=", "users.id")
          .count("cursos.id as count")
          .first();
                
          const count = parseInt(result.count);
                
          const curso = await app
          .db("cursos")
          .where('matricula.aluno', '=', `${id_user}`)
          .leftJoin("cursos.id", "=", "matricula.curso")
          .leftJoin("matricula.aluno", "=", "users.id")
          .select("cursos.id", "cursos.nome",  "cursos.data_inicio", "cursos.data_fim", "matricula.status", "users.id as id_aluno", "users.nome as aluno")
          .limit(limit)
          .offset(page * limit - limit);
     
           res.json({ data: curso, count, limit });
            
        } catch (error) {
            res.status(500).send(error)
        }
    }

    // só consegue deletar cursos que não possuam alunos matriculados 
  const removeCurso = async (req, res) => {
    try {
      const deletado = await app.db("cursos").where({ id: req.params.id }).del();

      res.json({ data: deletado });
    } catch (error) {
      res.status(500).send(error);
    }
  };
  
  
  return { getCurso, getAllCursos, getCursoById, saveCurso, updateCurso, getMatriculasCurso, getCursosEspec, removeCurso };
  
}
