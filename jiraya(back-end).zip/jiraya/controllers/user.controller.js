const User = require("../models/user.model.js");
const bcrypt = require("bcrypt");

const UserController = {
  async createUser(req, res) {
    try {
      const user = req.body;
      console.log(user)

      if (user.password) {
        if (user.password !== user.confirmPassword) {
          return res.status(401).json({ msg: "Different passwords!" });
        }
        
        delete user.confirmPassword;
        const hashedPassword = await bcrypt.hash(user.password, 10);
        const hasSignedUp = await User.findUserByEmail(user.email)
        console.log(hasSignedUp)
        if (hasSignedUp) {
          return res.status(400).json({ msg: "User already registered" });
        }
        await User.createUser({ ...user, password: hashedPassword });
        return res.status(200).json({ msg: "new user created with password" });
      }

      await User.createUser(user);
      res.status(200).json({ msg: "new user created" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller createUser - ${error.message}` });
    }
  },
  async getAllUsers(req, res) {
    try {
      let params = req.query;
      const limit = params.limit;

      params.nome = params.nome?.trim() || "";
      params.email = params.email?.trim() || "";

      const users = await User.findAllUsers(params);

      res.status(200).json({
        ...users,
        limitStats: limit,
      });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getAllUsers - ${error.message}` });
    }
  },

  async getUserById(req, res) {
    const id = req.params.id;
    try {
      const user = await User.findUserById(id);
      res.status(200).json(user);
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getUserById - ${error.message}` });
    }
  },

  async editUser(req, res) {
    const user = req.body;
    const id = req.params.id;
    try {
      await User.editUser(user, id);
      res.status(200).json({ msg: "user edited!" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getUserById - ${error.message}` });
    }
  },
};

module.exports = UserController;
