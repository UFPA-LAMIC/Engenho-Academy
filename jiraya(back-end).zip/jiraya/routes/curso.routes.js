const express = require('express')
const router = express.Router()
const CursoController = require('../controllers/curso.controller.js')

// Require the authenticate middleware
const { authenticate } = require('../middlewares/auth');

const roles = ['DOCENTE', 'DISCENTE']
const docente = ['DOCENTE']

//Routes for curso crud operations
router.post('/', authenticate(docente), CursoController.createCurso)
router.get('/', CursoController.findAllCursos)
router.get('/:id', CursoController.getCursoById)
router.put('/:id', authenticate(roles), CursoController.editCurso)
router.get('/matriculados/:id', authenticate(roles), CursoController.findAllCursosMatriculados)
router.get('/instrutor/:id', authenticate(roles), CursoController.findAllCursosOfDocente)

module.exports = router