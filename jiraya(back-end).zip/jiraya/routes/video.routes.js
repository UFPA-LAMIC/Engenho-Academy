const express = require('express')
const router = express.Router()
const VideoController = require('../controllers/video.controller.js')

// Require the authenticate middleware
const { authenticate } = require('../middlewares/auth');

const roles = ['DOCENTE', 'DISCENTE']

router.post('/', VideoController.createVideo)
router.get('/', authenticate(roles), VideoController.getAllVideos)
router.get('/:id', authenticate(roles), VideoController.getVideoById)
router.get('/curso/:id_curso', authenticate(roles), VideoController.getAllVideosFromThatCourse)
router.put('/:id', authenticate(roles), VideoController.editVideo)

module.exports = router