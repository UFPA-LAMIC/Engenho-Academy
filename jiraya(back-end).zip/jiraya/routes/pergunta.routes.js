const express = require('express')
const router = express.Router()
const PerguntaController = require('../controllers/pergunta.controller.js')

// Require the authenticate middleware
const { authenticate } = require('../middlewares/auth');

const roles = ['DOCENTE', 'DISCENTE']
const docente = ['DOCENTE']

//Routes for pergunta crud operations
router.post('/', authenticate(roles), PerguntaController.createPergunta)
router.get('/', authenticate(roles), PerguntaController.findAllPerguntas)
// router.get('/:id', authenticate(roles), PerguntaController.getPerguntaById)

module.exports = router