const db = require("../config/db");
const { formatDate, formatDatetime } = require("../utils");

const Pergunta = {
  async createPergunta(pergunta) {
    try {
      const perguntaId = await db("perguntas").insert(pergunta);
      return perguntaId[0];
    } catch (error) {
      throw new Error(`Erro no endpoint createPergunta - ${error.message}`);
    }
  },
  async findAllPerguntas(param) {
    try {
      const [count, getPerguntas] = [
        await db("perguntas").count("id as count").first(),

        await db("perguntas")
          .select(
            "perguntas.*",
            "respostas.id as id_resposta",
            "respostas.dth_sistema as data_resposta",
            "respostas.id_pergunta",
            "respostas.resposta",
            "users.nome as autor_pergunta",
            "usuarios.nome as autor_resposta",
          )
          .leftJoin("respostas", "perguntas.id", "=", "respostas.id_pergunta")
          .leftJoin("users", "perguntas.autor", "=", "users.id")
          .leftJoin("users as usuarios", "respostas.autor", "=", "usuarios.id")
          .orderBy("perguntas.id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const perguntasFormated = [];
      const idMap = {};

      getPerguntas.forEach((item) => {
        if (!idMap[item.id]) {
          idMap[item.id] = {
            id: item.id,
            dth_sistema: item.dth_sistema,
            autor: item.autor_pergunta,
            video: item.video,
            pergunta: item.pergunta,
            dth_sistema: item.dth_sistema,
            respostas: [],
          };
          perguntasFormated.push(idMap[item.id]);
        }
        if(item.resposta) {
          idMap[item.id].respostas.push({
            id: item.id_resposta,
            dth_sistema: item.data_resposta,
            autor: item.autor_resposta,
            id_pergunta: item.id_pergunta,
            resposta: item.resposta,
          });
        }
      });

      const perguntas = {
        data: perguntasFormated,
        ...count,
      };
      return perguntas;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllSim - ${error.message}`);
    }
  },
};

module.exports = Pergunta;
