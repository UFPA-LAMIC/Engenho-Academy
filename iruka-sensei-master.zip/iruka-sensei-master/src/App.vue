<template>
  <v-app id="app">
    <div>
      <toolbar />
      <div class="container-page">
        <div class="view">
          <router-view />
        </div>
      </div>
      <Footer />
      <Vlibras />
    </div>
  </v-app>
</template>

<script>
import Footer from "@/components/Footer.vue";
import Toolbar from "@/components/Toolbar.vue";
import axios from "axios";
import { baseApiUrl } from "./global";
import Vlibras from "@/components/VLibras.vue";
export default {
  name: "App",

  components: {
    Toolbar,
    Footer,
    Vlibras,
  },
  data: () => ({}),
  created() {
    this.verifyToken();
    this.authToken();
    this.$bus.$on("reload", this.authToken);
  },
  methods: {
    verifyToken() {
      const token = this.$getToken();
      const user = this.$getLoggedUser();

      if (!token) {
        if (user) {
          this.$removeLoggedUser();
        }
        // this.$router.push({ name: "home" });
        return;
      }

      axios
        .post(`${baseApiUrl}/verify-token`, { token })
        .then((response) => {
          if (response.data.expired) {
            this.$removeLoggedUser();
            this.$removeToken();
            // this.$router.push({ name: "home" });
            return;
          }
        })
        .catch(() => {
          this.$router.push({ name: "login" });
        });
    },
    authToken() {
      axios.defaults.headers.common["Authorization"] =
        "Bearer " + this.$getToken();
    },
  },
};
</script>
<style lang="scss">
* {
  /* box-sizing: border-box !important;
  margin: 0 !important;
  padding: 0 !important; */
}
.view {
  min-height: 100vh;
  width: 100%;
}

p,
h1,
h2,
h3,
h4,
h5 {
  color: $black;
}
</style>