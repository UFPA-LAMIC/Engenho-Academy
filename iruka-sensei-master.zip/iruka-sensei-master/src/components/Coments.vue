<template>
  <div class="subs pr-3 pb-3">
    <v-avatar class="mr-2" color="indigo" size="28">
      <span class="white--text text-h8">LP</span>
    </v-avatar>
    <span style="color: black; font-size: 0.8rem">{{ autor }}</span>
    <div class="rating text-end pb-3">
      <!-- Se resposta não foi avaliada -->
      <v-rating
        v-if="!rank && tipo === 'DOCENTE'"
        v-model="propModel"
        background-color="orange lighten-3"
        color="orange"
        small
      ></v-rating>
      <v-btn
        v-if="!rank && tipo === 'DOCENTE'"
        class="mx-2"
        fab
        dark
        x-small
        color="success"
        @click="$emit('updateRank')"
      >
        <!-- @click="(forum.id = item.id), updateForum('rank')" -->
        <v-icon dark> mdi-check-bold </v-icon>
      </v-btn>
      <!-- Se resposta foi avaliada -->
      <v-rating
        v-if="rank"
        v-model="rank"
        readonly
        background-color="orange lighten-3"
        color="orange"
        small
      ></v-rating>
    </div>
  </div>
</template>

<script>
export default {
  name: "Coments",
  data: () => ({
    rankModel: null,
  }),
  props: {
    autor: {
      type: String,
    },
    coment: {
      type: String,
    },
    rank: {
      type: Number,
    },
    semRank: {
      type: Number,
    },
    tipo: {
      type: String,
    },
  },
  watch: {
    ranked() {
      console.log(this.semRank);
    },
  },
  computed: {
    propModel: {
      get() {
        return this.semRank;
      },
      set(value) {
        this.$emit("update:semRank", value);
      },
    },
  },
};
</script>

<style>
</style>