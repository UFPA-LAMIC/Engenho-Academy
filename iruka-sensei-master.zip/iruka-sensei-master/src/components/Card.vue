<template>
  <div class="card" @click="redirect">
    <img
      class="card-image"
      src="@/assets/no_image_course.png"
      alt="Card Image"
    />
    <h3 class="card-title">{{ titulo }}</h3>
    <p class="card-description">{{ docente }}</p>
    <span class="card-footer">{{ numberOfVideos }} vídeos</span>
    <span
      class="card-status"
      :class="{
        'status-0': status === 0,
        'status-1': status === 1,
        'status-2': status === 2,
        'status-none': status === null || status === undefined,
      }"
      >{{ statusText() }}</span
    >
  </div>
</template>

<script>
export default {
  data: () => ({
    statusNumber: null,
  }),
  props: {
    redirectTo: {
      type: String,
      default: "home",
    },
    titulo: {
      type: String,
      default: "Título do Vídeo",
    },
    docente: {
      type: String,
      default: "Docente",
    },
    numberOfVideos: {
      type: Number,
      default: 0,
    },
    status: {
      type: Number,
      default: null,
    },
    idCurso: {},
  },
  methods: {
    redirect() {
      // this.$router.push({ name: `${this.redirectTo}` }).catch(() => {});
      this.$router
        .push({
          name: `${this.redirectTo}`,
          params: { id: this.idCurso },
        })
        .catch(() => {});
    },
    statusText() {
      switch (this.status) {
        case 0:
          return "Em análise";
        case 1:
          return "Matriculado";
        case 2:
          return "Não matriculado";
        default:
          return "Matricule-se já";
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.card {
  background-color: #fff;
  // border: 1px solid #e0e0e0;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(33, 33, 33, 0.1);
  padding-bottom: 15px;
  box-sizing: border-box;
  transition: transform 0.2s, box-shadow 0.2s;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  height: 100%;
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
  cursor: pointer;
}

.card-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 8px 8px 0 0;
  margin-bottom: 16px;
}

.card-title {
  font-size: 1.25rem;
  font-weight: bold;
  margin: 8px 0;
}

.card-description {
  font-size: 1rem;
  color: #555;
  margin: 8px 0;
  flex-grow: 1;
}

.card-footer {
  font-size: 0.875rem;
  color: #888;
  margin-top: auto;
}

.card-status {
  font-size: 0.875rem;
  margin-top: 8px;
  padding: 4px 8px;
  border-radius: 4px;
}

.status-0 {
  background-color: rgb(253, 173, 25); /* Amarelo para status 0 */
  color: #000;
}

.status-1 {
  background-color: #00cc66; /* Verde para status 1 */
  color: #fff;
}

.status-2 {
  background-color: #e02222; /* Vermelho para status 2 */
  color: #fff;
}

.status-none {
  background-color: #cccccc; /* Cinza para nenhum status */
  color: #000;
}

// @media screen and (max-width: 1660px) {
//   .course-card {
//     width: 90%;
//     min-height: 300px;
//   }

//   .course-img {
//     width: 90%;
//   }
// }
</style>