<template>
  <div class="px-5 pt-3">
    <v-card>
      <v-tabs>
        <v-tabs-slider color="green"></v-tabs-slider>
        <v-tab @click="tab = 'det'">Detalhes </v-tab>
        <v-tab @click="tab = 'for'">Fórum</v-tab>
      </v-tabs>
    </v-card>

    <Detalhes
      v-if="tab === 'det'"
      class="pa-3 my-3"
      :key="tab"
      :resumo="resumo_video"
      color="#F3F3F3"
    />

    <v-card v-if="tab === 'for'" :key="tab" class="pa-3 my-3" color="#F3F3F3">
      <v-row v-if="mode === 'pesquisar'">
        <v-col cols="12" sm="6" md="9">
          <v-text-field
            v-model="quest"
            dense
            placeholder="Pesquisar dúvidas"
            outlined
            @change="loadPergunta"
          >
            <v-icon slot="append" color="secondary" @click="loadPergunta">
              mdi-magnify
            </v-icon>
            <v-icon slot="append" color="secondary" @click="cancel">
              mdi-close
            </v-icon>
          </v-text-field>
        </v-col>
        <v-col>
          <div class="text-end">
            <v-btn
              color="primary"
              small
              @click="(mode = 'adicionar'), (quest = '')"
              class="mr-2"
              >publicar pergunta</v-btn
            >
          </div>
        </v-col>
      </v-row>

      <!-- ADICIONAR PERGUNTA -->

      <v-row v-if="mode === 'adicionar'">
        <v-col cols="12" sm="6" md="12">
          <resposta
            :placeholder="'Publique aqui a sua pergunta ou dúvida quanto ao conteúdo'"
            :texto.sync="pergunta.pergunta"
            @input="
              (pergunta.autor = getUser.id),
                (pergunta.aula = id_video),
                insertPergunta()
            "
            @cancel="mode = 'pesquisar'"
          />
        </v-col>
      </v-row>

      <v-snackbar
        v-model="snackbar"
        :timeout="timeout"
        color="success"
        outlinedI
      >
        {{ snackbarText }}
      </v-snackbar>

      <!-- LIST PERGUNTAS -->

      <v-row justify="center" class="mb-5" v-if="quest">
        <v-expansion-panels>
          <v-expansion-panel
            v-for="item in perguntas"
            :key="item.id"
            class="mb-2"
          >
            <v-expansion-panel-header
              color="rgb(194, 216, 235)"
              @click="responder = false"
            >
              <div id="infos" v-html="item.pergunta"></div>
            </v-expansion-panel-header>
            <v-card>
              <v-expansion-panel-content class="pt-3">
                <!-- Se a pergunta tiver resposta -->
                <div
                  v-for="resposta in item.respostas"
                  :key="resposta.resposta"
                >
                  <div class="texto-resp-coment mb-3">
                    <v-card
                      v-if="item.id_resposta"
                      class="card-resp pa-5 mb-3"
                      color="rgba(231, 230, 226, 0.911)"
                    >
                      <Coments
                        :autor="resposta.autor_resposta"
                        :rank="resposta.rank"
                        :semRank.sync="forum.rank"
                        :tipo="getUser.tipo"
                        @updateRank="updateForum(resposta.id, 'rank')"
                      />
                      <div class="texto-resp-coment mb-3">
                        <div id="infos" v-html="resposta.resposta"></div>
                      </div>
                    </v-card>
                    <!-- Senão tiver resposta -->
                    <Resposta
                      v-if="!item.id_resposta"
                      :texto.sync="resp.resposta"
                      @input="submit(getUser.id, item.id)"
                    />
                  </div>
                </div>
                <!-- Se não tiver comentários-->
                <div v-if="item.total_respostas <= 5">
                  <v-btn
                    class="mt-3"
                    text
                    icon
                    color="rgb(30, 124, 201)"
                    @click="responder = !responder"
                  >
                    <v-icon>mdi-comment-processing-outline</v-icon>
                  </v-btn>
                </div>
                <!-- Resposta quando clicar no ícone de comentar -->
                <Resposta
                  v-if="responder"
                  :texto.sync="resp.resposta"
                  @input="submit(getUser.id, item.id)"
                  @cancel="responder = false"
                />
              </v-expansion-panel-content>
            </v-card>
          </v-expansion-panel>
        </v-expansion-panels>
      </v-row>
    </v-card>
  </div>
</template>
<script>
import Coments from "../components/Coments.vue";
import Resposta from "../components/Resposta.vue";
import Detalhes from "../features/Detalhes.vue";
import axios from "axios";
import { baseApiUrl } from "../global";
import { mapGetters } from "vuex";
export default {
  name: "Perguntas",
  props: {
    resumo_video: String,
    id_video: Number,
  },
  computed: mapGetters(["getUser"]),
  components: { Detalhes, Coments, Resposta },
  data: function () {
    return {
      mode: "pesquisar",
      perguntas: [],
      resp: {},
      responder: false,
      comment: [],
      pergunta: {},
      forum: {},
      quest: "",
      tab: "det",
      snackbar: false,
      timeout: 3000,
      snackbarText: "",
      coment: "",
    };
  },
  methods: {
    async loadPergunta() {
      try {
        const response = await axios.get(
          `${baseApiUrl}/question/${this.id_video}?quest=${this.quest}`
        );
        this.perguntas = response.data.data;
      } catch (error) {
        console.error(error);
      }
    },
    async loadAnswer() {
      try {
        const response = await axios.get(`${baseApiUrl}/answer`);
        this.answer = response.data.data;
      } catch (error) {
        console.error(error);
      }
    },
    insertPergunta() {
      console.log(this.perguntas);
      axios
        .post(`${baseApiUrl}/question`, this.pergunta)
        .then(() => {
          this.publicarPergunta();
        })
        .catch((error) => {
          alert(error.response.data.msg);
        });
    },
    insertResposta() {
      axios
        .post(`${baseApiUrl}/answer`, this.resp)
        .then(() => {
          console.log("inseriu resposta");
          this.snackbar = true;
          this.snackbarText =
            "Resposta publicada com sucesso, aguarde a resposta";
          this.resp = {};
        })
        .catch((error) => {
          alert(error.response.data.msg);
        });
    },
    async updateForum(id, what) {
      console.log(this.forum);
      await axios
        .put(`${baseApiUrl}/answer/${id}`, this.forum)
        .then(() => {
          this.clear(what);
        })
        .catch((error) => {
          alert(error.response.data.msg);
        });
    },
    async getUsusario(id) {
      try {
        const response = await axios.get(`${baseApiUrl}/users/${id}`);
        const user = response.data.data.email;
        console.log("user - ", user);
        return user;
      } catch (error) {
        console.error(error);
      }
    },
    submit(id_autor, id_pergunta) {
      this.resp.autor = id_autor;
      this.resp.id_pergunta = id_pergunta;
      this.insertResposta();
    },
    publicarPergunta() {
      this.snackbar = true;
      this.snackbarText = "Pergunta publicada com sucesso, aguarde a resposta";
      this.mode = "pesquisar";
      this.pergunta = {};
      this.loadPergunta();
    },
    clear(what) {
      this.snackbar = true;
      what === "rank"
        ? (this.snackbarText = "Avaliação publicada com sucesso")
        : (this.snackbarText = "Comentário publicado com sucesso");
      this.coment = "";
      this.forum = {};
      this.loadPergunta();
    },
    clearComent() {
      this.forum = {};
      this.coment = "";
      this.mode = "pesquisar";
    },
    cancel() {
      (this.quest = ""), (this.perguntas = []);
    },
  },
  mounted() {
    this.loadPergunta();
  },
};
</script>
<style>
#clicavel {
  cursor: pointer;
}
/* .autor-ranking {
  background-color: chocolate;
  display: flex;
  flex-direction: column;
  justify-items: flex-end;
  align-items: center;
} */
.subs {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
.texto-resp-coment {
  display: flex;
  flex-direction: column;
}
.rating {
  display: flex;
  justify-content: flex-start;
}
</style>

/* 
- Pergunta:   id_autor, id_aula, texto, date
- Resposta:   id_autor, id_pergunta, texto, date
- Comentario: id_autor, id_resposta, texto, date

perguntas: [
  {
    pergunta: { autor, texto, date },
    respostas: [
      {
        autor, texto, comentarios: [
          { autor, texto }
        ]
      },
      {
        autor, texto, comentarios: []
      }
    ],
  }
]

var arr1 = [
  { id: 1, nome: "luan" },
  { id: 2, nome: "Iglan" },
  { id: 3, nome: "Renan" },
];
var arr2 = [
  { id: 1, sobrenome: "Paiva" },
  { id: 2, sobrenome: "Cardeal" },
  { id: 3, sobrenome: "Bastos" },
];
var arr3 = [
  { id: 1, altura: 1.71 },
  { id: 2, altura: 1.98 },
  { id: 3, altura: 1.73 },
];

const finalObj = arr1.map(obj => {
  const temp = {}

  arr2.filter(item => item.id === obj.id).forEach(i => temp.sobrenome = i.sobrenome)
  arr3.filter(item => item.id === obj.id).forEach(i => temp.altura = i.altura)

  return { ...obj, ...temp }
})

console.log(finalObj)
*/