import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify'
import router from './router'
import store from './store'
import eventBus from "./plugins/eventBus";

import loggedUser from "./plugins/loggedUser";
import SnackbarPlugin from './plugins/snackbar/snackbar'
// import "@/assets/styles/global.scss";

import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'
import VueEditor from 'vue2-editor'

Vue.use(BootstrapVue)
Vue.use(IconsPlugin)
Vue.use(VueEditor)
Vue.use(vuetify);
Vue.use(router);
Vue.use(loggedUser);
Vue.use(eventBus);
Vue.use(SnackbarPlugin)

Vue.config.productionTip = false

new Vue({
  store,
  router,
  vuetify,
  beforeCreate() {
    this.$store.commit("SET_USER", this.$getLoggedUser());
  },
  render: h => h(App)
}).$mount('#app')
