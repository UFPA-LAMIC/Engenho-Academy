export default [
  {
    path: "/descricao-curso/:id",
    name: "Descrição do Curso",
    component: () => import("@/modules/curso/views/DescricaoCurso.vue"),
  },
  {
    path: "/curso",
    name: "Curso",
    component: () => import("@/modules/curso/views/AssistirCurso.vue"),
  },
  {
    path: "/video-aulas/curso/:id",
    name: "video",
    component: () => import("@/modules/curso/views/AssistirCurso.vue"),
  },
  {
    path: "/editar-curso/:id",
    name: "Editar curso",
    component: () => import("@/modules/curso/views/EditarCurso.vue"),
  },
  {
    path: "/acompanhar-matriculas-curso/:id",
    name: "Matriculas curso",
    component: () => import("@/modules/curso/views/AcompanharMatricula.vue"),
  },
  {
    path: "/meus-cursos",
    name: "Meus Cursos",
    component: () => import("@/modules/curso/views/MeusCursos.vue"),
  },
  {
    path: "/cadastrar-curso",
    name: "Cadastrar Curso",
    component: () => import("@/modules/curso/views/CadastrarCurso.vue"),
  },
];
