<template>
  <base-page-layout>
    <div class="form-curso">
      <h2 class="mb-5">Cadastrar Curso</h2>
      <aside>
        <label class="teste" for="instrutor">Instrutor</label>
        <v-text-field
          class="campo-read mb-5"
          id="instrutor"
          v-model="user.nome"
          outlined
          hide-details
          readonly
        ></v-text-field>
        <label for="titulo">Título do curso</label>
        <v-text-field
          class="campo mb-5"
          id="titulo"
          v-model="curso.nome"
          outlined
          hide-details
          placeholder="Título do curso"
        ></v-text-field>
      </aside>
      <aside class="editor mb-5">
        <label for="aprendizado">O que o aluno aprenderá</label>
        <vue-editor
          v-model="curso.aprendizado"
          id="aprendizado"
          :editorToolbar="customToolbar"
        />
      </aside>
      <aside class="editor">
        <label for="descricao">Descrição</label>
        <vue-editor
          v-model="curso.descricao"
          id="descricao"
          :editorToolbar="customToolbar"
        />
      </aside>
      <div class="submit-btn">
        <v-btn color="#108068" outlined @click="submit">salvar</v-btn>
      </div>
    </div>
  </base-page-layout>
</template>
  
  <script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import { VueEditor } from "vue2-editor";
import { mapState } from "vuex";
import axios from "axios";
import { baseApiUrl } from "@/global";

export default {
  components: { VueEditor, BasePageLayout },
  data: () => ({
    curso: {},
    video: {},
    customToolbar: [
      [{ header: [false, 1, 2, 3, 4, 5, 6] }],
      ["bold", "italic", "underline", "strike"], // toggled buttons
      [{ align: [] }],
      ["blockquote", "code-block"],
      [{ list: "ordered" }, { list: "bullet" }, { list: "check" }],
      [{ indent: "-1" }, { indent: "+1" }], // outdent/indent
      [{ color: [] }, { background: [] }], // dropdown with defaults from theme
      ["link"],
      ["clean"], // remove formatting button
    ],
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
  },
  methods: {
    async submit() {
      try {
        this.curso = { ...this.curso, docente: this.user.id };
        await axios.post(`${baseApiUrl}/cursos`, this.curso);
        this.$snackbar({
          message: "Curso cadastrado com sucesso!",
          color: "#00b395",
          timeout: 4000,
        });
        this.$router.push({ name: "Meus Cursos" }).catch(() => {});
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao cadastrar usuário",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.form-curso {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-family: $primary_font;
}
.teste {
  margin-top: 20px;
}
.editor {
  width: 800px;
}
.campo,
.campo-read {
  width: 800px;
}
.campo-read {
  background-color: #f5f5f5;
}
.submit-btn {
  text-align: end;
  width: 800px;
  margin: 20px 0;
}
.submit-btn button {
  text-transform: capitalize;
}
</style>