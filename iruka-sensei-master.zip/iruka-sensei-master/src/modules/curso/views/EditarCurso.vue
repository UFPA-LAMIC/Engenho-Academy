<template>
  <base-page-layout>
    <div class="form-curso">
      <h2 class="mb-5">Cadastrar Curso</h2>
      <aside>
        <label class="teste" for="instrutor">Instrutor</label>
        <v-text-field
          class="campo-read mb-5"
          id="instrutor"
          v-model="user.nome"
          outlined
          hide-details
          readonly
        ></v-text-field>
        <label for="titulo">Título do curso</label>
        <v-text-field
          class="campo mb-5"
          id="titulo"
          v-model="curso.nome"
          outlined
          hide-details
          placeholder="Título do curso"
        ></v-text-field>
      </aside>
      <aside class="editor mb-5">
        <label for="aprendizado">O que o aluno aprenderá</label>
        <vue-editor
          v-model="curso.aprendizado"
          id="aprendizado"
          :editorToolbar="customToolbar"
        />
      </aside>
      <aside class="editor">
        <label for="descricao">Descrição</label>
        <vue-editor
          v-model="curso.descricao"
          id="descricao"
          :editorToolbar="customToolbar"
        />
      </aside>
    </div>

    <div class="form-curso mt-5">
      <h2 class="my-5">Cadastrar vídeos</h2>
      <aside>
        <label for="titulo">Título do vídeo</label>
        <v-text-field
          class="campo mb-5"
          id="titulo"
          v-model="video.titulo"
          outlined
          hide-details
          placeholder="Título do curso"
        ></v-text-field>
        <label for="titulo">URL</label>
        <v-text-field
          class="campo mb-5"
          id="titulo"
          v-model="video.url"
          outlined
          hide-details
          placeholder="Título do curso"
        ></v-text-field>
        <label for="titulo">Ordem na lista</label>
        <v-text-field
          class="campo mb-5"
          id="titulo"
          v-model="video.ordem"
          type="number"
          outlined
          hide-details
          placeholder="Título do curso"
        ></v-text-field>
      </aside>

      <div class="">
        <v-btn color="primary" outlined dense @click="submitVideo"
          >Adicionar vídeo</v-btn
        >
      </div>

      <aside class="video-list" v-if="videos">
        <ol>
          <li v-for="vid in videos" :key="vid.id" class="mb-5">
            {{ vid.titulo }} - {{ vid.url }}
          </li>
        </ol>
      </aside>
      <div class="submit-btn">
        <v-btn color="#108068" outlined @click="editCurso">salvar</v-btn>
      </div>
    </div>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import { VueEditor } from "vue2-editor";
import { mapState } from "vuex";
import axios from "axios";
import { baseApiUrl } from "@/global";

export default {
  components: { VueEditor, BasePageLayout },
  data: () => ({
    curso: {},
    video: {},
    videos: [],
    customToolbar: [
      [{ header: [false, 1, 2, 3, 4, 5, 6] }],
      ["bold", "italic", "underline", "strike"], // toggled buttons
      [{ align: [] }],
      ["blockquote", "code-block"],
      [{ list: "ordered" }, { list: "bullet" }, { list: "check" }],
      [{ indent: "-1" }, { indent: "+1" }], // outdent/indent
      [{ color: [] }, { background: [] }], // dropdown with defaults from theme
      ["link"],
      ["clean"], // remove formatting button
    ],
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
  },
  mounted() {
    this.getCursoInfos();
    this.getVideos();
  },
  methods: {
    async getCursoInfos() {
      const response = await axios.get(
        `${baseApiUrl}/cursos/${this.$route.params.id}`
      );
      this.curso = response.data;
    },

    async getVideos() {
      const response = await axios.get(
        `${baseApiUrl}/videos/curso/${this.$route.params.id}`
      );
      this.videos = response.data.data;
    },

    async editCurso() {
      const cursoEdited = {
        nome: this.curso.nome,
        aprendizado: this.curso.aprendizado,
        descricao: this.curso.descricao,
      };

      try {
        await axios.put(`${baseApiUrl}/cursos/${this.curso.id}`, cursoEdited);
        this.$snackbar({
          message: "Curso editado com sucesso!",
          color: "#00b395",
          timeout: 4000,
        });
        this.$router
          .push({ name: "Descrição do Curso", params: { id: this.curso.id } })
          .catch(() => {});
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao cadastrar usuário",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },

    async submitVideo() {
      try {
        this.video = { ...this.video, curso: this.curso.id };
        await axios.post(`${baseApiUrl}/videos`, this.video);
        this.$snackbar({
          message: "Curso cadastrado com sucesso!",
          color: "#00b395",
          timeout: 1000,
        });
        this.video = {};
        this.getVideos();
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao cadastrar usuário",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
  },
};
</script>
  <style lang="scss" scoped>
.form-curso {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-family: $primary_font;
}
.teste {
  margin-top: 20px;
}
.editor {
  width: 800px;
}
.campo,
.campo-read {
  width: 800px;
}
.campo-read {
  background-color: #f5f5f5;
}
.submit-btn {
  text-align: end;
  width: 800px;
  margin: 20px 0;
}
.submit-btn button {
  text-transform: capitalize;
}
.video-list {
  border: 1px solid #ccc;
  width: 800px;
  padding: 20px;
  margin: 20px 0;
}
</style>