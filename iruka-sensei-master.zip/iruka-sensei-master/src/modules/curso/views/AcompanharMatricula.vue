<template>
  <base-page-layout has-no-style>
    <div class="header-description">
      <h3>{{ curso.nome }}</h3>
      <p>
        <span>Criado por</span> <strong>{{ curso.criador }}</strong>
      </p>
    </div>
    <aside class="content">
      <div>
        <Card
          :id-curso="curso.id"
          :titulo="curso.nome"
          :docente="curso.responsavel"
        />
      </div>
      <div class="matricula-table ml-5">
        <v-data-table
          :headers="headers"
          :items="matriculas"
          class="elevation-1"
        >
          <template v-slot:item="{ item }">
            <tr>
              <td>{{ item.aluno }}</td>
              <td>{{ item.nome_aluno }}</td>
              <td>
                <v-chip :color="color(item.status)" dark>
                  {{ statusText(item.status) }}
                </v-chip>
              </td>
              <td>
                <v-btn icon @click="changeMatriculaStatus(item.id, 1)">
                  <v-icon color="#53D800">mdi-check-circle-outline</v-icon>
                </v-btn>
                <v-btn icon @click="changeMatriculaStatus(item.id, 2)">
                  <v-icon color="#FF5252">mdi-close-circle-outline</v-icon>
                </v-btn>
              </td>
            </tr>
          </template>
        </v-data-table>
      </div>
    </aside>
    <aside>
      <!-- <h4>Avaliação do curso</h4> -->
    </aside>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
import Card from "@/components/Card.vue";
import { mapState } from "vuex";
export default {
  components: { BasePageLayout, Card },
  data: () => ({
    redirect: null,
    curso: {},
    matriculas: [],
    isDocente: false,
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
    headers() {
      return [
        {
          text: "Código",
          value: "aluno",
          width: "10%",
        },
        {
          text: "Nome",
          value: "nome_aluno",
          width: "20%",
        },
        {
          text: "Status",
          value: "status",
          width: "15%",
        },
        {
          text: "Ações",
          value: "",
          width: "15%",
        },
      ];
    },
  },
  mounted() {
    this.whichPageMustShow();
    this.getMatriculasByCurso();
    this.getCursoInfos();
    window.scrollTo(0, 0);
  },
  methods: {
    whichPageMustShow() {
      if (!this.$isLogged()) {
        return;
      }

      this.user.tipo === "DOCENTE"
        ? (this.isDocente = true)
        : (this.isDocente = false);
    },
    async getCursoInfos() {
      if (!this.isDocente) {
        return;
      }
      try {
        const response = await axios.get(
          `${baseApiUrl}/cursos/${this.$route.params.id}`
        );
        this.curso = response.data;
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao cadastrar usuário",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    async getMatriculasByCurso() {
      if (!this.isDocente) {
        this.$router.push("/home");
        return;
      }
      try {
        const response = await axios.get(
          `${baseApiUrl}/matriculas/curso/${this.$route.params.id}`
        );
        this.matriculas = response.data.data;
        console.log(this.matriculas);
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao cadastrar usuário",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    async changeMatriculaStatus(id, status) {
      const matricula = {
        id,
        status,
      };

      try {
        await axios.put(
          `${baseApiUrl}/matriculas/curso/${this.curso.id}`,
          matricula
        );

        if (matricula.status === 1) {
          this.$snackbar({
            message: "Aluno deferido no curso.",
            color: "#00b395",
            timeout: 3000,
          });
        } else {
          this.$snackbar({
            message: "Aluno indeferido no curso.",
            color: "#e02222",
            timeout: 3000,
          });
        }

        this.getMatriculasByCurso();
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao mudar status de matrícula",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    color(status) {
      if (status === 1) {
        return "#53D800";
      } else if (status === 2) {
        return "#FF5252";
      } else {
        return "#afb5bd";
      }
    },
    statusText(status) {
      if (status === 1) {
        return "Deferido";
      } else if (status === 2) {
        return "Indeferido";
      } else {
        return "Pendente";
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.header-description {
  background: $dark_banner;
  height: 120px;
  padding: 30px;

  h3 {
    font-size: 32px;
    color: $light;
    font-weight: 400;
  }
  p {
    margin: 0;
    font-family: $primary_font;
    color: $light;
    font-weight: 400;

    & span {
      font-weight: 200;
      color: $lighter;
    }
  }
}

.content {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 20px;
  // background: red;
}

.matricula-table {
  width: 1000px;
  // padding: 20px;
}

@media screen and (max-width: 765px) {
  .header-description {
    padding: 20px;
    h3 {
      font-size: 26px;
    }
    p {
      font-size: 14px;
    }
  }
  .content {
  }
}

@media screen and (max-width: 630px) {
  .header-description {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 10px 20px 10px 20px;
    height: 100px;
    // text-align: center;
    // height: 140px;
    h3 {
      font-size: 22px;
    }
    p {
      font-size: 14px;
    }
  }
  .content {
    display: flex;
    flex-direction: column-reverse;
  }
}
</style>