<template>
  <base-page-layout has-filter>
    <div class="titulo">
      <h1>Cursos online que impulsionam o seu potêncial.</h1>
      <p>
        Um ambiente de aprendizado virtual que oferece uma ampla gama de cursos
        e recursos educacionais para estudantes, professores e interessados.
      </p>
    </div>
    <div class="card-container" >
      <aside v-for="curso in cursos" :key="curso.id">
        <card redirect-to="Descrição do Curso" :id-curso="curso.id" :titulo="curso.nome" :docente="curso.responsavel"/>
      </aside>
    </div>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import Card from "@/components/Card.vue";
import axios from 'axios';
import { baseApiUrl } from '@/global';
export default {
  components: { BasePageLayout, Card },
  data: () => ({
    cursos: [],
  }),
  mounted() {
    this.getCursos();
  },
  methods: {
    async getCursos() {
      const response = await axios.get(`${baseApiUrl}/cursos`);
      this.cursos = response.data.data;
    },
  },
};
</script>

<style lang="scss" scoped>
.titulo {
  font-family: Arial, Helvetica, sans-serif;
  max-width: 750px;
  margin-bottom: 30px;
  margin-right: 30px;
  // word-break: normal;
}
.titulo h1 {
  letter-spacing: -0.04rem;
  font-size: 28px;
  font-weight: 700;
  font-family: $primary_font;
}
.titulo p {
  letter-spacing: -0.03rem;
  font-size: 18px;
  font-weight: 500;
  line-height: 25px;
  font-family: $primary_font;
}
.card-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(285px, auto));
  gap: 20px;
  justify-content: start;
  align-items: center;
  // background: rgb(228, 163, 163);
}

@media screen and (max-width: 830px) {
  .titulo {
    // background: red;
    // word-break: normal;
  }
  .titulo h1 {
    font-size: 24px;
    line-height: 25px;
  }
  .titulo p {
    font-size: 14px;
    line-height: 17px;
  }
}
@media screen and (max-width: 440px) {
}
</style>