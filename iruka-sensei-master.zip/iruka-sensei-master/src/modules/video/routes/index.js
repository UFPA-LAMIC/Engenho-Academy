export default [
  {
    path: "/login",
    name: "login",
    component: () => import("@/modules/login/views/Login.vue"),
  },
];
