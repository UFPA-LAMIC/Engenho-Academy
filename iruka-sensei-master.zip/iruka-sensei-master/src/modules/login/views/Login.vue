<template>
  <base-page-layout>
    <div class="login">
      <aside class="login-fields">
        <p class="title">Faça seu login e comece a aprender!</p>
        <v-text-field
          class="campo"
          v-model="user.email"
          outlined
          placeholder="E-mail"
          hide-details
        ></v-text-field>
        <v-text-field
          class="campo"
          v-model="user.password"
          outlined
          placeholder="Senha"
          type="password"
          hide-details
        ></v-text-field>
        <v-btn class="login-btn" color="#4966FE" dark @click="submit"
          >Entrar</v-btn
        >
        <!-- <v-btn class="cadastrar" text >Cadastrar-se</v-btn> -->
        <p class="cadastrar" @click="redirect">Cadastrar-se</p>
      </aside>
    </div>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import { mapActions } from "vuex";
import axios from "axios";
import { baseApiUrl } from "@/global";
export default {
  components: { BasePageLayout },
  name: "Login",
  data: () => ({
    user: {},
  }),
  methods: {
    ...mapActions(["login"]),
    redirect() {
      this.$router.push({ name: "cadastro" }).catch(() => {});
    },
    async submit() {
      try {
        const response = await axios.post(`${baseApiUrl}/login`, this.user);
        this.login(response.data.user);
        this.$setToken(response.data.token);
        this.$setLoggedUser(response.data.user);
        this.$bus.$emit("reload");
        // window.location.href("/");
        this.$router.push("/");
        setTimeout(() => {
          this.$router.go(0);
        }, 0);
      } catch (error) {
        console.log(error.response?.data?.message);
        this.$snackbar({
          message: error.response?.data?.message,
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.login {
  display: flex;
  justify-content: center;
  align-items: center;
  // background: red;
  min-height: inherit;
}

.title {
  font-family: $primary_font;
  margin: 0;
  font-size: 1rem;
  text-align: center;
  margin-bottom: 30px;
}

.login-fields {
  width: 380px;
}

.campo {
  width: 100%;
  margin-bottom: 15px;
}

.login-btn {
  text-transform: capitalize;
  font-family: $primary_font;
  width: 100%;
  height: 40px !important;
}

.cadastrar {
  text-align: end;
  margin-top: 20px;
  font-family: $primary_font;
  color: #4966fe;
}
.cadastrar:hover {
  cursor: pointer;
}
</style>