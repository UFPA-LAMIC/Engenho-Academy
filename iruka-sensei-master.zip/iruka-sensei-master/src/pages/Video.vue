<template>
  <div class="video-panel">
    <v-card color="#F3F3F3" class="ma-5">
      <v-row class="mx-3">
        <v-col sm="9" md="9">
          <video
            v-if="video.filename"
            height="450"
            max-width="800"
            controls="controls"
            autoplay="autoplay"
          >
            <source :src="`${url}/${video.filename}`" type="video/mp4" />
          </video>
        </v-col>
        <v-col sm="3" md="3">
          <v-card class="login pa-2">
            <v-list>
              <v-list-item-group mandatory color="indigo">
                <v-list-item v-for="item in videos" :key="item.titulo">
                  <v-list-item-icon>
                    <v-icon>mdi-play</v-icon>
                  </v-list-item-icon>

                  <v-list-item-content @click="chooseVideo(item.id)">
                    <v-list-item-title v-text="item.titulo"></v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list>
          </v-card>
        </v-col>
      </v-row>
    </v-card>
    <perguntas :resumo_video="this.video.resumo" :id_video="this.video.id" />
  </div>
</template>
<script>
import axios from "axios";
import { baseApiUrl } from "../global";
import Perguntas from "../features/Perguntas.vue";

export default {
  name: "Video",
  components: { Perguntas },
  data: function () {
    return {
      video: {},
      videos: [],
      url: "http://localhost:3006/video",
    };
  },
  methods: {
    loadVideo() {
      const url = `${baseApiUrl}/videos/${this.$route.params.id}`;
      axios.get(url).then((res) => {
        this.video = res.data;
      });
    },
    loadVideos() {
      const url = `${baseApiUrl}/videos/?id_curso=${this.$route.params.curso}`;
      axios
        .get(url)
        .then((res) => {
          this.videos = res.data.data;
        })
        .catch((error) => {
          alert(error.response.data.msg);
        });
    },
    chooseVideo(id) {
      this.$router.push(`/videos/${id}`).catch(() => {});
      // this.$forceUpdate();
      document.location.reload(true);
    },
  },
  mounted() {
    this.loadVideo();
    this.loadVideos();
    window.scrollTo(0, 0);
  },
};
</script>