export default {
    user: {},
    shouldReload: false,
}