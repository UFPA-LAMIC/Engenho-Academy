<template>
  <v-container class="justify-center items-center">
    <div class="py-3">
      <h1 class="text-center text-indigo-700">Simple Quiz</h1>
      <v-card class="mt-8">
        <div v-if="idx < count">
          <p class="">{{ questions[idx]["question"] }}</p>
          <v-col
            v-for="(answer, index) in questions[idx].answers"
            :key="index"
            :for="index"
            class="mt-4 py-2 px-6"
            :style="
              ({ 'hover:bg-gray-100 cursor-pointer': selectedAnswer == '' },
              {
                'bg-green-200':
                  index == questions[idx].correctAnswer && selectedAnswer != '',
              },
              { 'bg-red-200': selectedAnswer == index })
            "
          >
            <input
              :id="index"
              type="radio"
              class="hidden"
              :value="index"
              @change="answered($event)"
              :disabled="selectedAnswer != ''"
            />
            {{ answer }}
          </v-col>
          <div class="mt-6 flow-root">
            <v-btn
              @click="nextQuestion"
              v-show="selectedAnswer != '' && idx < count - 1"
              class="px-5 py-2"
            >
              Next &gt;
            </v-btn>
            <v-btn
              @click="showResults"
              v-show="selectedAnswer != '' && idx == count - 1"
              class="px-5 py-2"
            >
              Finish
            </v-btn>
          </div>
        </div>
        <div v-else>
          <h2 class="text-bold text-3xl">Results</h2>
          <div class="flex justify-start space-x-4 mt-6">
            <p>
              Correct Answers:
              <span class="text-2xl text-green-700 font-bold">{{
                correctAnswers
              }}</span>
            </p>
            <p>
              Wrong Answers:
              <span class="text-2xl text-red-700 font-bold">{{
                wrongAnswers
              }}</span>
            </p>
          </div>
          <div class="mt-6 flow-root">
            <v-btn @click="resetQuiz" class="px-5 py-2"> Play again </v-btn>
          </div>
        </div>
      </v-card>
    </div>
    <v-card>
      <v-card-title>Quiz da Matéria</v-card-title>
      <v-card-subtitle></v-card-subtitle>
    </v-card>
  </v-container>
</template>
<script>
export default {
  data() {
    return {
      idx: 0,
      selectedAnswer: "",
      correctAnswers: 0,
      wrongAnswers: 0,
      count: 3,
      questions: [
        {
          question:
            "Rolex is a company that specializes in what type of product?",
          answers: { a: "Bags", b: "Watches", c: "Shoes", d: "Laptops" },
          correctAnswer: "b",
        },
        {
          question: "When did Facebook launch?",
          answers: { a: "2005", b: "2008", c: "2003", d: "2004" },
          correctAnswer: "d",
        },
        {
          question:
            "Albert Einstein had trouble with mathematics when he was in school?",
          answers: { a: "True", b: "False" },
          correctAnswer: "b",
        },
      ],
    };
  },
  methods: {
    answered(e) {
      this.selectedAnswer = e.target.value;
      if (this.selectedAnswer == this.questions[this.idx].correctAnswer) {
        this.correctAnswers++;
      } else {
        this.wrongAnswers++;
      }
    },
    nextQuestion() {
      this.idx++;
      this.selectedAnswer = "";
      document.querySelectorAll("input").forEach((el) => (el.checked = false));
    },
    showResults() {
      this.idx++;
    },
    resetQuiz() {
      this.idx = 0;
      this.selectedAnswer = "";
      this.correctAnswers = 0;
      this.wrongAnswers = 0;
    },
  },
};
</script>