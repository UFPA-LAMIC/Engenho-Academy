<template>
  <v-snackbar :color="color" :timeout="timeout" v-model="show" bottom left>
    <!-- <strong>{{ message }}</strong>  -->
    {{ message }}
  </v-snackbar>
</template>

<script>
export default {
  props: {
    message: String,
    color: String,
    timeout: {
      type: Number,
      default: 6000,
    },
  },
  data() {
    return {
      show: false,
    };
  },
  watch: {
    message() {
      this.show = true;
    },
  },
};
</script>
