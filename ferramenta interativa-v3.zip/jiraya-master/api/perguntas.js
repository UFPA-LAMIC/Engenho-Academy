module.exports = (app) => {
  const limit = 25;

  const responsavel = async (bd) => {
    await app
          .db("perguntas")
          .join("users", `"${bd}"`, "=", "users.id")
          .select("users.email")
  } 
  
  const getLista = async (req, res) => {
    try {
      let {  quest  } = req.query;
      
      if (quest) quest = quest.trim(); //tira o espaço em branco, final e começo
      else quest = "";
          
      const page = req.query.page || 1;
      const result = await app
        .db("perguntas")
        .count("id as count")
        .where("pergunta", "like", `%${quest}%`)
        .first();
      const count = parseInt(result.count);
      const perguntas = await app
        .db("perguntas")
        .select()
        .where("pergunta", "like", `%${quest}%`)
        .limit(limit)
        .offset(page * limit - limit);

        const perguntasFormated = perguntas.map(form => {
          const [date, time] = form.dth_sistema.split(" ");
          const dataFormatada = date.split("-").reverse().join("/");
  
          const formatedDtsistema = dataFormatada + " " + time;
        
                return { ...form, dth_sistema: formatedDtsistema };
        });

        res.json({ data: perguntasFormated, count, limit });
    } catch (error) {
      res.status(500).send(error);
      console.log(error)
    }
  };

  const getById = async (req, res) => {

    app
    .db("perguntas")
      .select()
      .table("perguntas")
      .where({ id: req.params.id })
      .first()
      .then((perguntas) => {
        const [date, time] = perguntas.dth_sistema.split(' ');
        const dateFormated = date.split("-").reverse().join("/");
        
        const formatedDtsistema = dateFormated + " " + time;
        
        res.json({ ...perguntas, dth_sistema: formatedDtsistema});
      })
      .catch((err) => res.status(500).send(err));
    };

    const savePergunta = async (req, res) => {
      try {
        const pergunta = { pergunta: req.body.pergunta, resposta: req.body.resposta, id_user_resposta: req.body.id_user_resposta }
        console.log(req.body)
          const inserir = await app
            .db("perguntas")
            .insert(pergunta)
          console.log(inserir)
          res.json(inserir)
      } catch (error) {
        res.status(500).send(error);
      }
    };

    const updateForum = async (req, res) => {
      try {
        const state = { ...req.body };
        console.log(state)
        const status = await app
          .db("perguntas")
          .where({ id: state.id })
          .update({ 
            resposta: state.resposta,
            id_user_resposta: state.id_user_resposta,
            comentario1: state.comentario1,
            id_user_coment1: state.id_user_coment1,
            comentario2: state.comentario2,
            id_user_coment1: state.id_user_coment2,
            comentario3: state.comentario3,
            id_user_coment1: state.id_user_coment3,
            comentario4: state.comentario4,
            id_user_coment1: state.id_user_coment4,
            comentario5: state.comentario5,
            id_user_coment1: state.id_user_coment5,
            rank_resposta: state.rank_resposta,
            rank_coment1: state.rank_coment1,
            rank_coment2: state.rank_coment2,
            rank_coment3: state.rank_coment3,
            rank_coment4: state.rank_coment4,
            rank_coment5: state.rank_coment5
          });
          console.log(status)
        res.json(status);
      } catch (error) {
        res.status(500).send(error);
      }
    };
  
    const updateState = async (req, res) => {
      try {
        const auto = {
          id: req.body.id,
          state: req.body.state,
          state_description: req.body.state_description,
          id_administrativo: req.body.id_administrativo,
        };
  
        const status = await app
          .db("relatorio_disparo")
          .where({ id: auto.id })
          .update({ state: auto.state })
          .update({ state_description: auto.state_description })
          .update({ id_administrativo: auto.id_administrativo });
  
        res.json({
          data: status,
          // msg: `Documento: Auto de Entrega número ${auto.id} modificado com sucesso`,
        });
      } catch (error) {
        res.status(500).send(error);
      }
    };



return { getLista, getById, savePergunta, updateForum };

}