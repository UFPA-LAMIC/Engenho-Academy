const knex = require('../config/db')
const { numberToMontMapper } = require('./utils')

module.exports = (app) => {
  const getQuiz = async (req, res, next) => {
    try {
      let { id_video } = req.query

      const page = req.query.page
      const limit = req.query.limit
      const orderBy = 'asc'

      const model = app
        .db('quiz')
        .select()
        .where('id_video', '=', `${id_video}`)

      const trocasPromise = model
        .clone()
        .orderBy('id', orderBy)
        .limit(limit)
        .offset(page * limit - limit)
      const counterPromise = model.clone().count('id as count')

      const [trocas, counter] = await Promise.all([
        trocasPromise,
        counterPromise,
      ])

      console.log(trocas)

      const totalCount = counter[0]['count']

      res.json({
        data: trocas,
        count: totalCount,
        limit,
      })
    } catch (error) {
      next(error)
    }
  }

  const getContadorAbono = async (req, res, next) => {
    try {
      const year = req.query.year
      const params = [year]
      const query = `
        SELECT
          COUNT(id) AS total,
          DATE_FORMAT(dth_sistema, '%m') AS mes,
          DATE_FORMAT(dth_sistema, '%Y') AS ano  
        FROM quiz WHERE YEAR(dth_sistema) = ?
        GROUP BY MONTH(dth_sistema)
      `
      const result = (await knex.raw(query, params))[0]

      result.forEach((row) => {
        row['mes'] = numberToMontMapper(row['mes'])
      })

      res.json({
        data: result,
      })
    } catch (error) {
      next(error)
    }
  }

  const getById = async (req, res, next) => {
    app
      .db('quiz')
      .select()
      .table('quiz')
      .where({ id: req.params.id })
      .first()
      .then((q) => {
        const [date, time] = q.dth_sistema.split(' ')
        const dateFormated = date.split('-').reverse().join('/')

        const formatedDtsistema = dateFormated + ' ' + time

        res.json({
          ...q,
          dth_sistema: formatedDtsistema,
        })
      })
      .catch((err) => next(err))
  }

  const saveQuiz = async (req, res, next) => {
    try {
      const answer = { ...req.body }

      const status = await app
        .db('quiz')
        .insert(answer)
      res.json(status)
    } catch (error) {
      next(error)
    }
  }

  const answerQuiz = async (req, res, next) => {
    try {
      const answer = { ...req.body }

      const status = await app
        .db('quiz')
        .where({ id: req.params.id })
        .update(answer)
      res.json({
        data: status,
      })
    } catch (error) {
      next(error)
    }
  }

  return { getQuiz, getContadorAbono, getById, saveQuiz, answerQuiz }
}