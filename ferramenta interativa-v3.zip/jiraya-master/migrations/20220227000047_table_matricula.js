exports.up = function (knex, Promise) {
    return knex.schema.createTable("matricula", (table) => {
      table.increments("id").primary();
      table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
      table.integer("curso").unsigned();
      table.integer("aluno").unsigned();
      table.integer("status").defaultTo(0);
      table.foreign("curso").references("id").inTable("cursos");
      table.foreign("aluno").references("id").inTable("users");
    });
  };
  
  exports.down = function (knex, Promise) {
    return knex.schema.dropTable("matricula");
  };