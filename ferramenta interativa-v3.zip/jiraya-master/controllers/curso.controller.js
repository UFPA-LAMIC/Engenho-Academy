const Curso = require("../models/curso.model.js");

const CursoController = {
  async createCurso(req, res) {
    const curso = req.body;
    try {
      await Curso.createCurso(curso);
      res.status(200).json({ msg: "new curso created" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller createCurso - ${error.message}` });
    }
  },

  async findAllCursos(req, res, next) {
    try {
      const params = req.query;
      const data_inicio = params.data_inicio
        ? params.data_inicio
        : "0001-01-01";
      const data_fim = params.data_fim ? params.data_fim : "9999-01-01";

      params.nome = params.nome?.trim() || "";

      const limit = params.limit;

      const curso = await Curso.findAllCursos({
        ...params,
        data_inicio,
        data_fim,
      });

      res.status(200).json({
        ...curso,
        limitStats: limit,
      });
    } catch (error) {
      console.log(error);
      res
        .status(500)
        .json({ error: `Erro no controller findAllCursos - ${error.message}` });
    }
  },

  async findAllCursosMatriculados(req, res, next) {
    try {
      const params = req.query;
      const id = req.params.id;
      const data_inicio = params.data_inicio
        ? params.data_inicio
        : "0001-01-01";
      const data_fim = params.data_fim ? params.data_fim : "9999-01-01";

      params.aluno = id;

      const limit = params.limit;

      const curso = await Curso.findAllCursosMatriculados({
        ...params,
        data_inicio,
        data_fim,
      });

      res.status(200).json({
        ...curso,
        limitStats: limit,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        error: `Erro no controller findAllCursosMatriculados - ${error.message}`,
      });
    }
  },

  async findAllCursosOfDocente(req, res, next) {
    try {
      const params = req.query;
      const id = req.params.id;
      const data_inicio = params.data_inicio
        ? params.data_inicio
        : "0001-01-01";
      const data_fim = params.data_fim ? params.data_fim : "9999-01-01";

      params.docente = id;

      const limit = params.limit;

      const curso = await Curso.findAllCursosOfDocente({
        ...params,
        data_inicio,
        data_fim,
      });

      res.status(200).json({
        ...curso,
        limitStats: limit,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        error: `Erro no controller findAllCursosOfDocente - ${error.message}`,
      });
    }
  },

  async findCursoByDocente(req, res) {
    try {
      const idCurso = req.params.idCurso;
      const idDocente = req.params.idDocente;
      const curso = await Curso.findCursoByDocente(idCurso, idDocente);
      res.status(200).json(curso);
    } catch (error) {
      res
        .status(500)
        .json({
          error: `Erro no controller findCursoByDocente - ${error.message}`,
        });
    }
  },

  async getCursoById(req, res) {
    try {
      const id = req.params.id;
      const curso = await Curso.findCursoById(id);
      res.status(200).json(curso);
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getCursoById - ${error.message}` });
    }
  },
  async editCurso(req, res) {
    const curso = req.body;
    const id = req.params.id;
    try {
      await Curso.editCurso(curso, id);
      res.status(200).json({ msg: "curso edited!" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getCursoById - ${error.message}` });
    }
  },
};

module.exports = CursoController;
