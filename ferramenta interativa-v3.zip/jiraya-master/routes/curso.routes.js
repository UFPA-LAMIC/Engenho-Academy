const express = require("express");
const router = express.Router();
const CursoController = require("../controllers/curso.controller.js");

// Require the authenticate middleware
const { authenticate } = require("../middlewares/auth");

const roles = [99, 1, 7];
const master = [99, 7];

//Routes for curso crud operations
router.post("/", authenticate(master), CursoController.createCurso);
router.get("/", CursoController.findAllCursos);
router.get("/:id", CursoController.getCursoById);
router.put("/:id", authenticate(master), CursoController.editCurso);
router.get(
  "/matriculados/:id",
  authenticate(roles),
  CursoController.findAllCursosMatriculados
);
router.get(
  "/docente/:id",
  authenticate(roles),
  CursoController.findAllCursosOfDocente
);
router.get(
  "/:idCurso/docente/:idDocente",
  authenticate(roles),
  CursoController.findCursoByDocente
);

module.exports = router;
