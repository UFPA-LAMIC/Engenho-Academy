const jwt = require('jsonwebtoken')
const { jwtSecret } = require('../env')

const verifyToken = async (req, res) => {
  const { token } = req.body

  // Check if the token exists
  if (!token) {
    return res.status(401).json({ message: 'Missing token!' })
  }

  try {
    // Verify the token
    const decoded = jwt.verify(token, jwtSecret)
    const timeElapsed = Date.now()
    const today = new Date(timeElapsed)

    // Add the users payload
    const userSteps = {
      user: decoded,
      baseUrl: req.baseUrl,
      route: req.route,
      host: req.hostname,
      date: today
    }

    res.json(userSteps)
  } catch (error) {
    // Return an error
    res
      // .status(401)
      .json({ message: 'Expired token! please login again', expired: true })
  }
}

module.exports = { verifyToken }
