const Video = require("../models/video.model.js");
const bcrypt = require("bcrypt");

const VideoController = {
  async createVideo(req, res) {
    try {
      const video = req.body;

      await Video.createVideo(video);
      res.status(200).json({ msg: "new video created" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller createVideo - ${error.message}` });
    }
  },
  async getAllVideos(req, res) {
    try {
      let params = req.query;
      const limit = params.limit;

      params.titulo = params.titulo?.trim() || "";

      const videos = await Video.findAllVideos(params);

      res.status(200).json({
        ...videos,
        limitStats: limit,
      });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getAllVideos - ${error.message}` });
    }
  },
  async getAllVideosFromThatCourse(req, res) {
    try {
      let params = req.query;
      const id = req.params.id_curso;
      const limit = params.limit;

      params.titulo = params.titulo?.trim() || "";

      const videos = await Video.findAllVideosFromThatCourse(params, id);

      res.status(200).json({
        ...videos,
        limitStats: limit,
      });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getAllVideos - ${error.message}` });
    }
  },

  async getVideoById(req, res) {
    const id = req.params.id;
    try {
      const video = await Video.findVideoById(id);
      res.status(200).json(video);
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getVideoById - ${error.message}` });
    }
  },

  async editVideo(req, res) {
    const video = req.body;
    const id = req.params.id;
    try {
      await Video.editVideo(video, id);
      res.status(200).json({ msg: "video edited!" });
    } catch (error) {
      res
        .status(500)
        .json({ error: `Erro no controller getVideoById - ${error.message}` });
    }
  },
};

module.exports = VideoController;
