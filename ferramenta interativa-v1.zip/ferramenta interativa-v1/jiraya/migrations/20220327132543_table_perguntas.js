exports.up = function (knex) {
    return knex.schema.createTable("perguntas", (table) => {
      table.increments("id").primary();
      table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
      table.text("pergunta");
      table.integer("autor").unsigned();
      table.foreign("autor").references("id").inTable("users");
      table.integer("video").unsigned();
      table.foreign("video").references("id").inTable("videos");
    });
  };
  
  exports.down = function (knex) {
    return knex.schema.dropTable("perguntas");
  };
  