exports.up = function (knex, Promise) {
    return knex.schema.createTable("ufpa_graduacao", (table) => {
      table.increments("id").primary();
      table.string("nome", 100);
      table.string("codigo", 6);
    });
  };
  
  exports.down = function (knex, Promise) {
    return knex.schema.dropTable("ufpa_graduacao");
  };
  