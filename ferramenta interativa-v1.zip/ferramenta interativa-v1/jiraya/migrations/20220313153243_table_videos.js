exports.up = function (knex, Promise) {
    return knex.schema.createTable("videos", (table) => {
      table.increments("id").primary();
      table.datetime("dth_sistema").defaultTo(knex.fn.now(0));
      table.string("titulo");
      table.string("url");
      table.integer("ordem");
      table.integer("curso").unsigned();
      table.foreign("curso").references("id").inTable("cursos");
    });
  };
  
  exports.down = function (knex, Promise) {
    return knex.schema.dropTable("videos");
  };