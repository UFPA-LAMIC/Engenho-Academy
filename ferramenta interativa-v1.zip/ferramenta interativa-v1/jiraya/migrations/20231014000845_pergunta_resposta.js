/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.createTable("pergunta_resposta", (table) => {
        table.increments("id").primary();
        table.integer("id_pergunta").unsigned();
        table.integer("id_resposta").unsigned();
        table.foreign("id_pergunta").references("id").inTable("perguntas");
        table.foreign("id_resposta").references("id").inTable("respostas");
      });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.dropTable("pergunta_resposta");
};
