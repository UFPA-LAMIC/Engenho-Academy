module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'o_projeto_vai_sair',
  validLimitsForPagination: [10, 30, 50],
  defaultLimitPagination: 10,
}
