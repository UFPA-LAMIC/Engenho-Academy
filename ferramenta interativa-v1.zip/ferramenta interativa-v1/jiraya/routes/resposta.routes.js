const express = require('express')
const router = express.Router()
const RespostaController = require('../controllers/resposta.controller.js')

// Require the authenticate middleware
const { authenticate } = require('../middlewares/auth');

const roles = ['DOCENTE', 'DISCENTE']
const docente = ['DOCENTE']

//Routes for resposta crud operations
router.post('/:idPergunta', authenticate(roles), RespostaController.createResposta)
// router.get('/', authenticate(roles), RespostaController.findAllRespostas)
// router.get('/:id', authenticate(roles), RespostaController.getRespostaById)

module.exports = router