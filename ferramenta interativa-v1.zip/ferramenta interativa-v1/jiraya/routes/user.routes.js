const express = require('express')
const router = express.Router()
const UserController = require('../controllers/user.controller.js')

// Require the authenticate middleware
const { authenticate } = require('../middlewares/auth');

// here I can put the roles that my users will acces
const roles = ['DOCENTE', 'DISCENTE']

//Routes for user crud operations
router.post('/', UserController.createUser)
router.get('/', authenticate(roles), UserController.getAllUsers)
router.get('/:id', authenticate(roles), UserController.getUserById)
router.put('/:id', authenticate(roles), UserController.editUser)

module.exports = router