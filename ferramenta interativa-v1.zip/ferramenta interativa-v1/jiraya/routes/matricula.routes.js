const express = require("express");
const router = express.Router();
const MatriculaController = require("../controllers/matricula.controller.js");

// Require the authenticate middleware
const { authenticate } = require("../middlewares/auth");

const roles = ["DOCENTE", "DISCENTE"];
const docente = ["DOCENTE"];

//Routes for matricula crud operations
router.post("/", authenticate(roles), MatriculaController.createMatricula);
router.get("/", authenticate(docente), MatriculaController.findAllMatriculas);
router.get("/curso/:idCurso/aluno/:idAluno", authenticate(roles), MatriculaController.findMatriculaByAlunoForThatCourse);
router.get("/curso/:idCurso", authenticate(docente), MatriculaController.findAllMatriculasByCurso);
router.get("/aluno/:idAluno", authenticate(docente), MatriculaController.findAllMatriculasByAluno);
router.get("/:id", authenticate(docente), MatriculaController.getMatriculaById);
router.put("/:id", authenticate(roles), MatriculaController.editMatricula);

module.exports = router;
