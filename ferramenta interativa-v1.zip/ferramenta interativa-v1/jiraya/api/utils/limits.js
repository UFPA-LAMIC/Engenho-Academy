const {
  validLimitsForPagination,
  defaultLimitPagination,
} = require('../../env.js')

exports.verifyLimitForPagination = (limit) => {
  if (validLimitsForPagination.includes(+limit)) return +limit
  return defaultLimitPagination
}
