exports.yearValidator = (year) => {
  if (!Number(year)) return new Date().getFullYear()
  return Number(year)
}
