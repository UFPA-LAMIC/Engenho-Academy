const bcrypt = require("bcrypt-nodejs");
module.exports = (app) => {
  const limit = 20
    const { existsOrError, notExistsOrError, equalsOrError } = app.api.validation;
    const encryptPassword = (password) => {
    const salt = bcrypt.genSaltSync(10);
    return bcrypt.hashSync(password, salt);
  };

  const createUser = async (req, res) => {
    const dados = { ...req.body };

    try {
        existsOrError(dados.password, "Senha não preenchida!");

        equalsOrError(dados.password, dados.confirmPassword, "Senhas diferentes!")
  
        const userFromDB = await app
          .db("users")
          .where({ email: dados.email })
          .first();
        if (!dados.id) {
          notExistsOrError(userFromDB, "Usuário já cadastrado!");
        }
      } catch (msg) {
        return res.status(400).send(msg);
      }
      
      password = encryptPassword(dados.password)
      delete dados.confirmPassword

      const inserir = await app.db("users").insert({...dados, password: password});
      console.log(dados)
      res.json({dados: inserir});
  };

  const getUser = async (req, res) => {
    try {
      let {  id_curso  } = req.query;
          
      if (id_curso) id_curso = id_curso.trim();
      else id_curso = "";

      const page = req.query.page || 1;
      const result = await app
        .db("users")
        .count("id as count")
        // .where('users.tipo', '=', 'DISCENTE')
        .first();
      const count = parseInt(result.count);

      const list = await app.db("users")
      // .where('users.tipo', '=', 'DISCENTE')
      .select()
      .limit(limit)
      .offset(page * limit - limit);

      res.json({data: list, count, limit});
    } catch (error) {
      res.status(400).send(error);
    }
  };

  const getUserById = async (req, res) => {
    try {

      const status = await app
        .db("users")
        .where({ id: req.params.id })
        .first()
          
      res.json({ data: status });

    } catch (error) {
      res.status(400).send('The user was not found');
    }
  };

  const removeUser = async (req, res) => {
    try {
      const deletado = await app.db("users").where({ id: req.params.id }).del();

      res.json({ data: deletado });
    } catch (error) {
      res.status(500).send(error);
    }
  };

  const removeUserByEmail = async (req, res) => {
    let {  email  } = req.query;
    try {
      const deletado = await app.db("users").where('email', '=', email ).del();

      res.json({ data: deletado });
    } catch (error) {
      res.status(500).send(error);
    }
  };

  const metricaUsersx = async (req, res) => {
    try {
      let {  id_curso  } = req.query;
          
      if (id_curso) id_curso = id_curso.trim();
      else id_curso = "";

      const page = req.query.page || 1;
      const result = await app
        .db("users")
        .count("id as count")
        .where('users.tipo', '=', 'DISCENTE')
        .first();
      const count = parseInt(result.count);

      const list = await app.db("users")
      .where('users.tipo', '=', 'DISCENTE')
      .select()
      .limit(limit)
      .offset(page * limit - limit);

      const listFormated = list.map(user => {
        const [date, time] = user.dth_sistema.split(" ");
        const dataFormatada = date.split("-").reverse().join("/");

        const formatedDtsistema = dataFormatada + " " + time;
        const dataNascimento = user.dt_nascimento.split("-").reverse().join("/")
      
              return { ...user, dth_sistema: formatedDtsistema, dt_nascimento: dataNascimento };
      });

      res.json({data: listFormated, count, limit});
    } catch (error) {
      res.status(400).send(error);
    }
  };

  const metricaUsers = async (req, res) => {
    const result = await app.db.raw(`
      select TIMESTAMPDIFF(YEAR, dt_nascimento, CURDATE()) AS age, COUNT(*) as total
      from users
      group by age
    `)
    res.json(result[0])
  }

  // const getUserById = async (req, res) => {
  //   const id =  req.body.id 
  //   try {

  //     const status = await app
  //       .db("users")
  //       .where({ id: id })
  //       .first()
          
  //       res.json({ data: status });

  //   } catch (error) {
  //     res.status(400).send(error);
  //   }
  // };

  return { createUser, getUser, getUserById, removeUser, metricaUsers, removeUserByEmail};
};
