module.exports = (app) => {

    const insertVideos = async (req, res) => {
    
        const dados = { ...req.body, ...req.file };
        await app.db("videos").insert( dados );
        res.json(dados);
      };

      const getVideos = async (req, res) => {
        try{
          let {  id_curso  } = req.query;
          
          if (id_curso) id_curso = id_curso.trim();
          else id_curso = "";
          
          const videos = await app.db("videos")
          .where("curso", "=", `${id_curso}`)
          .select()
          
          const videosFormated = videos.map((video) => {
            const [date, time] = video.dth_sistema.split(" ");
            const dateFormated = date.split("-").reverse().join("/");

            const formatedDtsistema = dateFormated;
    
            return { ...video, dth_sistema: formatedDtsistema };
          });
    
          res.json({ data: videosFormated});
        } catch (error) {
          res.status(500).send(error);
        }
    };

      const getVideoId = async (req, res) => {
        app
          .db("videos")
          .select()
          .where({id: req.params.id})
          .first()
          .then((video) => {
            console.log(video);
            res.json(video);
          })
          .catch((err) => res.status(500).send(err));
    
        //  res.json({ ...auto, responsavel: responsavel, dth_sistema: formatedDtsistema,
        //    dt_ocorrencia: formatedDtocorrencia, });
      };

      const removeVideo = async (req, res) => {
        let { id } = req.query
        try {
          const deletado = await app.db("videos").where("id", "=", `${id}`).del();
    
          res.json({ data: deletado });
        } catch (error) {
          console.log(error)
          res.status(500).send(error);
        }
      };

      return { insertVideos, getVideos, getVideoId, removeVideo }

}