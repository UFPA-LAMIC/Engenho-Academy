const jwt = require('jsonwebtoken');
const { jwtSecret } = require("../env");

const authenticate = (roles) => (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];

  // Check if the token exists
  if (!token) {
    return res.status(401).json({ message: 'Unauthorized, please login!' });
  }

  try {
    // Verify the token
    const payload = jwt.verify(token, jwtSecret)

    const foundRole = roles.find(role => role === payload.tipo)

    if(!foundRole) {
      return res.status(403).json({msg: "Usuário não possui acesso à pagina!"})
    }

    req.userId = payload.id

    // Call the next middleware
    next();
  } catch (error) {
    // Return an error
    res.status(401).json({ message: 'Expired token! please login again', expired: true });
  }
};

module.exports = { authenticate };
