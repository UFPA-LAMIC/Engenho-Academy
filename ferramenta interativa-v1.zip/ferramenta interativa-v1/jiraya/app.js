const express = require('express')
const dotenv = require('dotenv')
dotenv.config()
const app = express()
const port = 3006
const bodyParser = require('body-parser')
const cors = require('cors')

const db = require('./config/db')
const config = require('./config')

//rotas
const loginRoutes = require('./routes/login.routes')
const verifyTokenRoutes = require('./routes/verifyToken.routes')
const userRoutes = require('./routes/user.routes')
const videoRoutes = require('./routes/video.routes')
const graduacaoRoutes = require('./routes/graduacao.routes')
const cursoRoutes = require('./routes/curso.routes')
const matriculaRoutes = require('./routes/matricula.routes')
const perguntaRoutes = require('./routes/pergunta.routes')
const respostaRoutes = require('./routes/resposta.routes')

const testDatabaseConnection = async () => {
  try {
    await db.raw('SELECT 1')
    console.log('Conexão com o banco de dados estabelecida com sucesso!')
  } catch (error) {
    console.error('Erro ao conectar ao banco de dados:', error)
    db.destroy() // fecha a conexão com o banco de dados
    process.exit(1)
  }
}

//Middleware
app.use(bodyParser.json())
app.use(cors())

// static files server from the "public" directory
app.use("/video", express.static(__dirname + "/video_aulas"));


//Routes
app.use('/login', loginRoutes)
app.use('/verify-token', verifyTokenRoutes)
app.use('/users', userRoutes)
app.use('/videos', videoRoutes)
app.use('/graduacao', graduacaoRoutes)
app.use('/cursos', cursoRoutes)
app.use('/matriculas', matriculaRoutes)
app.use('/perguntas', perguntaRoutes)
app.use('/respostas', respostaRoutes)

app.listen(port, async () => {
  await testDatabaseConnection()
  console.log(`Aplicação rodando, porta ------ ${port}`)
  console.log(`Ambiente ------ ${config.env}`)
})