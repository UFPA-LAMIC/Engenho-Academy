const path = require('path')
const multer = require('multer')
const crypto = require('crypto')

module.exports = {
    storage:multer.diskStorage({
        destination:'./video_aulas',
        filename:(req, file, cb) => {
            crypto.randomBytes(16, (err, hash) => {
                if(err) cb(err);

                const fileName = `${hash.toString("hex")}-${file.originalname}`

                cb(null, fileName)
            })
        }
    })
    
}
