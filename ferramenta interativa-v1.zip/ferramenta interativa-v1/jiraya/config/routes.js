const multer = require("multer");
const multerConfig = require("./multer");
const jwt = require("jwt-simple");

const verifyUser = (tipo) => (req, res, next) => {
  const authToken = req.headers["authorization"].split(" ")[1];

  // console.log('token', authToken);

  try {
    if (authToken) {
      const payload = jwt.decode(authToken, 'hduahduwhduahhahd');

      if (payload.tipo !== tipo && payload.tipo !== "DOCENTE") {
        return res
          .status(403)
          .json({ msg: "Usuário não possui acesso! "});
      }

      console.log(payload); 
      res.locals.payload = payload;

      next();
    } else {
      res.send({ message: "No token provided" });
    }
  } catch (e) {
    console.log(e);

    next(e);
  }

  // res.send(false);
};


module.exports = (app) => {
  app.post("/signup", app.api.users.createUser);
  app.post("/signin", app.api.auth.signin);
  app.post("/validateToken", app.api.auth.validateToken);

  /*-------------------------------- */

  app.route("/users")
  // .all(app.config.passport.authenticate())
  .get(app.api.users.getUser)
  .post(app.api.users.createUser);
  // .post(verifyUser('DOCENTE'), app.api.users.createUser);
  
  app.route("/user")
  // .all(app.config.passport.authenticate())
  .delete(app.api.users.removeUserByEmail);

  app.route("/users/:id")
  // .all(app.config.passport.authenticate())
  .get(app.api.users.getUserById)
  .delete(app.api.users.removeUser);

  app.route("/perguntas")
  // .all(app.config.passport.authenticate())
  .get(app.api.perguntas.getLista)
  .post(app.api.perguntas.savePergunta)
  .put(app.api.perguntas.updateForum);
  
  app.route("/question/")
  // .all(app.config.passport.authenticate())
  .post(app.api.question.saveQuestion)
  .put(app.api.question.updateQuestion);
  
  app.route("/question/:aula")
  // .all(app.config.passport.authenticate())
  .get(app.api.question.getQuestion)
  .post(app.api.question.saveQuestion)
  .put(app.api.question.updateQuestion);

  app.route("/answer")
  // .all(app.config.passport.authenticate())
  .get(app.api.answer.getAnswer)
  .post(app.api.answer.saveAnswer);

  app.route("/answer/:id")
  // .all(app.config.passport.authenticate())
  .put(app.api.answer.updateAnswer)
  .delete(app.api.answer.removeAnswer);

  // --------- CURSO --------

  app.route("/curso")
  // .all(app.config.passport.authenticate())
  .get(app.api.cursos.getCurso)
  .post(app.api.cursos.saveCurso)
  
  app.route("/curso/:id")
  // .all(app.config.passport.authenticate())
  .get(app.api.cursos.getCursoById)
  .delete(app.api.cursos.removeCurso)
  .put(app.api.cursos.updateCurso);
  
  app.route("/cursos")
  // .all(app.config.passport.authenticate())
  .get(app.api.cursos.getAllCursos);
  
  app.route("/cursos-aluno")
  // .all(app.config.passport.authenticate())
  .get(app.api.cursos.getMatriculasCurso);
  
  app.route("/cursos-docente/:docente")
  // .all(app.config.passport.authenticate())
  .get(app.api.cursos.getCursosEspec);

  // --------- MATRÍCULAS --------
  
  app.route("/matriculas")
  // .all(app.config.passport.authenticate())
  .get(app.api.matricula.getAllMatriculas)
  .post(app.api.matricula.saveMatricula);
  
  app.route("/matriculas-por-aluno")
  // .all(app.config.passport.authenticate())
  .get(app.api.matricula.getByAlunoAndCourseId)
  
  app.route("/cursos-matriculados")
  // .all(app.config.passport.authenticate())
  .get(app.api.matricula.getCursosMatriculados);
  
  app.route("/matriculas/:curso")
  // .all(app.config.passport.authenticate())
  .get(app.api.matricula.getMatriculasCurso);
  
  app.route("/matriculas/:curso/:aluno")
  // .all(app.config.passport.authenticate())
  .put(app.api.matricula.updateMatricula);
  
  app.route("/matriculas-deferidas/:curso")
  // .all(app.config.passport.authenticate())
  .get(app.api.matricula.getMatriculasDeferidas);
  
  app.route("/matriculas-analise/:curso")
  // .all(app.config.passport.authenticate())
  .get(app.api.matricula.getMatriculasAnalise);
  
  // --------- VÍDEOS --------
  app
  .route("/videos")
  // .all(app.config.passport.authenticate())
  .get(app.api.videos.getVideos)
  .post(multer(multerConfig).single("file"), app.api.videos.insertVideos)
  .delete(app.api.videos.removeVideo)
  
  app.route("/videos/:id").get(app.api.videos.getVideoId);
  
  // --------- MÉTRICAS --------
  app.route("/metrica-users")
  // .all(app.config.passport.authenticate())
  .get(app.api.users.metricaUsers)

  
  // --------- QUIZ --------
  app
  .route("/quiz")
  // .all(app.config.passport.authenticate())
  .get(app.api.quiz.getQuiz)
  .post(app.api.quiz.saveQuiz);
  
  app
  .route("/quiz/:id")
  // .all(app.config.passport.authenticate())
  .get(app.api.quiz.getById)
  .put(app.api.quiz.answerQuiz);
  
  // --------- QUIZ ANSWER --------
  app
  .route("/quiz_answer")
  // .all(app.config.passport.authenticate())
  .get(app.api.quiz_answer.getQuiz)
  .post(app.api.quiz_answer.saveQuiz);
  
  app
  .route("/quiz_answer/:id")
  // .all(app.config.passport.authenticate())
  .get(app.api.quiz_answer.getById)
  .put(app.api.quiz_answer.answerQuiz);

  
  // --------- RATES --------
  app
  .route("/avaliacao_curso")
  // .all(app.config.passport.authenticate())
  .get(app.api.avaliacao_curso.getCourseRates)
  .post(app.api.avaliacao_curso.ratingCourse)
  .put(app.api.avaliacao_curso.UpdateRatingCourse);
  
  app
  .route("/avaliacao_metrics")
  // .all(app.config.passport.authenticate())
  .get(app.api.avaliacao_curso.getMetrics)
  
  app
  .route("/avaliacao_curso_aluno/")
  // .all(app.config.passport.authenticate())
  .get(app.api.avaliacao_curso.getByAluno)
  
  app
  .route("/avaliacao_curso/:id")
  // .all(app.config.passport.authenticate())
  .get(app.api.avaliacao_curso.getById)
  
  // app.route("/upload").post(multer(multerConfig).single("file"), (req, res) => {
  //   const dados = { ...req.file };
  //   res.json({ dados: dados });
  // });
};
