/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
const bcrypt = require("bcrypt");

exports.seed = async function (knex) {
  // Deletes ALL existing entries
  // await knex("cursos").del();

  await knex.raw('ALTER TABLE cursos AUTO_INCREMENT = 1') // reseta o incremento da coluna id

  await knex("cursos").insert([
    {
      nome: "Direito Administrativo",
      data_inicio: "2023-10-08",
      data_fim: "2023-10-12",
      descricao:
        "Conheça o conteúdo do curso Direito Administrativo voltado a Gestão Pública - Princípios do Direito Administrativo: legalidade, supremacia do interesse público e publicidade - Princípios do Direito Administrativo: continuidade do serviços público, moralidade administrativa, eficiência e segurança jurídica - Administração Indireta - Conceito e elementos do serviço público - Classificação e formas de gestão do serviço público - Cargo, emprego e função pública - Regime jurídico dos servidores públicos - Conceitos e classificação dos atos administrativos - Atributos dos atos administrativos - Extinção dos atos administrativos - Poderes da Administração Pública - Fundamentos da intervenção na propriedade privada - Modalidades de intervenção na propriedade - Desapropriação - Intervenção do Estado no domínio econômico - Características e prerrogativas de Direito Público Administrativo",
      docente: 7,
      },
    {
      nome: "Java - Entendendo o conceito básico da linguagem",
      data_inicio: "2023-04-02",
      data_fim: "2023-08-12",
      descricao:
        "Este é o único curso em que você vai contar não só com vídeo aulas, mas também com material de apoio específico para TODOS capítulos, inúmeros exercícios resolvidos e também exercícios propostos com correção, cobertura de aspectos de design com diagramas UML, e a melhor didática baseada na associação aula / conteúdo do material de apoio / versões do Github. O curso é constantemente atualizado com novos conteúdos, e nós garantimos que ele estará sempre atualizado para a última versão LTS (Long Term Support) do Java, que atualmente é a versão 11 (lembre-se que, embora as versões 12 e 13 já estejam disponíveis, estas são versões de curta duração, que serão retiradas de circulação em poucos meses, assim como foi com as versões 9 e 10).",
      docente: 7,
      },
    {
      nome: "Aprenda Arduino usando o simulador Tinkercad",
      data_inicio: "2023-05-22",
      data_fim: "2023-07-06",
      descricao:
        "O Arduino é uma plataforma muito popular atualmente. Criada inicialmente para facilitar a programação de microcontroladores, hoje é usada em diversas áreas tanto para prototipagem quanto para pesquisas. Apesar de ter uma grande quantidade de bibliotecas, que facilitam em muito o desenvolvimento de projetos, os primeiros passos podem ser um poucos frustrantes se você não tiver habituado na programação em linguagem C/C++ ou programação de microcontroladores. Esse curso foi criado para ajudar os iniciantes na plataforma Arduino a quebrarem as barreiras iniciais na plataforma. O uso de uma plataforma de simulação gratuita lhe ajudará a entender os fundamentos essenciais da plataforma Arduino. Assim, quando você for usar a placa física e criar seus próprios projetos, já terá uma base sólida de conhecimento.",
      docente: 7,
      },
  ]);
};
