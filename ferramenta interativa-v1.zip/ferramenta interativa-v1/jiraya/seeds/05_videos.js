/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */

exports.seed = async function (knex) {
  // Deletes ALL existing entries
  // await knex("videos").del();

  await knex.raw("ALTER TABLE videos AUTO_INCREMENT = 1"); // reseta o incremento da coluna id

  await knex("videos").insert([
    {
      titulo: "Aula 1 Curso de Java 2023",
      url: "https://www.youtube.com/embed/R4Xte53PKwA?si=zmptAkXJeFwmIf4I",
      ordem: 1,
      curso: 3,
    },
    {
      titulo: "Aula 2 Java 2023 (Variável int, operações matemáticas e concatenação)",
      url: "https://www.youtube.com/embed/8EuBDQbc5WU?si=UeKHpuyFHxL7pkAB",
      ordem: 2,
      curso: 3,
    },
    {
      titulo: "Aula 3 JAVA 2023 ( tipo flutuante , double)",
      url: "https://www.youtube.com/embed/K6Ynbw4cBnA?si=LAqQ6KQIYXW-_Egw",
      ordem: 3,
      curso: 3,
    },
    {
      titulo: "Aula 4 JAVA 2023 (Cast e tipos de variáveis numéricas)",
      url: "https://www.youtube.com/embed/r5wNDhaPdfI?si=fnSAjmxj04YwRSO-",
      ordem: 4,
      curso: 3,
    },
  ]);
};
