const db = require("../config/db");
const { formatDate, formatDatetime } = require('../utils')

const PerguntaResposta = {
  async createPerguntaResposta(perguntaResposta) {
    try {
      await db("pergunta_resposta").insert(perguntaResposta);
    } catch (error) {
      throw new Error(`Erro no endpoint createPerguntaResposta - ${error.message}`);
    }
  },
  
  async editPerguntaResposta (perguntaResposta, id) {
    console.log(id)
    try {
      await db('pergunta_resposta').update(perguntaResposta).where('id_pergunta', id)
    } catch (error) {
      throw new Error(`Erro no endpoint editPerguntaResposta - ${error.message}`)
    }
  },
};

module.exports = PerguntaResposta;