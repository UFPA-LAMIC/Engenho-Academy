const db = require("../config/db");
const { formatDate, formatDatetime } = require("../utils");

const Matricula = {
  async createMatricula(matricula) {
    try {
      await db("matricula").insert(matricula);
    } catch (error) {
      throw new Error(`Erro no endpoint createMatricula - ${error.message}`);
    }
  },

  //query para buscar todos os matriculas
  async findAllMatriculas(param) {
    try {
      const [count, getMatricula] = [
        await db("matricula")
          .join("users", "matricula.aluno", "=", "users.id")
          .join("cursos", "matricula.curso", "=", "cursos.id")
          .count("matricula.id as count")
          .first(),

        await db("matricula")
          .select(
            "matricula.*",
            "users.nome as responsavel",
            "cursos.nome as nome_curso"
          )
          .join("users", "matricula.aluno", "=", "users.id")
          .join("cursos", "matricula.curso", "=", "cursos.id")
          .orderBy("matricula.id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const matricula = {
        data: getMatricula,
        ...count,
      };
      return matricula;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllMatricula - ${error.message}`);
    }
  },

  //query para buscar todos a matricula que o aluno se matriculou
  async findMatriculaByAlunoForThatCourse(param) {
    try {
      const matricula = await db("matricula")
        .select()
        .where("curso", "=", param.curso)
        .where("aluno", "=", param.aluno)
        .first();

      return matricula;
    } catch (error) {
      throw new Error(
        `Erro no endpoint findMatriculaByAlunoForThatCourse - ${error.message}`
      );
    }
  },

  //query para buscar todas as matrículas de um curso específico
  async findAllMatriculasByCurso(param) {
    try {
      const [count, getMatricula] = [
        await db("matricula")
          .count("matricula.id as count")
          .join("users", "matricula.aluno", "=", "users.id")
          .where("curso", "=", param.curso)
          .first(),

        await db("matricula")
          .select("matricula.*", "users.nome as nome_aluno")
          .where("curso", "=", param.curso)
          .join("users", "matricula.aluno", "=", "users.id")
          .orderBy("matricula.dth_sistema", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const matricula = {
        data: getMatricula,
        ...count,
      };
      return matricula;
    } catch (error) {
      throw new Error(
        `Erro no endpoint findAllMatriculasByCurso - ${error.message}`
      );
    }
  },

  //query para buscar todas as matrículas de um aluno específico
  async findAllMatriculasByAluno(param) {
    try {
      const [count, getMatricula] = [
        await db("matricula")
          .count("id as count")
          .where("aluno", "=", param.aluno)
          .first(),

        await db("matricula")
          .select()
          .where("aluno", "=", param.aluno)
          .orderBy("id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const matricula = {
        data: getMatricula,
        ...count,
      };
      return matricula;
    } catch (error) {
      throw new Error(
        `Erro no endpoint findAllMatriculasByAluno - ${error.message}`
      );
    }
  },

  async findMatriculaById(id) {
    try {
      const matricula = await db("matricula").where("id", id).select().first();

      return matricula;
    } catch (error) {
      throw new Error(`Erro no endpoint findMatriculaById - ${error.message}`);
    }
  },

  async editMatricula(matricula, id) {
    try {
      await db("matricula").update(matricula).where("id", id);
    } catch (error) {
      throw new Error(`Erro no endpoint findMatriculaById - ${error.message}`);
    }
  },
};

module.exports = Matricula;
