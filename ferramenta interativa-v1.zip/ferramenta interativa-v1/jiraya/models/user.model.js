const db = require("../config/db");

const User = {
  async createUser(user) {
    try {
      await db("users").insert(user);
    } catch (error) {
      throw new Error(`Erro no endpoint createUser - ${error.message}`);
    }
  },
  async findAllUsers(param) {
    try {
      const [count, getUsers] = [
        await db("users")
          .count("id as count")
          .where("nome", "like", `%${param.nome}%`)
          .where("email", "like", `%${param.email}%`)
          .first(),

        await db("users")
          .select()
          .where("nome", "like", `%${param.nome}%`)
          .where("email", "like", `%${param.email}%`)
          .orderBy("id", param.orderBy)
          .limit(param.limit)
          .offset(param.page * param.limit - param.limit),
      ];

      const users = {
        data: getUsers,
        ...count,
      };
      return users;
    } catch (error) {
      throw new Error(`Erro no endpoint findAllUser - ${error.message}`);
    }
  },
  async findUserById(id) {
    try {
      const user = await db("users").where("id", id).select().first();
      return user;
    } catch (error) {
      throw new Error(`Erro no endpoint findUserById - ${error.message}`);
    }
  },
  async findUserByEmail(email) {
    try {
      const user = await db("users").where("email", email).select().first();
      return user;
    } catch (error) {
      throw new Error(`Erro no endpoint findUserById - ${error.message}`);
    }
  },
  async editUser(user, id) {
    try {
      await db("users").update(user).where("id", id);
    } catch (error) {
      throw new Error(`Erro no endpoint findUserById - ${error.message}`);
    }
  },
};

module.exports = User;
