<template>
  <v-row class="cadastro">
    <v-col cols="auto">
      <v-dialog transition="dialog-bottom-transition" width="1000">
        <template v-slot:activator="{ on, attrs }">
          <v-btn class="mb-3 ml-5" text v-bind="attrs" v-on="on">
            {{ cadastrar }}
          </v-btn>
        </template>
        <template v-slot:default="dialog">
          <v-card>
            <v-card-title>E aí, vai matricular ?</v-card-title>
            <v-container fluid class="pa-0">
              <v-row class="mx-3">
                <v-col cols="12" sm="6" md="6">
                  <label for="nome" class="labels pb-3">Título</label>
                  <v-text-field
                    v-model="nome"
                    id="nome"
                    dense
                    outlined
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="3">
                  <label for="dtInicio" class="labels pb-3">Início</label>
                  <v-text-field
                    v-model="data_inicio"
                    id="dtInicio"
                    dense
                    readonly
                    outlined
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="3">
                  <label for="dtInicio" class="labels pb-3">Fim</label>
                  <v-text-field
                    v-model="data_fim"
                    id="dtInicio"
                    dense
                    readonly
                    outlined
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row class="mx-3">
                <label for="info" class="labels pb-3">Informações</label>
                <v-col>
                  <v-textarea
                    id="info"
                    name="input-7-1"
                    filled
                    auto-grow
                    v-model="info"
                  ></v-textarea>
                </v-col>
              </v-row>
              <!-- <v-card-actions class="justify-end pr-5">
                <v-btn outlined color="#002040">MATRICULAR</v-btn>
              </v-card-actions> -->
            </v-container>
            <div class="text-end pa-5">
              <v-btn color="primary" class="mr-3" @click="dialog.value = false"
                >MATRICULAR</v-btn
              >
              <v-btn color="secondary" @click="dialog.value = false"
                >cancelar</v-btn
              >
              <v-btn color="secondary" @click="cadastro = true">snack</v-btn>
            </div>
          </v-card>
        </template>
        <v-snackbar
          v-model="snackbar"
          :timeout="3000"
          absolute
          centered
          top
          :color="snackColor"
        >
          {{ snackText }}
        </v-snackbar>
      </v-dialog>
    </v-col>
  </v-row>
</template>

<script>
import { baseApiUrl } from "../global";
import axios from "axios";
export default {
  data() {
    return {
      user: {},
      snackbar: false,
      snackText: "",
      snackColor: "",
    };
  },
  props: {
    cadastrar: {
      type: String,
    },
  },
  methods: {
    addUser() {
      console.log("userrr", this.user);
      const url = `${baseApiUrl}/users`;
      axios
        .post(url, this.user)
        .then(() => {})
        .catch((error) => {
          console.log(error);
        });
    },
    submit() {
      this.user.tipo = "DISCENTE";
      this.addUser();
      this.snackText = "Boaa!!! Parabéns pelo cadastro.";
      this.snackColor = "rgb(52, 185, 52)";
      this.snackbar = true;
    },
    teste() {
      this.snackText = "Boaa!!! Parabéns pelo cadastro.";
      this.snackColor = "rgb(52, 185, 52)";
      this.snackbar = true;
    },
  },
};
</script>
<style>
.cadastro {
  /* background-color: blue; */
  display: flex;
  justify-content: flex-end;
}
</style>