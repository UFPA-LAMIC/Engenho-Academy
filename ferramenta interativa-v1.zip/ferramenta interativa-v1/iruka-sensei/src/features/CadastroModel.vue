<template>
  <v-row>
    <v-col cols="auto">
      <v-dialog transition="dialog-bottom-transition" width="1000">
        <template v-slot:activator="{ on, attrs }">
          <v-btn class="mb-3 ml-5" icon v-bind="attrs" v-on="on">
            <v-icon>mdi-image-plus</v-icon>
          </v-btn>
        </template>
        <template v-slot:default="dialog">
          <v-card>
            <v-card-title>Upload de Video</v-card-title>
            <v-container fluid class="pa-0">
              <v-row class="mx-3">
                <v-row>
                  <v-col cols="12">
                    <v-text-field
                      color="success"
                      placeholder="Título"
                      v-model="chosenVideo.titulo"
                      outlined
                      loading
                    ></v-text-field>
                  </v-col>
                  <v-col cols="12" sm="6" md="12">
                    <label for="infos" class="labels pb-3">Informações</label>
                    <!-- <div id="infos" v-html="curso.infos"></div> -->
                    <vue-editor
                      id="infos"
                      v-model="chosenVideo.resumo"
                      :editorToolbar="customToolbar"
                    ></vue-editor>
                  </v-col>
                </v-row>
                <v-col cols="8">
                  <div class="up-image">
                    <video
                      id="video-preview"
                      controls
                      v-show="chosenVideo.file != ''"
                    />
                    <label for="file-upload" class="mt-5 custom-file-upload">
                      <v-icon color="white">mdi-arrow-up</v-icon>Upload
                    </label>
                    <input
                      id="file-upload"
                      type="file"
                      accept="video/*"
                      @change="handleFileUpload($event)"
                    />
                  </div>
                </v-col>
              </v-row>
            </v-container>
            <div class="text-end pa-5">
              <v-btn color="secondary" @click="dialog.value = false"
                >cancelar</v-btn
              >
              <v-btn
                color="primary"
                class="ml-3"
                @click="submit(), (dialog.value = false)"
                >ADICIONAR</v-btn
              >
            </div>
          </v-card>
        </template>
      </v-dialog>
      <v-snackbar
        v-model="snackbar"
        :timeout="3000"
        absolute
        centered
        top
        :color="color"
      >
        {{ snackText }}
      </v-snackbar>
    </v-col>
  </v-row>
</template>

<script>
import { baseApiUrl } from "../global";
import axios from "axios";
export default {
  props: {
    id: Number,
  },
  data() {
    return {
      chosenVideo: {
        file: "",
        titulo: "",
        resumo: "",
        curso: null,
        snackText: "",
        color: "",
        snackbar: false,
      },
      customToolbar: [
        [{ font: [] }],
        [{ header: [false, 1, 2, 3, 4, 5, 6] }],
        [{ size: ["small", false, "large", "huge"] }],
        ["bold", "italic", "underline", "strike"],
        [
          { align: "" },
          { align: "center" },
          { align: "right" },
          { align: "justify" },
        ],
        [{ header: 1 }, { header: 2 }],
        ["blockquote", "code-block"],
        [{ list: "ordered" }, { list: "bullet" }, { list: "check" }],
        [{ script: "sub" }, { script: "super" }],
        [{ indent: "-1" }, { indent: "+1" }],
        [{ color: [] }, { background: [] }],
        [{ direction: "rtl" }],
        ["clean"],
      ],
    };
  },
  methods: {
    previewVideo() {
      let video = document.getElementById("video-preview");
      let reader = new FileReader();

      reader.readAsDataURL(this.chosenVideo.file);
      reader.addEventListener("load", function () {
        video.src = reader.result;
      });
    },
    handleFileUpload(event) {
      this.chosenVideo.file = event.target.files[0];
      this.previewVideo();
    },
    addVideo() {
      const url = `${baseApiUrl}/videos`;
      const formData = new FormData();
      formData.append("file", this.chosenVideo.file);
      formData.append("titulo", this.chosenVideo.titulo);
      formData.append("resumo", this.chosenVideo.resumo);
      formData.append("curso", (this.chosenVideo.curso = this.id));
      axios
        .post(url, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((video) => {
          console.log(video);
        })
        .catch((error) => {
          alert(error.response.data.msg);
        });
    },
    submit() {
      this.addVideo();
      this.$emit("updatePage");
      this.snackText = "Upload realizado!";
      this.color = "rgb(51, 222, 71)";
      this.snackbar = true;
    },
  },
};
</script>

<style>
.up-image {
  /* background-color: red; */
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.image-placeholder {
  background-color: #f3f3f3;
  width: 100%;
  height: 230px;
  border: solid 1px #9a9a9a;
  text-align: center;
  display: table;
}
.image-placeholder :hover {
  cursor: pointer;
}
.centered-text {
  display: table-cell;
  vertical-align: middle;
}
.input-file {
  display: none;
}
.hint-text {
  font-size: 12px;
  letter-spacing: 0.23px;
  color: #656565;
}
input[type="file"] {
  display: none;
}
.custom-file-upload {
  /* border: 1px solid #ccc;
  display: inline-block;
  padding: 6px 12px;
  cursor: pointer; */
  background-color: #002040; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-decoration: none;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 18px;
  cursor: pointer;
}
</style>