<template>
  <v-container class="all-content pa-0" fluid>
    <!-- <aside class="header" v-if="hasFilter">
      <aside class="text-field">
        <v-text-field
          class="filter"
          prepend-inner-icon="mdi-magnify"
          placeholder="Pesquisar por curso"
          outlined
          dense
        ></v-text-field>
      </aside>
    </aside> -->
    <div class="base-page-content-no-style" v-if="hasNoStyle">
      <slot></slot>
    </div>
    <div class="base-page-content" v-else>
      <slot></slot>
    </div>
  </v-container>
</template>
  
  <script>
export default {
  name: "BasePageLayout",
  props: {
    hasFilter: {
      type: Boolean,
      default: false,
    },
    hasNoStyle: {
      type: Boolean,
      default: false,
    },
  },
};
</script>
  
  <style lang="scss" scoped>
/* Consulta de mídia para telas maiores (por exemplo, tablets e desktops) */
.all-content {
  min-height: inherit;
}
.header {
  display: flex;
  align-items: center;
  height: 80px;
  background: #f4f4f4;
  padding: 0 20px;
}
.text-field {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 40%;
}

.filter {
  position: relative;
  top: 20%;
  border-radius: 30px !important;
}

.base-page-content-no-style {
  min-height: inherit;
}

.base-page-content {
  padding: 20px;
  min-height: inherit;
}

/* ::v-deep .v-input__slot{
  background: red;
} */
/* Estilos base para dispositivos móveis (mobile first) */
@media screen and (max-width: 855px) {
  .text-field {
    width: 65%;
  }
}

@media screen and (max-width: 440px) {
  .text-field {
    width: 80%;
  }
}
</style>