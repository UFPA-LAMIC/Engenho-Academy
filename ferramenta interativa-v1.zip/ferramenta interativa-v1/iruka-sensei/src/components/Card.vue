<template>
  <div class="course-card" @click="redirect">
    <img
      class="course-img"
      src="@/assets/no_image_course.png"
      alt="no card image"
    />
    <h3>{{ titulo }}</h3>
    <aside>
      <p>{{ docente }}</p>
      <span>04 Vídeos</span>
    </aside>
  </div>
</template>

<script>
export default {
  props: {
    redirectTo: {
      type: String,
      default: "home",
    },
    titulo: {
      type: String,
      default: "Título do Curso",
    },
    docente: {
      type: String,
      default: "Docente",
    },
    idCurso:{}
  },
  methods: {
    redirect() {
      // this.$router.push({ name: `${this.redirectTo}` }).catch(() => {});
      this.$router
        .push({
          name: `${this.redirectTo}`,
          params: {id: this.idCurso},
        })
        .catch(() => {});
    },
  },
};
</script>

<style lang="scss" scoped>
.course-card {
  width: 280px;
  height: 300px;
  padding: 10px;
  // background: orange;
  box-shadow: 1px 1px rgb(227, 227, 227), 0 0 0.08em rgb(184, 184, 184);
}

.course-card:hover {
  cursor: pointer;
}

.course-img {
  width: 260px;
}

h3 {
  font-size: 1.2rem;
  font-weight: 700;
  letter-spacing: -0.04rem;
  line-height: 20px;
  color: #2d2f31;
  margin: 10px 0;
  font-family: $secondary_font;
}

p,
span {
  font-size: 0.8rem;
  // font-weight: 700;
  font-family: $secondary_font;
}

p {
  margin: 0;
}
</style>