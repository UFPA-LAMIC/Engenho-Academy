<template>
  <div class="toolbar">
    <aside class="logo">
      <img src="@/assets/logo-branco.png" alt="logo" />
    </aside>
    <aside class="menu" v-if="larguraDaTela > 440">
      <v-list class="menu-items">
        <v-list-item
          v-for="item in menu"
          :key="item.name"
          class="item"
          :to="item.to"
        >
          <v-list-item-content>
            <p class="content">
              {{ item.name }}
            </p>
          </v-list-item-content>
        </v-list-item>
      </v-list>
      <div v-if="$isLogged()">
        <logged-user :user="user" />
      </div>
      <v-btn v-else class="botao" outlined to="login">Login</v-btn>
    </aside>
    <div class="mobile" v-else>
      <v-icon @click="drawer = !drawer" size="32">mdi-menu</v-icon>
      <v-navigation-drawer v-model="drawer" absolute left temporary>
        <v-list nav dense>
          <v-list-item-group
            class=""
            active-class="orange--text"
            v-model="group"
          >
            <v-list-item to="home">
              <v-list-item-title>Home</v-list-item-title>
            </v-list-item>

            <v-list-item to="Meus Cursos">
              <v-list-item-title>Meus Cursos</v-list-item-title>
            </v-list-item>

            <v-list-item>
              <v-list-item-title>Sobre o Projeto</v-list-item-title>
            </v-list-item>

            <v-list-item to="login">
              <v-list-item-title>Login</v-list-item-title>
            </v-list-item>
          </v-list-item-group>
        </v-list>
      </v-navigation-drawer>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import LoggedUser from "@/components/LoggedUser.vue";
// import axios from "axios";
// import { baseApiUrl } from "@/global";

export default {
  components: {
    // LoggedUser,
    LoggedUser,
  },
  data: () => ({
    drawer: false,
    group: null,
    tela: 1000,
    larguraDaTela: window.innerWidth,
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
    menu() {
      return [
        {
          name: "Home",
          to: "/home",
        },
        {
          name: "Meus cursos",
          to: "/meus-cursos",
        },
        {
          name: "Sobre o projeto",
          to: "/experiencias",
        },
      ];
    },
  },
  beforeRouteUpdate(to, from, next) {
    this.recarrregarComponenteToolbar();
    next();
  },
  watch: {
    group() {
      this.drawer = false;
    },
    $route: "recarrregarComponenteToolbar",
  },
  mounted() {
    this.tela = window.screen.width;
    window.addEventListener("resize", this.atualizarLarguraDaTela);
  },
  beforeDestroy() {
    // Remove o ouvinte de evento de redimensionamento quando o componente é destruído
    window.removeEventListener("resize", this.atualizarLarguraDaTela);
  },
  methods: {
    atualizarLarguraDaTela() {
      this.larguraDaTela = window.innerWidth;
    },
    recarrregarComponenteToolbar() {
      // Simule um atraso assíncrono (substitua isso pela lógica real)
      // Atualize a variável logged após o atraso (substitua isso pela lógica real)
      return this.$isLogged();
    },
    formatAvatar(name) {
      const nameSplitted = name.split(" ");
      return (
        nameSplitted[0].charAt(0) +
        nameSplitted[nameSplitted.length - 1].charAt(0)
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.toolbar {
  display: flex;
  // justify-content: space-around;
  align-items: center;
  padding: 30px;
  height: 90px;
  max-width: 100% !important;
  box-shadow: 3px 3px rgb(221, 221, 221), -1em 0 0.4em rgb(95, 95, 95);
  background: $primary_color;
}
.logo {
  width: 30%;
}

.logo img {
  width: 120px;
}

.botao {
  padding: 3px 15px 3px 15px;
  border: 1px solid;
  font-size: 14px;
  font-family: $primary_font;
  text-transform: capitalize;
  color: $fontes_background;
}

.botao:hover {
  background: #da9e06bd;
  transition: 1s;
}

.menu {
  width: 70%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  // background: purple;
}

.menu-items {
  display: flex;
  justify-content: flex-end;
  align-items: flex-end;
  background: transparent !important;
  position: relative;
  // top: 70px !important;
  & .item {
    word-break: keep-all !important;
    text-align: end !important;
    margin: 3px !important;
  }
  & .item:hover {
    background-color: rgba(59, 54, 54, 0.262);
    color: transparent;
    transition: 1s;
  }
  & .content {
    width: 130px;
    margin: 0;
    color: $fontes_background;
    letter-spacing: -1;
    font-size: 16px;
    font-weight: 500;
    text-align: center !important;
    font-family: $primary_font;
  }
}

.v-list-item--active {
  color: transparent !important;
}

@media screen and (max-width: 915px) {
  .toolbar {
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
    height: 220px;
    padding: 20px;
  }

  .logo img {
    width: 100px;
    margin-bottom: 3px;
  }

  .menu {
    justify-content: space-around;
    width: 100%;
  }
  .menu-items {
    padding-top: 0;
    flex-wrap: wrap;
    width: 30%;
  }
}

@media screen and (max-width: 440px) {
  .toolbar {
    display: grid;
    grid-template-columns: 1fr;
    // flex-direction: column;
    // justify-content: flex-start;
    // align-items: flex-start;
    height: 120px;
    // padding: 20px;
  }

  .logo {
    text-align: center;
    // background: red;
    width: 100%;
  }

  .mobile {
    margin-top: 20px;
  }

  .menu {
    justify-content: space-between;
    width: 100%;
  }
  .menu-items {
    flex-direction: column;
    & .item {
      margin: 0 !important;
      background: transparent !important;
    }
    & .content {
      text-align: start !important;
      // font-size: 18px;
      font-weight: 700;
    }
  }

  .bkg-menu {
    background: rgb(212, 170, 170);
    color: white;
  }

  button {
    text-align: end;
    // margin-right: 20px;
  }
}
</style>
