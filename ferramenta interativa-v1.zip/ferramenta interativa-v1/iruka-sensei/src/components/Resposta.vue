<template>
  <!-- Se não tiver resposta -->
  <v-row>
    <v-col cols="12" sm="6" md="12">
      <vue-editor
        id="infos"
        :editorToolbar="customToolbar"
        :placeholder="placeholder"
        v-model="propModel"
      ></vue-editor>
    </v-col>
    <div class="text-start pb-3">
      <v-btn
        class="mr-2"
        text
        outlined
        color="secondary"
        small
        @click="$emit('cancel')"
        >cancelar</v-btn
      >
      <v-btn color="primary" small @click="$emit('input')">publicar</v-btn>
    </div>
  </v-row>
</template>

<script>
export default {
  props: {
    id_resposta: {
      type: Number,
    },
    texto: {
      type: String,
    },
    placeholder: {
      type: String,
    },
  },
  data: () => ({
    resposta: {},
    customToolbar: [
      [{ font: [] }],
      [{ header: [false, 1, 2, 3, 4, 5, 6] }],
      [{ size: ["small", false, "large", "huge"] }],
      ["bold", "italic", "underline", "strike"],
      [
        { align: "" },
        { align: "center" },
        { align: "right" },
        { align: "justify" },
      ],
      [{ header: 1 }, { header: 2 }],
      ["blockquote", "code-block"],
      [{ list: "ordered" }, { list: "bullet" }, { list: "check" }],
      [{ script: "sub" }, { script: "super" }],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ color: [] }, { background: [] }],
      [{ direction: "rtl" }],
      ["clean"],
    ],
  }),
  computed: {
    propModel: {
      get() {
        return this.texto;
      },
      set(value) {
        this.$emit("update:texto", value);
      },
    },
  },
};
</script>

<style>
</style>
