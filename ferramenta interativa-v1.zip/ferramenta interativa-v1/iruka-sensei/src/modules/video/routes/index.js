export default [
  {
    path: "/videos",
    name: "videos",
    component: () => import("@/modules/video/views/Videos.vue"),
  },
  {
    path: "/adicionar-videos",
    name: "Add video",
    component: () => import("@/modules/video/views/AdicionarVideo.vue"),
  },
];
