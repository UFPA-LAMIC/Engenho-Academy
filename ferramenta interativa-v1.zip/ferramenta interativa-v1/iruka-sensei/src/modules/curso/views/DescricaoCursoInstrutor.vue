<template>
  <base-page-layout has-no-style>
    <aside v-if="!edit">
      <div class="header-description">
        <h3>{{ curso.nome }}</h3>
        <p>
          <span>Criado por</span> <strong>{{ curso.criador }}</strong>
        </p>
      </div>
      <aside class="content">
        <aside class="first-column">
          <h4>O que você irá aprender</h4>
          <div v-html="curso.aprendizado"></div>
          <h4>Descrição do curso</h4>
          <div v-html="curso.descricao"></div>
        </aside>
        <div class="second-column">
          <v-btn depressed dark color="#4966FE" @click="editar"
            >Editar Curso</v-btn
          >
          <v-btn depressed dark color="#4966FE" @click="videos(curso.id)"
            >Vídeos</v-btn
          >
          <v-btn depressed dark color="#4966FE" @click="matriculas(curso.id)"
            >Matriculas</v-btn
          >
        </div>
      </aside>
    </aside>

    <aside v-else>
      <div class="">
        <v-text-field
          class="campo mb-5"
          id="instrutor"
          v-model="curso.nome"
          outlined
          hide-details
        ></v-text-field>
      </div>
      <aside class="content">
        <aside class="first-column">
          <h4>O que você irá aprender</h4>
          <vue-editor
            v-model="curso.aprendizado"
            id="aprendizado"
            :editorToolbar="customToolbar"
          />
          <h4>Descrição do curso</h4>
          <vue-editor
            v-model="curso.descricao"
            id="aprendizado"
            :editorToolbar="customToolbar"
          />
        </aside>
        <div class="second-column">
          <v-btn depressed dark color="#4966FE" @click="salvar">Salvar</v-btn>
          <v-btn depressed dark color="#b0332a" @click="cancelar"
            >cancelar</v-btn
          >
        </div>
      </aside>
    </aside>
  </base-page-layout>
</template>
  
  <script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import Swal from "sweetalert2";
import axios from "axios";
import { baseApiUrl } from "@/global";
export default {
  components: { BasePageLayout },
  data: () => ({
    redirect: null,
    curso: {},
    edit: false,
    customToolbar: [
      [{ header: [false, 1, 2, 3, 4, 5, 6] }],
      ["bold", "italic", "underline", "strike"], // toggled buttons
      [{ align: [] }],
      ["blockquote", "code-block"],
      [{ list: "ordered" }, { list: "bullet" }, { list: "check" }],
      [{ indent: "-1" }, { indent: "+1" }], // outdent/indent
      [{ color: [] }, { background: [] }], // dropdown with defaults from theme
      ["link"],
      ["clean"], // remove formatting button
    ],
  }),
  mounted() {
    this.getCursoInfos();
  },
  methods: {
    isLoggedIn() {
      this.$isLogged() && this.$showPage()
        ? this.newAlert()
        : this.$router.push({ name: "login" }).catch(() => {});
    },
    newAlert() {
      Swal.fire({
        // position: "top-end",
        icon: "success",
        title: "Sua matrícula foi solicitada!",
        showConfirmButton: false,
        timer: 2500,
      });
    },
    editar() {
      this.edit = !this.edit;
    },
    videos(id) {
      this.$router.push({ name: "videos", params: { id: id } }).catch(() => {});
    },
    matriculas(id) {
      this.$router.push({ name: "matricula", params: { id: id } }).catch(() => {});
    },
    async salvar() {
      const cursoEditado = {
        nome: this.curso.nome,
        aprendizado: this.curso.aprendizado,
        descricao: this.curso.descricao,
      };
      await axios.put(
        `${baseApiUrl}/cursos/${this.$route.params.id}`,
        cursoEditado
      );
      this.edit = !this.edit;
      this.getCursoInfos();
    },
    cancelar() {
      this.edit = !this.edit;
      this.getCursoInfos();
    },
    async getCursoInfos() {
      const response = await axios.get(
        `${baseApiUrl}/cursos/${this.$route.params.id}`
      );
      this.curso = response.data;
    },
  },
};
</script>
  
  <style lang="scss" scoped>
.header-description {
  background: $dark_banner;
  height: 120px;
  padding: 30px;

  h3 {
    font-size: 32px;
    color: $light;
    font-weight: 400;
  }
  p {
    margin: 0;
    font-family: $primary_font;
    color: $light;
    font-weight: 400;

    & span {
      font-weight: 200;
      color: $lighter;
    }
  }
}

.content {
  padding: 20px 20px 20px 30px;
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 30px;

  & h4 {
    font-family: $primary_font;
    font-size: 24px;
    color: $dark;
    font-weight: 400;
    margin-bottom: 10px;
  }

  & .text {
    line-height: 25px;
    font-family: $primary_font;
    color: $black;
  }

  & .second-column {
    // background: red;
    display: flex;
    flex-direction: column;
    align-items: center;

    & button {
      margin-top: 20px;
      width: 220px;
      text-transform: capitalize;
      font-family: $primary_font;
      font-size: 16px;
      // color: $primary_btn;
    }
  }
}
.campo {
  width: 800px;
  margin: 30px;
}

@media screen and (max-width: 765px) {
  .header-description {
    padding: 20px;
    h3 {
      font-size: 26px;
    }
    p {
      font-size: 14px;
    }
  }
  .content {
    gap: 20px;
    padding: 20px;

    & h4 {
      font-size: 20px;
    }

    & .text {
      font-size: 14px;
    }

    & .second-column {
      & .course-img {
        width: 260px;
      }

      & .adicionais {
        // background: red;
        width: 260px;

        & h5 {
          font-size: 18px;
        }

        & .teste {
          & .teste2 p {
            font-size: 13px;
          }
        }
      }

      & button {
        width: 260px;
        font-size: 14px;
      }
    }
  }
}

@media screen and (max-width: 630px) {
  .header-description {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 10px 20px 10px 20px;
    height: 100px;
    // text-align: center;
    // height: 140px;
    h3 {
      font-size: 22px;
    }
    p {
      font-size: 14px;
    }
  }
  .content {
    display: flex;
    flex-direction: column-reverse;
  }
}
</style>