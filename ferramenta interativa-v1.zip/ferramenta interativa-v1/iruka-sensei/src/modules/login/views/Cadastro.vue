<template>
  <base-page-layout>
    <div class="content">
      <!-- <div class="voltar">
        <p @click="redirect">Voltar</p>
      </div> -->
      <div class="voltar">
        <v-btn class="voltar-btn" text @click="redirect">Voltar</v-btn>
      </div>
      <h3>Cadastre-se de maneira bem rápida</h3>
      <aside class="content-form">
        <aside class="first-column">
          <v-text-field
            class="campo"
            v-model="user.nome"
            outlined
            hide-details
            placeholder="Nome completo"
            label="Nome completo"
          ></v-text-field>
          <v-text-field
            class="campo"
            v-model="user.email"
            outlined
            hide-details
            placeholder="E-mail"
            label="E-mail"
          ></v-text-field>
          <v-text-field
            class="campo"
            v-model="user.password"
            type="password"
            outlined
            hide-details
            placeholder="Senha"
            label="Senha"
          ></v-text-field>
          <v-text-field
            class="campo"
            v-model="user.confirmPassword"
            outlined
            type="password"
            hide-details
            placeholder="Confirmar a senha"
            label="Confirmar a senha"
          ></v-text-field>
          <v-text-field
            class="campo-data"
            v-model="user.dt_nascimento"
            hide-details
            outlined
            type="date"
            label="Data de nascimento"
          ></v-text-field>
          <aside class="ufpa">
            <label for="aluno">Aluno da UFPA:</label>
            <v-radio-group id="aluno" v-model="ufpa" row>
              <v-radio label="Sim" value="sim"></v-radio>
              <v-radio label="Não" value="nao"></v-radio>
            </v-radio-group>
          </aside>
          <v-select
            v-if="ufpa === 'sim'"
            class="curso"
            outlined
            :items="cursos"
            item-text="nome"
            item-value="id"
            label="Curso"
            v-model="user.graduacao"
          >
          </v-select>
          <aside class="ufpa">
            <label for="aluno">Possui alguma deficiencia ?</label>
            <v-radio-group id="aluno" v-model="pcd" row>
              <v-radio label="Sim" value="sim"></v-radio>
              <v-radio label="Não" value="nao"></v-radio>
            </v-radio-group>
          </aside>
          <v-select
            v-if="pcd === 'sim'"
            v-model="user.pne"
            class="curso"
            outlined
            :items="pne"
          >
          </v-select>
          <v-btn class="cadastrar" color="#4966FE" dark @click="cadastrar"
            >Cadastrar</v-btn
          >
        </aside>
      </aside>
    </div>
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
export default {
  components: { BasePageLayout },
  data() {
    return {
      user: {},
      ufpa: "sim",
      pcd: null,
      cursos: [],
      pne: ["Visual", "Motora"],
    };
  },
  mounted() {
    this.ufpaCursos();
  },
  methods: {
    async cadastrar() {
      try {
        await axios.post(`${baseApiUrl}/users`, this.user);
        this.$snackbar({
          message: "Usuário cadastrado com sucesso!",
          color: "#00b395",
          timeout: 4000,
        });
        this.user = {}
        this.$router.push({ name: "login" }).catch(() => {});
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao cadastrar usuário",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    async ufpaCursos() {
      const response = await axios.get(`${baseApiUrl}/graduacao`);
      this.cursos = response.data.data;
    },
    redirect() {
      this.$router.push({ name: "login" }).catch(() => {});
    },
  },
};
</script>

<style lang="scss" scoped>
.content {
  min-height: inherit;
  display: flex;
  flex-direction: column;
  justify-content: center;
  // align-items: center;
  // background: red;

  & .voltar {
    width: 45%;
    text-align: center;
  }

  & .voltar-btn {
    text-transform: capitalize;
    font-family: $primary_font;
    font-weight: 700;
    font-size: 16px;
  }

  & h3 {
    text-align: center;
    font-family: $primary_font;
    font-size: 32px;
    margin: 30px 0;
    font-weight: 400;
  }

  & .content-form {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    // background: red;

    & .first-column {
      margin-right: 20px;
    }

    & .second-column {
      margin-left: 20px;
    }
    & .campo {
      width: 400px;
      margin: 0 0 20px 0;
      //   height: 45px !important;
      //   background: green;
    }

    & .campo-data {
      width: 400px;
      margin: 0 0 20px 0;
      position: relative;
      // top: -20px;
      // background: orange;
    }

    & .ufpa {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      position: relative;
      // top: -20px;
      height: 45px;
      // background: purple;

      & label {
        font-family: $primary_font;
        margin-right: 15px;
      }
    }

    & .curso {
      position: relative;
      // bottom: -10px;
    }

    & .cadastrar {
      height: 56px;
      width: 100%;
      text-transform: capitalize;
      font-family: $primary_font;
      font-size: 18px;
      letter-spacing: -0.03px;
    }
  }
}

@media screen and (max-width: 935px) {
  .content {
    margin-bottom: 30px;
  }
  .content-form {
    display: flex;
    flex-direction: column;
    align-items: center;
    // background: red;

    & .first-column {
      margin: 0 !important;
    }
    & .second-column {
      margin: 0 !important;
    }

    & .campo {
      margin-bottom: 15px;
    }

    & .campo-data {
      top: 0 !important;
      //   background: orange;
    }

    & .ufpa {
      top: 0 !important;
    }
  }
}

@media screen and (max-width: 465px) {
  .content {
    margin-bottom: 30px;
  }
  .voltar {
    width: 25% !important;
    margin-top: 20px;
    border: 1px solid;
    border-radius: 4px;
  }

  h3 {
    text-align: center;
    font-family: $login_font;
    font-size: 22px !important;
    margin: 30px 0;
  }

  .ufpa {
    padding: 0 20px;
  }

  .cadastrar {
    margin: 0 20px;
    width: 360px !important;
  }
  ::v-deep.v-input {
    // background: red !important;
    padding: 0 20px;
  }
}
</style>