export default [
    {
        path: '/login',
        name: 'login',
        component: () => import('@/modules/login/views/Login.vue')
    },
    // {
    //     path: '/expired-token',
    //     name: 'Expired Token',
    //     component: () => import('@/modules/login/views/ExpiredToken.vue')
    // },
    // {
    //     path: '/access-denied',
    //     name: 'Access Denied',
    //     component: () => import('@/modules/login/views/AccessDenied.vue')
    // },
    {
        path: '/cadastro',
        name: 'cadastro',
        component: () => import('@/modules/login/views/Cadastro.vue')
    },
]