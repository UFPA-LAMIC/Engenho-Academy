<template>
  <div class="password-modal">
    <div class="password-text">
      <v-btn icon @click="closeModal">
        <v-icon large>mdi-close</v-icon>
      </v-btn>
      <p class="password-text__title">Crie uma senha de acesso</p>
      <p class="password-text__subtitle">
        Usuários novos recém cadastrados conseguem criar uma senha para acessar
        o sistema.
      </p>
    </div>
    <v-card class="login-card" width="500" height="420">
      <div class="login-card__text">
        <label class="modal-label mb-2">Nome funcional:</label>
        <v-text-field
          v-model="newUser.nome_funcional"
          placeholder="Nome funcional"
          outlined
          dense
        ></v-text-field>
        <label class="modal-label mb-2">Nova senha:</label>
        <v-text-field
          v-model="newUser.password"
          placeholder="Senha"
          outlined
          dense
          :append-icon="show2 ? 'mdi-eye' : 'mdi-eye-off'"
          :rules="[rules.required, rules.min]"
          :type="show2 ? 'text' : 'password'"
          @click:append="show2 = !show2"
        ></v-text-field>
        <label class="modal-label mb-2">Confirme sua senha:</label>
        <v-text-field
          v-model="newUser.confirmPassword"
          placeholder="Confirmar senha"
          outlined
          dense
          :append-icon="show2 ? 'mdi-eye' : 'mdi-eye-off'"
          :rules="[rules.required, rules.min]"
          :type="show2 ? 'text' : 'password'"
          @click:append="show2 = !show2"
        ></v-text-field>
        <div class="login-card__btns">
          <v-btn
            dark
            large
            color="#041833"
            :loading="loading"
            @click="savePassword"
            >Cadastrar senha</v-btn
          >
        </div>
      </div>
    </v-card>
  </div>
</template>

<script>
import axios from "axios";
import { baseApiUrl } from "@/global";
export default {
  data: () => ({
    newUser: {},
    loading: false,
    show2: false,
    rules: {
      required: (value) => !!value || "Required.",
    },
  }),
  methods: {
    async savePassword() {
      try {
        this.loading = true;

        await axios.put(`${baseApiUrl}/users`, this.newUser);

        this.$snackbar({
          message: "Senha cadastrada com sucesso!",
          color: "#00b395",
          timeout: 4000,
        });

        this.loading = false;
        this.$emit("close");
      } catch (error) {
        console.log(error);
        if (error.response.status === 401) {
          this.$snackbar({
            message: error.response.data.msg,
            color: "#e02222",
            timeout: 4000,
          });
          this.loading = false;
          return;
        }
        this.$snackbar({
          message: "Erro ao criar senha",
          color: "#e02222",
          timeout: 4000,
        });
        this.loading = false;
      }
    },
    closeModal() {
      this.$emit("close");
      this.newUser = {};
    },
  },
};
</script>

<style lang="scss" scoped>
.password-modal {
  position: relative;
  bottom: 10px;
}
.password-text {
  width: 520px;
  // padding: 0 40px;
  & button {
    position: relative;
    left: 450px;
  }
  &__title {
    margin-bottom: 0;
    font-size: 28px;
    font-weight: 500;
    letter-spacing: -1px;
    color: #314b6de1;
  }
  &__subtitle {
    font-size: 14px;
    letter-spacing: -0.15px;
    color: #606060e1;
  }
}
.login-card {
  &__text {
    padding: 40px 40px;
  }
  &__btns {
    text-align: center;
  }
  &__btns button {
    width: 100%;
  }
  &__btns p {
    margin-top: 25px;
    font-size: 14px;
    font-weight: 500;
    color: #0079f2;
    cursor: pointer;
    text-decoration: underline;
  }

  .modal-label {
    font-weight: 700;
    color: rgba(90, 90, 90, 0.844);
  }
}
</style>