export default [
  {
    path: "/matricula",
    name: "matricula",
    component: () => import("@/modules/matricula/views/Matricula.vue"),
  },
];
