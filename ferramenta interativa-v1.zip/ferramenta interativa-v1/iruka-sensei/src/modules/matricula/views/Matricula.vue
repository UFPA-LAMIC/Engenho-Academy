<template>
  <base-page-layout :has-filter="hasFilter">
    <aside>
      <div class="titulo">
        <h1>Quadro de matricula do curso</h1>
      </div>
      <div class="table-container">
        <v-data-table :items="items" :headers="headers">
          <template v-slot:item="{ item }">
            <tr>
              <td>{{ dateTransform(item.dth_sistema) }}</td>
              <td>{{ item.nome_aluno }}</td>
              <td>
                <p class="status" :style="color(item.status)">
                  {{ textTransform(item.status) }}
                </p>
              </td>

              <td v-if="item.status === 0">
                <v-tooltip max-width="250" top>
                  <template #activator="{ on }">
                    <span v-on="on">
                      <v-btn
                        icon
                        color="#45ac85"
                        @click="deferirMatricula(item.id)"
                      >
                        <v-icon>mdi-check-circle</v-icon>
                      </v-btn>
                    </span>
                  </template>
                  Deferir Matrícula
                </v-tooltip>
                <v-tooltip max-width="250" top>
                  <template #activator="{ on }">
                    <span v-on="on">
                      <v-btn
                        icon
                        color="#e02222"
                        @click="indeferirMatricula(item.id)"
                      >
                        <v-icon>mdi-close-box</v-icon>
                      </v-btn>
                    </span>
                  </template>
                  Indeferir Matrícula
                </v-tooltip>
              </td>
              <td v-if="item.status === 1">
                <v-tooltip max-width="250" top>
                  <template #activator="{ on }">
                    <span v-on="on">
                      <v-btn
                        icon
                        color="#e02222"
                        @click="indeferirMatricula(item.id)"
                      >
                        <v-icon>mdi-close-box</v-icon>
                      </v-btn>
                    </span>
                  </template>
                  Indeferir Matrícula
                </v-tooltip>
              </td>
              <td v-if="item.status === 2">
                <v-tooltip max-width="250" top>
                  <template #activator="{ on }">
                    <span v-on="on">
                      <v-btn
                        icon
                        color="#45ac85"
                        @click="deferirMatricula(item.id)"
                      >
                        <v-icon>mdi-check-circle</v-icon>
                      </v-btn>
                    </span>
                  </template>
                  Deferir Matrícula
                </v-tooltip>
              </td>
            </tr>
          </template>
        </v-data-table>
      </div>
    </aside>
  </base-page-layout>
</template>
    
<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
import { truncate } from "lodash";
export default {
  components: { BasePageLayout },
  data: () => ({
    items: [],
    src: "",
    hasFilter: true,
  }),
  computed: {
    headers() {
      return [
        {
          text: "Data Solicitação",
          value: "dth_sistema",
          width: "15%",
        },
        {
          text: "Aluno",
          value: "nome_aluno",
          width: "25%",
        },
        {
          text: "Status",
          value: "status",
          width: "25%",
        },
        {
          text: "Ações",
          value: "",
          width: "15%",
        },
      ];
    },
  },
  beforeMount() {
    this.getMatriculas();
  },
  methods: {
    getFormatedText(text) {
      return truncate(text, {
        length: 24,
        separator: " ",
      });
    },
    async getMatriculas() {
      const response = await axios.get(
        `${baseApiUrl}/matriculas/curso/${this.$route.params.id}`
      );
      this.items = response.data.data;
    },
    color(status) {
      if (status === 1) {
        return { color: "#45ac85" };
      } else if (status === 2) {
        return { color: "#e02222" };
      } else {
        return { color: "#ff7b00" };
      }
    },
    textTransform(number) {
      if (number === 0) {
        return "Solicitada";
      }

      if (number === 1) {
        return "Deferida";
      }

      if (number === 2) {
        return "Indeferida";
      }
    },
    iconeTransform(number) {
      if (number === 0) {
        return "alert";
      }

      if (number === 1) {
        return "check-circle";
      }

      if (number === 2) {
        return "close-box";
      }
    },
    dateTransform(date) {
      const data = date.split(" ");
      return data[0].split("-").reverse().join("/");
    },
    async deferirMatricula(id) {
      await axios.put(`${baseApiUrl}/matriculas/${id}`, { status: 1 });
      this.getMatriculas();
    },
    async indeferirMatricula(id) {
      await axios.put(`${baseApiUrl}/matriculas/${id}`, { status: 2 });
      this.getMatriculas();
    },
  },
};
</script>
    
<style lang="scss" scoped>
.titulo {
  font-family: Arial, Helvetica, sans-serif;
  max-width: 750px;
  margin-bottom: 30px;
  margin-right: 30px;
  // word-break: normal;
}
.titulo h1 {
  letter-spacing: -0.04rem;
  font-size: 28px;
  font-weight: 700;
  font-family: $primary_font;
}

@media screen and (max-width: 830px) {
  .titulo {
    // background: red;
    // word-break: normal;
  }
  .titulo h1 {
    font-size: 24px;
    line-height: 25px;
  }
  .titulo p {
    font-size: 14px;
    line-height: 17px;
  }
}
@media screen and (max-width: 440px) {
}
</style>