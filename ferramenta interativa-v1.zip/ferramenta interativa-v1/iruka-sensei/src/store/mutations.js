export default {
  SET_USER(state, user) {
    state.user = user;
  },
  LOGOUT(state) {
    state.user = {};
  },
  SET_SHOULD_RELOAD(state, value) {
    state.shouldReload = value;
  },
};
