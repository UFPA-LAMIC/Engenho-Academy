<template>
  <div class="home ma-5">
    <h1>Meus Cursos</h1>
    <novo-curso />
    <div class="cards-curso">
      <div v-for="c in cursos" :key="c.id">
        <card-list
          :nome="c.nome"
          :data_inicio="c.data_inicio"
          :data_fim="c.data_fim"
          :color="c.color"
          :id="c.id"
          :docente="c.docente"
          :method="dialogExpand"
          tipo="dialog"
        ></card-list>
      </div>
    </div>
    <v-row>
      <v-col cols="auto">
        <v-dialog
          transition="dialog-bottom-transition"
          width="1000"
          v-model="dialog"
        >
          <v-card color="white">
            <v-card-title>Cadastrar Curso</v-card-title>
            <v-divider class="mx-5"></v-divider>
            <v-card-text fluid class="pa-0">
              <v-row class="mx-3">
                <v-col cols="12" sm="6" md="12">
                  <label for="nome" class="labels pb-3">Título</label>
                  <v-text-field
                    v-model="curso.nome"
                    id="nome"
                    dense
                  ></v-text-field>
                </v-col>
                <v-row>
                  <v-col cols="12" sm="6" md="3">
                    <label for="dtInicio" class="labels pb-3">Início</label>
                    <v-text-field
                      v-model="curso.data_inicio"
                      id="dtInicio"
                      dense
                      type="date"
                    ></v-text-field>
                  </v-col>
                  <v-col cols="12" sm="6" md="3">
                    <label for="dtInicio" class="labels pb-3">Fim</label>
                    <v-text-field
                      v-model="curso.data_fim"
                      id="dtInicio"
                      dense
                      type="date"
                    ></v-text-field>
                  </v-col>
                </v-row>
                <v-col cols="12" sm="6" md="12">
                  <label for="infos" class="labels pb-3">Informações</label>
                  <!-- <div id="infos" v-html="curso.infos"></div> -->
                  <vue-editor
                    id="infos"
                    v-model="curso.infos"
                    :editorToolbar="customToolbar"
                  ></vue-editor>
                </v-col>
              </v-row>
              <v-row class="ml-1">
                <v-col md="1">
                  <v-btn text @click="colorDialog = true">
                    <v-icon :color="curso.color"
                      >mdi-checkbox-blank-circle</v-icon
                    >cor</v-btn
                  >
                </v-col>
                <v-dialog
                  transition="dialog-bottom-transition"
                  width="300"
                  v-model="colorDialog"
                >
                  <div class="pa-5">
                    <v-color-picker
                      dot-size="30"
                      hide-inputs
                      v-model="curso.color"
                    ></v-color-picker>
                  </div>
                  <v-btn color="primary" @click="colorDialog = false"
                    >SALVAR</v-btn
                  >
                </v-dialog>
              </v-row>
            </v-card-text>
            <v-card-actions class="justify-end">
              <v-btn text color="secondary" @click="dialog = false"
                >cancelar</v-btn
              >
              <v-btn dark color="#002040" @click="updateCurso(curso.id)"
                >SALVAR</v-btn
              >
            </v-card-actions>
          </v-card>
        </v-dialog>
      </v-col>
    </v-row>
    <v-snackbar
      v-model="snackbar"
      :timeout="3000"
      right
      top
      :color="snackColor"
    >
      {{ snackText }}
    </v-snackbar>
  </div>
</template>

// <script>
// import { VueEditor } from "vue2-editor";
import axios from "axios";
import { baseApiUrl } from "../global.js";
import { mapGetters } from "vuex";
import CardList from "../components/CardList.vue";
import NovoCurso from "./NovoCurso.vue";
export default {
  name: "Curso",
  components: {
    NovoCurso,
    CardList,
    // VueEditor
  },
  data: () => ({
    expand: false,
    dialog: false,
    colorDialog: false,
    snackText: "",
    snackColor: "#blue",
    snackbar: false,
    user: {},
    cursos: [],
    users: [],
    curso: {},
    customToolbar: [
      [{ font: [] }],
      [{ header: [false, 1, 2, 3, 4, 5, 6] }],
      [{ size: ["small", false, "large", "huge"] }],
      ["bold", "italic", "underline", "strike"],
      [
        { align: "" },
        { align: "center" },
        { align: "right" },
        { align: "justify" },
      ],
      [{ header: 1 }, { header: 2 }],
      ["blockquote", "code-block"],
      [{ list: "ordered" }, { list: "bullet" }, { list: "check" }],
      [{ script: "sub" }, { script: "super" }],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ color: [] }, { background: [] }],
      [{ direction: "rtl" }],
      ["clean"],
    ],
  }),
  methods: {
    ...mapGetters(["getUser"]),
    loadCursos() {
      axios
        .get(`${baseApiUrl}/cursos-docente/${this.$route.params.id}`)
        .then((res) => {
          this.cursos = res.data.data;
          console.log("cursoss", this.cursos);
        })
        .catch((error) => {
          alert(error.res.data.msg);
        });
    },
    async loadCursoById(id) {
      try {
        const response = await axios.get(`${baseApiUrl}/curso/${id}`);
        this.curso = response.data.data;
        console.log("cursoooo", this.curso);
      } catch (error) {
        console.error(error);
      }
    },
    async updateCurso(id) {
      try {
        await axios.put(`${baseApiUrl}/curso/${id}`, this.curso);
        console.log("cursooUpdate", this.curso);
        this.dialog = false;
        this.loadCursos();
      } catch (error) {
        console.error(error);
      }
    },
    dataEdit(id_curso) {
      this.updateCurso(id_curso);
      this.dialog = false;
      this.snackText = "Curso editado com sucesso prof!!!";
      this.snackColor = "rgb(52, 185, 52)";
      this.snackbar = true;
    },
    dialogExpand(value, id) {
      this.dialog = value;
      this.loadCursoById(id);
    },
  },
  mounted() {
    this.loadCursos();
    // if (localStorage.getItem(userKey)) {
    //   try {
    //     this.user = JSON.parse(localStorage.getItem(userKey));
    //     console.log("USEEEERRR", this.user);
    //     this.loadCursos(this.user.id);
    //   } catch (e) {
    //     localStorage.removeItem(userKey);
    //   }
    // }
  },
};
</script>

<style>
.cards-curso {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  flex-wrap: wrap;
}
</style>