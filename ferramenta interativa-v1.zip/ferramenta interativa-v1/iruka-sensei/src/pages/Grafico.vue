<template>
  <div class="home ma-5">
    <h1 style="font: 1.5rem">Gráficos</h1>
    <h4>Por Cursos</h4>
    <div class="chart-div">
      <BarChart
        :chartData="chartData"
        :options="chartOptions"
        class="line-chart"
      />
    </div>
  </div>
</template>

<script>
import BarChart from "../features/BarChart.vue";
import { baseApiUrl } from "../global";
import axios from "axios";
export default {
  name: "Grafico",
  components: { BarChart },
  data: () => ({
    users: [],
    chartData: {
      labels: ["15-18", "19-22", "23-26", "27+"],
      datasets: [
        {
          label: "Matrículas",
          borderColor: "#4bcc96",
          borderWidth: 3,
          pointBackgroundColor: "#4bcc96",
          pointRadius: 5,
          pointHoverBorderColor: "000",
          fill: false,
          data: [10, 32, 23, 28],
        },
      ],
    },
    chartOptions: {
      maintainAspectRatio: false,
      responsive: true,
      tooltips: {
        backgroundColor: "#00055e",
        titleFontColor: "#fff",
        bodyFontColor: "#fff",
        position: "nearest",
        mode: "nearest",
        intersect: 0,
        bodySpacing: 4,
        xPadding: 20,
      },
    },
  }),
  mounted() {
    this.loadMetricaUsers();
  },
  computed: {
    // dtNascimento(){
    // }
  },
  methods: {
    async loadMetricaUsers() {
      try {
        const response = await axios.get(`${baseApiUrl}/metrica-users`);
        this.users = response.data.data;
        console.log("users", this.users);
      } catch (error) {
        console.error(error);
      }
    },
  },
};
</script>
<style>
.line-chart {
  width: 60vw;
  height: 50vh;
}
</style>