import axios from "axios";

export default {
  login({ commit }, user) {
    const formatedUser = {
      id: user.id,
      nome: user.nome,
      tipo: user.tipo,
      email: user.email,
      dt_nascimento: user.dt_nascimento,
      graduacao: user.graduacao
    };
    commit("SET_USER", formatedUser);
  },

  logout({ commit }) {
    // Clear token and user payload from Vuex store
    commit("LOGOUT");
    // Remove token from Axios headers
    delete axios.defaults.headers.common["Authorization"];
  },

  reloadComponent({ commit }) {
    commit('SET_SHOULD_RELOAD', true);
  },

};
