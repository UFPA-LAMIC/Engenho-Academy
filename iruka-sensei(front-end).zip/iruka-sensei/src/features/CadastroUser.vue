<template>
  <v-row class="cadastro">
    <v-col cols="auto">
      <v-dialog transition="dialog-bottom-transition" width="600">
        <template v-slot:activator="{ on, attrs }">
          <v-btn class="mb-3 ml-5" text v-bind="attrs" v-on="on">
            Cadastrar
          </v-btn>
        </template>
        <template v-slot:default="dialog">
          <v-card>
            <v-card-title>Cadastro de usuários</v-card-title>
            <v-container fluid class="pa-0">
              <v-row class="mx-3">
                <v-col cols="12" sm="6" md="12">
                  <label for="nome" class="labels pb-3">Nome</label>
                  <v-text-field
                    id="nome"
                    v-model="user.nome"
                    placeholder="Nome"
                    dense
                    outlined
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row class="mx-3">
                <v-col cols="12" sm="6" md="12">
                  <label for="email" class="labels pb-3">E-mail</label>
                  <v-text-field
                    id="email"
                    v-model="user.email"
                    placeholder="email"
                    dense
                    outlined
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row class="mx-3">
                <v-col cols="12" sm="6" md="6">
                  <label for="dtNascimento" class="labels pb-3"
                    >Data de Nascimento</label
                  >
                  <v-text-field
                    id="dtNascimento"
                    v-model="user.dt_nascimento"
                    type="date"
                    dense
                    outlined
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row class="mx-3">
                <v-col cols="12" sm="6" md="6">
                  <label for="senha" class="labels pb-3">Senha</label>
                  <v-text-field
                    id="senha"
                    v-model="user.password"
                    placeholder="senha"
                    type="password"
                    dense
                    outlined
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="6">
                  <label for="confirm" class="labels pb-3"
                    >Confirmar Senha</label
                  >
                  <v-text-field
                    id="confirm"
                    v-model="user.confirmPassword"
                    placeholder="confirmar senha"
                    type="password"
                    dense
                    outlined
                  ></v-text-field>
                </v-col>
              </v-row>
            </v-container>
            <div class="text-end pa-5">
              <v-btn
                color="primary"
                class="mr-3"
                @click="submit(), (dialog.value = false)"
                >CADASTRAR</v-btn
              >
              <v-btn color="secondary" @click="dialog.value = false"
                >cancelar</v-btn
              >
            </div>
          </v-card>
        </template>
      </v-dialog>
      <v-snackbar
        v-model="snackbar"
        :timeout="3000"
        absolute
        bottom
        left
        :color="snackColor"
      >
        {{ snackText }}
      </v-snackbar>
    </v-col>
  </v-row>
</template>

<script>
import { baseApiUrl } from "../global";
import axios from "axios";
export default {
  data() {
    return {
      user: {},
      genero: ["MASCULINO", "FEMININO", "OUTRO"],
      snackbar: false,
      snackText: "",
      snackColor: "",
    };
  },
  props: {
    cadastro: {
      type: Boolean,
    },
  },
  methods: {
    addUser() {
      console.log("userrr", this.user);
      const url = `${baseApiUrl}/users`;
      axios
        .post(url, this.user)
        .then(() => {})
        .catch((error) => {
          console.log(error);
        });
    },
    submit() {
      this.user.tipo = "DISCENTE";
      this.addUser();
      this.user = {};
      this.snackText = "Boaa!!! Parabéns pelo cadastro.";
      this.snackColor = "rgb(51, 222, 71)";
      this.snackbar = true;
    },
  },
};
</script>
<style>
.cadastro {
  /* background-color: blue; */
  display: flex;
  justify-content: flex-end;
}
</style>