<template>
  <base-page-layout :has-filter="hasFilter">
    <aside class="add-btn">
      <v-btn dark color="#108068" @click="redirectTo('Add video')"
        >Adicionar vídeo</v-btn
      >
    </aside>
    <aside v-if="videos.length > 0">
      <div class="titulo">
        <h1>Vídeos do curso</h1>
      </div>
      <div class="card-container">
        <aside v-for="video in videos" :key="video.id">
          <card-videos
            redirect-to="Add video"
            :id-video="video.id"
            :titulo="video.titulo"
            :ordem="video.ordem"
          />
        </aside>
      </div>
    </aside>
    <aside v-else>
      <div class="sem-videos">
        <img
          src="../../../../public/assets/sem-videos.png"
          alt="Sem videos img"
        />
        <p>Você não possui vídeos cadastrados!</p>
      </div>
    </aside>
  </base-page-layout>
</template>
    
<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
import CardVideos from "@/components/CardVideos.vue";
export default {
  components: { BasePageLayout, CardVideos },
  data: () => ({
    videos: [],
    src: "",
    hasFilter: true,
  }),
  computed: {},
  beforeMount() {
    this.getVideos();
  },
  methods: {
    async getVideos() {
      const response = await axios.get(
        `${baseApiUrl}/videos/curso/${this.$route.params.id}`
      );
      this.videos = response.data.data;
      this.videos.length > 0
        ? (this.hasFilter = true)
        : (this.hasFilter = false);
    },
    redirectTo(where) {
      this.$router
        .push({ name: `${where}`, params: { id: this.$route.params.id } })
        .catch(() => {});
    },
  },
};
</script>
    
    <style lang="scss" scoped>
.add-btn {
  text-align: end;
}
.add-btn button {
  text-transform: capitalize;
}
.titulo {
  font-family: Arial, Helvetica, sans-serif;
  max-width: 750px;
  margin-bottom: 30px;
  margin-right: 30px;
  // word-break: normal;
}
.titulo h1 {
  letter-spacing: -0.04rem;
  font-size: 28px;
  font-weight: 700;
  font-family: $primary_font;
}
.titulo p {
  letter-spacing: -0.03rem;
  font-size: 18px;
  font-weight: 500;
  line-height: 25px;
  font-family: $primary_font;
}
.card-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, auto));
  gap: 20px;
  justify-content: start;
  align-items: center;
  // background: rgb(228, 163, 163);
}
.sem-videos {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 80vh;
}
.sem-videos img {
  width: 800;
  height: 400px;
}

.sem-videos p,
span {
  font-family: $primary_font;
}

.sem-videos span {
  color: $primary_btn;
}
.sem-videos span:hover {
  cursor: pointer;
}

@media screen and (max-width: 830px) {
  .titulo {
    // background: red;
    // word-break: normal;
  }
  .titulo h1 {
    font-size: 24px;
    line-height: 25px;
  }
  .titulo p {
    font-size: 14px;
    line-height: 17px;
  }
}
@media screen and (max-width: 440px) {
}
</style>