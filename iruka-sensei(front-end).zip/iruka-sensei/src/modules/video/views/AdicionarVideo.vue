<template>
  <base-page-layout>
    <div class="pagina">
      <div class="voltar-btn">
        <v-btn class="text-align-start mr-5" color="#ccc" @click="redirectTo"
          >voltar</v-btn
        >
      </div>
      <h2 class="mb-5">Cadastrar Curso</h2>
      <div class="form-curso">
        <aside>
          <label for="titulo">Título do video</label>
          <v-text-field
            class="campo mb-5"
            id="titulo"
            v-model="video.titulo"
            outlined
            hide-details
            placeholder="Título do video"
          ></v-text-field>
        </aside>

        <aside>
          <label for="titulo">URL do vídeo</label>
          <v-text-field
            class="campo mb-5"
            id="titulo"
            v-model="video.url"
            outlined
            hide-details
            placeholder="URL do video"
          ></v-text-field>
        </aside>

        <aside>
          <label for="titulo">Ordem do vídeo</label>
          <v-text-field
            class="campo-menor mb-5"
            id="titulo"
            v-model="video.ordem"
            type="number"
            outlined
            hide-details
            placeholder="0"
          ></v-text-field>
        </aside>

        <div class="submit-btn">
          <v-btn color="#108068" dark @click="submit">salvar</v-btn>
        </div>

        <div v-html="video.url"></div>
      </div>
    </div>
  </base-page-layout>
</template>
    
    <script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";

export default {
  components: { BasePageLayout },
  data: () => ({
    video: {},
    src: "",
  }),
  mounted() {
    // this.getVideoInfo()
  },
  methods: {
    async submit() {
      try {
        const src = this.video.url.split("src=");
        const url = src[1].split(" ");

        const video = {
          titulo: this.video.titulo,
          url: url[0].replace(/"/g, ""),
          ordem: this.video.ordem,
          curso: this.$route.params.id,
        };

        await axios.post(`${baseApiUrl}/videos`, video);
        this.src = video.url;
        this.$snackbar({
          message: "Video cadastrado com sucesso!",
          color: "#00b395",
          timeout: 4000,
        });
        this.video = {};
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao cadastrar video",
          color: "#e02222",
          timeout: 3000,
        });
      }
    },
    redirectTo() {
      this.$router
        .push({ name: "videos", params: { id: this.$route.params.id } })
        .catch(() => {});
    },
    async getVideoInfo() {
      // if()
      const response = await axios.get(
        `${baseApiUrl}/videos/${this.$route.params.id}`
      );
      this.video = response.data;
    },
  },
};
</script>
  <style lang="scss" scoped>
.pagina {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.form-curso {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: start;
  font-family: $primary_font;
}
.editor {
  width: 800px;
}
.campo {
  width: 800px;
}
.campo-menor {
  width: 200px;
}
.voltar-btn {
  text-align: start;
  width: 800px;
  margin: 20px 0;
}
.submit-btn {
  text-align: end;
  width: 800px;
  margin: 20px 0;
}
.voltar-btn button,
.submit-btn button {
  text-transform: capitalize;
}
</style>