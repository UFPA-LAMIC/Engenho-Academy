<template>
  <base-page-layout :has-filter="hasFilter">
    <aside v-if="cursos.length > 0">
      <aside class="add-btn" v-if="user.tipo === 'DOCENTE'">
        <v-btn outlined color="#108068" @click="redirectTo('Cadastrar Curso')"
          >Adicionar curso</v-btn
        >
      </aside>
      <div class="titulo">
        <h1>Meus cursos</h1>
      </div>
      <div class="card-container" v-if="user.tipo === 'DOCENTE'">
        <aside v-for="curso in cursos" :key="curso.id">
          <card
            redirect-to="Descrição do Curso Instrutor"
            :id-curso="curso.id"
            :titulo="curso.nome"
            :docente="curso.responsavel"
          />
        </aside>
      </div>
      <div class="card-container" v-else>
        <aside v-for="curso in cursos" :key="curso.id">
          <card
            redirect-to="Descrição do Curso"
            :id-curso="curso.id"
            :titulo="curso.nome"
            :docente="curso.responsavel"
          />
        </aside>
      </div>
    </aside>
    <aside v-else>
      <div class="sem-cursos">
        <img
          src="../../../../public/assets/sem-cursos.png"
          alt="Sem cursos img"
        />
        <p @click="redirectTo('home')">
          Você não possui cursos cadastrados! <span>Ir para cursos.</span>
        </p>
      </div>
    </aside>
  </base-page-layout>
</template>
  
  <script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import Card from "@/components/Card.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
import { mapState } from "vuex";
export default {
  components: { BasePageLayout, Card },
  data: () => ({
    cursos: [],
    src: "",
    hasFilter: false,
  }),
  computed: {
    ...mapState({ user: (state) => state.user }),
  },
  mounted() {
    this.getCursos();
    this.getCursosOfDocente();
  },
  methods: {
    async getCursos() {
      try {
        if (!this.user) {
          return;
        }
        
        const response = await axios.get(
          `${baseApiUrl}/cursos/matriculados/${this.user.id}`
        );
        this.cursos = response.data.data;
        this.cursos.length > 0
          ? (this.hasFilter = true)
          : (this.hasFilter = false);
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao carregar cursos",
          color: "#e02222",
          timeout: 4000,
        });
      }
    },

    async getCursosOfDocente() {
      try {
        if (!this.user) {
          return;
        }

        if (this.user.tipo === "DISCENTE" || !this.user) {
          return;
        }

        const response = await axios.get(
          `${baseApiUrl}/cursos/instrutor/${this.user.id}`
        );
        this.cursos = response.data.data;
        this.cursos.length > 0
          ? (this.hasFilter = true)
          : (this.hasFilter = false);
      } catch (error) {
        console.log(error);
        this.$snackbar({
          message: "Erro ao carregar cursos do instrutor",
          color: "#e02222",
          timeout: 4000,
        });
      }
    },
    redirectTo(where) {
      this.$router.push({ name: `${where}` }).catch(() => {});
    },
  },
};
</script>
  
  <style lang="scss" scoped>
.add-btn {
  text-align: end;
}
.add-btn button {
  text-transform: capitalize;
}
.titulo {
  font-family: Arial, Helvetica, sans-serif;
  max-width: 750px;
  margin-bottom: 30px;
  margin-right: 30px;
  // word-break: normal;
}
.titulo h1 {
  letter-spacing: -0.04rem;
  font-size: 28px;
  font-weight: 700;
  font-family: $primary_font;
}
.titulo p {
  letter-spacing: -0.03rem;
  font-size: 18px;
  font-weight: 500;
  line-height: 25px;
  font-family: $primary_font;
}
.card-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(285px, auto));
  gap: 20px;
  justify-content: start;
  align-items: center;
  // background: rgb(228, 163, 163);
}
.sem-cursos {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 80vh;
}
.sem-cursos img {
  width: 800;
  height: 400px;
}

.sem-cursos p,
span {
  font-family: $primary_font;
}

.sem-cursos span {
  color: $primary_btn;
}
.sem-cursos span:hover {
  cursor: pointer;
}

@media screen and (max-width: 830px) {
  .titulo {
    // background: red;
    // word-break: normal;
  }
  .titulo h1 {
    font-size: 24px;
    line-height: 25px;
  }
  .titulo p {
    font-size: 14px;
    line-height: 17px;
  }
}
@media screen and (max-width: 440px) {
}
</style>