<template>
  <base-page-layout>
    <div class="video">
      <iframe
        width="1200"
        height="600"
        :src="src"
        title="YouTube video player"
        frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen
      ></iframe>

      <v-card class="video-list ml-5" tile>
        <v-list>
          <v-subheader class="subtitle">Aulas do curso</v-subheader>
          <v-list-item-group v-model="selectedItem" color="primary">
            <v-list-item v-for="(item, i) in items" :key="i">
              <p class="mr-3" style="margin: 0">{{ item.ordem }} -</p>
              <v-list-item-content @click="chooseVideo(item)">
                <v-list-item-title class="texto">{{
                  item.titulo
                }}</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
      </v-card>
    </div>

    <!-- <v-tabs class="mt-2" color="#77C">
      <v-tab>Perguntas e respostas</v-tab>
      <v-tab>Visão geral</v-tab>
    </v-tabs>
    <v-btn text>Fazer uma nova pergunta</v-btn> -->
  </base-page-layout>
</template>

<script>
import BasePageLayout from "@/components/BasePageLayout.vue";
import axios from "axios";
import { baseApiUrl } from "@/global";
export default {
  components: { BasePageLayout },
  data: () => ({
    selectedItem: 1,
    items: [],
    src: "",
  }),
  mounted() {
    this.getVideos();
    window.scrollTo(0, 0);
  },
  methods: {
    async getVideos() {
      const response = await axios.get(`${baseApiUrl}/videos/curso/${this.$route.params.id}`);
      this.items = response.data.data;
      this.src = this.items[0].url
      this.selectedItem = this.items[0].ordem -1
    },
    chooseVideo(item) {
      this.src = item.url
      this.selectedItem = this.items.ordem -1
    }
  },
};
</script>

<style lang="scss" scoped>
.video {
  display: flex;
  justify-content: space-between;
  width: 100%;
  height: 100vh;
  // background-color: red;
}
.subtitle {
  font-size: 22px;
  font-weight: 500;
  font-family: $primary_font;
  color: $black;
}
.video-list {
  min-width: 450px;
  max-width: 450px;
}
.texto {
  text-wrap: wrap;
  font-family: $primary_font;
}
</style>