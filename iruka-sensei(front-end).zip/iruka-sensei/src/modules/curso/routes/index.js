export default [
  {
    path: "/descricao-curso/:id",
    name: "Descrição do Curso",
    component: () => import("@/modules/curso/views/DescricaoCurso.vue"),
  },
  {
    path: "/descricao-curso-instrutor/:id",
    name: "Descrição do Curso Instrutor",
    component: () => import("@/modules/curso/views/DescricaoCursoInstrutor.vue"),
  },
  {
    path: "/curso",
    name: "Curso",
    component: () => import("@/modules/curso/views/AssistirCurso.vue"),
  },
  {
    path: "/video/:id",
    name: "video",
    component: () => import("@/modules/curso/views/AssistirCurso.vue"),
  },
  {
    path: "/meus-cursos",
    name: "Meus Cursos",
    component: () => import("@/modules/curso/views/MeusCursos.vue"),
  },
  {
    path: "/cadastrar-curso",
    name: "Cadastrar Curso",
    component: () => import("@/modules/curso/views/CadastrarCurso.vue"),
  },
];
