<template>
    <div class="video-card" @click="redirect">
      <img
        class="video-img"
        src="@/assets/no_image_course.png"
        alt="no card image"
      />
      <h3>{{ titulo }}</h3>
      <aside>
        <p>{{ ordem }}</p>
      </aside>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      redirectTo: {
        type: String,
        default: "home",
      },
      titulo: {
        type: String,
        default: "Título do Vídeo",
      },
      ordem: {
        type: Number,
        default: 0,
      },
      idVideo:{}
    },
    methods: {
      redirect() {
        // this.$router.push({ name: `${this.redirectTo}` }).catch(() => {});
        this.$router
          .push({
            name: `${this.redirectTo}`,
            params: {id: this.idVideo},
          })
          .catch(() => {});
      },
    },
  };
  </script>
  
  <style lang="scss" scoped>
  .video-card {
    width: 220px;
    height: 260px;
    padding: 10px;
    // background: orange;
    box-shadow: 1px 1px rgb(227, 227, 227), 0 0 0.08em rgb(184, 184, 184);
  }
  
  .video-card:hover {
    cursor: pointer;
  }
  
  .video-img {
    width: 200px;
  }
  
  h3 {
    font-size: 1.0rem;
    font-weight: 700;
    letter-spacing: -0.02rem;
    line-height: 20px;
    color: #2d2f31;
    margin: 10px 0;
    font-family: $primary_font;
  }
  
  p,
  span {
    font-size: 0.8rem;
    // font-weight: 700;
    font-family: $primary_font;
  }
  
  p {
    margin: 0;
  }
  </style>