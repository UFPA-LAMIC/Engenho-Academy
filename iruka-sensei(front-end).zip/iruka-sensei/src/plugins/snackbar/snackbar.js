import Snackbar from './SnackbarTemplate.vue';

export default {
  install(Vue) {
    Vue.prototype.$snackbar = ({ message, color, timeout }) => {
      
      const SnackbarComponent = Vue.extend(Snackbar);
      const snackbar = new SnackbarComponent({
        el: document.createElement('div'),
        propsData: { message, color, timeout },
      });
      // console.log(snackbar)
      snackbar.show = true
      document.body.appendChild(snackbar.$el);
    };
  },
};

