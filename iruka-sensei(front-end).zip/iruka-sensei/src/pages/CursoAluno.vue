<template>
  <div class="home ma-5">
    <h1 style="font: 1.5rem">Cursos da plataforma</h1>
    <div class="cards-curso">
      <div v-for="c in cursos" :key="c.id">
        <card-list
          :nome="c.nome"
          :data_inicio="c.data_inicio"
          :data_fim="c.data_fim"
          :color="c.color"
          :docente="c.docente"
          :id="c.id"
          :method="dialogExpand"
          tipo="dialog"
        ></card-list>
      </div>
    </div>

    <v-dialog
      transition="dialog-bottom-transition"
      width="1000"
      v-model="dialog"
    >
      <v-card>
        <v-card-title>E aí, vai matricular ?</v-card-title>
        <v-divider class="mx-5"></v-divider>
        <v-card-text fluid class="pa-0">
          <v-row class="mx-3">
            <v-col cols="12" sm="6" md="12">
              <label for="nome" class="labels pb-3">Curso</label>
              <v-text-field
                v-model="curso.nome"
                id="nome"
                dense
                readonly
              ></v-text-field>
            </v-col>
            <v-row>
              <v-col cols="12" sm="6" md="3">
                <label for="dtInicio" class="labels pb-3">Início</label>
                <v-text-field
                  v-model="curso.data_inicio"
                  id="dtInicio"
                  dense
                  readonly
                ></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <label for="dtInicio" class="labels pb-3">Fim</label>
                <v-text-field
                  v-model="curso.data_fim"
                  id="dtInicio"
                  dense
                  readonly
                ></v-text-field>
              </v-col>
            </v-row>
          </v-row>
          <v-row class="mx-3">
            <label for="infos" class="labels pb-3">Informações</label>
            <div id="infos" v-html="curso.infos"></div>
          </v-row>
        </v-card-text>
        <v-card-actions class="justify-end py-5 pr-5">
          <v-btn dark color="#002040" @click="dadosMatricula(curso)"
            >MATRICULAR</v-btn
          >
          <v-btn text color="secondary" @click="dialog = false">cancelar</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-snackbar
      v-model="snackbar"
      :timeout="4000"
      down
      left
      color="rgb(52, 185, 52)"
    >
      Boaa, parabéns pela matrícula! Aguarde deferimento.
    </v-snackbar>
  </div>
</template>

<script>
import axios from "axios";
import { baseApiUrl, userKey } from "../global.js";
import { mapGetters } from "vuex";
import CardList from "../components/CardList.vue";
export default {
  name: "CursoAluno",
  components: {
    CardList,
  },
  data: () => ({
    expand: false,
    snackbar: false,
    dialog: false,
    user: {},
    cursos: [],
    users: [],
    curso: {},
    matricula: {},
  }),
  methods: {
    ...mapGetters(["getUser"]),
    async loadCursos() {
      try {
        const response = await axios.get(`${baseApiUrl}/cursos`);
        this.cursos = response.data.data;
      } catch (error) {
        console.error(error);
      }
    },
    async loadCursoById(id) {
      try {
        const response = await axios.get(`${baseApiUrl}/curso/${id}`);
        this.curso = response.data.data;
      } catch (error) {
        console.error(error);
      }
    },
    async matricularAluno() {
      try {
        await axios.post(`${baseApiUrl}/matriculas`, this.matricula);
        console.log("matricula", this.matricula);
      } catch (error) {
        console.error(error);
      }
    },

    dadosMatricula(item) {
      this.matricula.aluno = this.getUser().id;
      this.matricula.curso = item.id;
      this.matricularAluno();
      this.dialog = false;
      this.snackbar = true;
    },
    dialogExpand(value, id) {
      this.dialog = value;
      this.loadCursoById(id);
    },
  },
  mounted() {
    this.loadCursos();
    if (localStorage.getItem(userKey)) {
      try {
        this.user = JSON.parse(localStorage.getItem(userKey));
        console.log("USEEEERRR", this.user);
        this.loadCursos(this.user.id);
      } catch (e) {
        localStorage.removeItem(userKey);
      }
    }
  },
};
</script>

<style>
/* .btn-add {
  display: flex;
  justify-content: center;
  align-content: center;
  align-items: center;
} */
</style>