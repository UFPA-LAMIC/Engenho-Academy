<template>
  <div class="home ma-5">
    <div class="mb-5">
      <h2 class="pa-2">
        <v-icon class="mr-2 mb-1">mdi-view-dashboard</v-icon> Painel Principal:
      </h2>
      <home-dashboard />
    </div>
    <h4>Meus Cursos</h4>
    <div class="cards-curso">
      <div class="mt-3" v-for="item in cursos" :key="item.id">
        <card-list
          :nome="item.nome"
          :videos="item.videos"
          :data_inicio="item.data_inicio"
          :data_fim="item.data_fim"
          :matriculados="item.matriculados"
          :docente="item.docente"
          :color="item.color"
          :id_matricula="item.id"
          :method="dialogExpand"
          tipo="expand"
        />
      </div>
    </div>
  </div>
</template>
<script>
import HomeDashboard from "./HomeDashboard.vue";
// import VideoList from "../features/VideoList.vue";
import CardList from "../components/CardList.vue";
import axios from "axios";
import { mapGetters } from "vuex";
import { baseApiUrl, userKey } from "../global";

export default {
  name: "Home",
  components: { CardList, HomeDashboard },
  data: () => ({
    expand: false,
    cursos: [],
    id: null,
  }),
  methods: {
    ...mapGetters(["getUser"]),
    async loadCursosProfessor(id) {
      try {
        const response = await axios.get(`${baseApiUrl}/cursos-docente/${id}`);
        this.cursos = response.data.data;
        console.log("curso prof");
      } catch (error) {
        console.error(error);
      }
    },
    getId(id) {
      return (this.id = id);
    },
    async loadCursosAluno(id) {
      try {
        const response = await axios.get(
          `${baseApiUrl}/cursos-matriculados/?id_user=${id}`
        );
        this.cursos = response.data.data;
        console.log("curso aluno");
      } catch (error) {
        console.error(error);
      }
    },
    dialogExpand(value, id_matricula) {
      this.expand = value;
      let id = this.getId(id_matricula);
      this.$router.push(`/videos?id_curso=${id}`).catch(() => {});
    },
  },
  mounted() {
    if (localStorage.getItem(userKey)) {
      try {
        this.user = JSON.parse(localStorage.getItem(userKey));
        console.log("USEEEERRR", this.user);
        this.user.tipo === "DOCENTE"
          ? this.loadCursosProfessor(this.user.id)
          : this.loadCursosAluno(this.user.id);
      } catch (e) {
        localStorage.removeItem(userKey);
      }
    }
  },
};
</script>
<style>
.home {
  height: 150vh;
  /* min-height: 150vh; */
}
.home h4 {
  font-weight: 400;
}
</style>